import * as React from "react"
import { CheckIcon, ClockIcon, AlertCircleIcon, Loader2Icon } from "lucide-react"
import { cn } from "../lib/utils"

export type PhaseStatus = "completed" | "in_progress" | "pending" | "failed" | "blocked"

export interface PlanPhase {
  id: string
  title: string
  description?: string
  status: PhaseStatus
  completedTasks?: number
  totalTasks?: number
}

export interface PhaseTrackerProps {
  phases: PlanPhase[]
  activePhaseId?: string
  onPhaseSelect?: (phase: PlanPhase) => void
  className?: string
}

export function PhaseTracker({
  phases,
  activePhaseId,
  onPhaseSelect,
  className,
}: PhaseTrackerProps) {
  const statusIcon = (status: PhaseStatus) => {
    switch (status) {
      case "completed": return <CheckIcon className="size-3 text-positive" />
      case "in_progress": return <Loader2Icon className="size-3 text-primary animate-spin" />
      case "failed": return <AlertCircleIcon className="size-3 text-destructive" />
      case "blocked": return <ClockIcon className="size-3 text-warning" />
      default: return <span className="size-1.5 rounded-full bg-muted-foreground/50" />
    }
  }

  return (
    <div
      data-slot="phase-tracker"
      className={cn("flex flex-col gap-2 rounded-lg border border-border bg-card p-3 font-sans text-xs", className)}
    >
      <div className="font-semibold text-strong font-mono uppercase tracking-wider text-xs text-muted-foreground mb-1">
        Implementation Roadmap
      </div>

      <div className="space-y-1.5">
        {phases.map((p, idx) => {
          const isActive = p.id === activePhaseId

          return (
            <div
              key={p.id}
              onClick={() => onPhaseSelect?.(p)}
              className={cn(
                "flex items-center justify-between gap-3 p-2 rounded border border-transparent transition-all cursor-pointer",
                isActive ? "border-primary bg-primary-surface/20" : "hover:bg-well/60"
              )}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="flex items-center justify-center size-5 rounded-full bg-control border border-border shrink-0">
                  {statusIcon(p.status)}
                </div>
                <div className="truncate">
                  <span className="font-mono text-muted-foreground text-xs mr-1.5">0{idx + 1}.</span>
                  <span className="font-medium text-strong">{p.title}</span>
                </div>
              </div>

              {p.totalTasks !== undefined && (
                <div className="font-mono text-2xs text-subtle shrink-0">
                  {p.completedTasks ?? 0}/{p.totalTasks} tasks
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
