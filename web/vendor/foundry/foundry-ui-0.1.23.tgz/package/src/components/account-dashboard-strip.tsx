import * as React from "react"
import { cn } from "../lib/utils"
import { PnlValue } from "./pnl-value"

export interface GreekValues {
  delta: number
  gamma: number
  theta: number
  vega: number
}

export interface AccountDashboardStripProps {
  accountName: string
  accountType?: "Live" | "Paper"
  netLiquidationValue: number
  dailyPnl: number
  dailyPnlPercent?: number
  valueAtExpiry?: number
  marginUtilizationPercent: number
  leverageRatio?: number
  greeks?: GreekValues
  className?: string
}

export function AccountDashboardStrip({
  accountName,
  accountType = "Live",
  netLiquidationValue,
  dailyPnl,
  dailyPnlPercent,
  valueAtExpiry,
  marginUtilizationPercent,
  leverageRatio,
  greeks,
  className,
}: AccountDashboardStripProps) {
  return (
    <div
      data-slot="account-dashboard-strip"
      className={cn(
        "flex flex-wrap items-center justify-between gap-4 rounded-lg border border-border bg-card px-4 py-2.5 font-mono text-xs shadow-xs",
        className
      )}
    >
      {/* Account Info */}
      <div className="flex items-center gap-2 border-r border-hairline pr-4">
        <span className="size-2 rounded-full bg-positive" />
        <span className="font-bold text-strong">{accountName}</span>
        <span className="text-2xs text-muted-foreground uppercase bg-control px-1.5 py-0.5 rounded">
          {accountType}
        </span>
      </div>

      {/* NLV & Daily P&L */}
      <div className="flex flex-col">
        <span className="text-2xs text-muted-foreground uppercase">Net Liquidation</span>
        <div className="flex items-baseline gap-2">
          <span className="text-sm font-bold text-strong">
            ${netLiquidationValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
          <PnlValue value={dailyPnl} percent={dailyPnlPercent} />
        </div>
      </div>

      {/* Margin Progress */}
      <div className="flex flex-col min-w-[120px]">
        <div className="flex justify-between text-2xs">
          <span className="text-muted-foreground uppercase">Margin</span>
          <span className={cn("font-bold", marginUtilizationPercent > 80 ? "text-destructive" : "text-strong")}>
            {marginUtilizationPercent.toFixed(1)}%
          </span>
        </div>
        <div className="h-1.5 w-full bg-control rounded-full overflow-hidden mt-1">
          <div
            style={{ width: `${Math.min(100, marginUtilizationPercent)}%` }}
            className={cn(
              "h-full rounded-full transition-all",
              marginUtilizationPercent > 80 ? "bg-destructive" : marginUtilizationPercent > 60 ? "bg-warning" : "bg-positive"
            )}
          />
        </div>
      </div>

      {/* Greeks Ribbon */}
      {greeks && (
        <div className="flex items-center gap-3 border-l border-hairline pl-4 text-xs">
          <div>
            <span className="text-muted-foreground">Δ</span>{" "}
            <span className={greeks.delta >= 0 ? "text-positive" : "text-negative"}>
              {greeks.delta > 0 ? "+" : ""}{greeks.delta.toFixed(1)}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Γ</span>{" "}
            <span className="text-strong">{greeks.gamma.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Θ</span>{" "}
            <span className={greeks.theta >= 0 ? "text-positive" : "text-negative"}>
              {greeks.theta > 0 ? "+" : ""}${greeks.theta.toFixed(0)}/d
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">V</span>{" "}
            <span className="text-strong">{greeks.vega.toFixed(0)}</span>
          </div>
        </div>
      )}

      {leverageRatio !== undefined && (
        <div className="text-2xs text-muted-foreground border-l border-hairline pl-4">
          Lev: <span className="font-semibold text-strong">{leverageRatio.toFixed(2)}x</span>
        </div>
      )}
    </div>
  )
}
