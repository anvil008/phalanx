import {
  useEffect,
  useRef,
  useState,
  type ComponentProps,
  type ReactNode,
} from "react"

import { cn } from "../lib/utils"

export type NumberValueTone =
  | "neutral"
  | "sign"
  | "income"
  | "delta"
  | "positive"
  | "negative"
  | "muted"

export type NumberValueProps = Omit<ComponentProps<"span">, "children"> & {
  value: number | null | undefined
  formatter?: (value: number) => ReactNode
  fallback?: ReactNode
  tone?: NumberValueTone
  suffix?: ReactNode
}

const toneClasses = {
  neutral: "text-strong",
  positive: "text-positive",
  negative: "text-negative",
  muted: "text-muted-foreground",
} as const

function resolvedTone(value: number, tone: NumberValueTone) {
  if (tone === "income") return value > 0 ? "positive" : "neutral"
  if (tone !== "sign" && tone !== "delta") return tone
  if (value > 0) return "positive"
  if (value < 0) return "negative"
  return "neutral"
}

export function NumberValue({
  value,
  formatter = (nextValue) => nextValue.toLocaleString(),
  fallback = "—",
  tone = "neutral",
  suffix,
  className,
  ...props
}: NumberValueProps) {
  const isValid = typeof value === "number" && Number.isFinite(value)
  const activeTone = isValid ? resolvedTone(value, tone) : "muted"

  return (
    <span
      data-slot="number-value"
      data-tone={activeTone}
      className={cn(
        "font-mono font-medium tracking-[-0.025em] tabular-nums",
        toneClasses[activeTone],
        className
      )}
      {...props}
    >
      {isValid ? formatter(value) : fallback}
      {isValid && suffix != null ? (
        <span
          data-slot="number-value-suffix"
          className="text-[0.75em] text-subtle"
        >
          {suffix}
        </span>
      ) : null}
    </span>
  )
}

export function NumberValueGroup({
  className,
  ...props
}: ComponentProps<"span">) {
  return (
    <span
      data-slot="number-value-group"
      className={cn("inline-flex items-baseline gap-1.5", className)}
      {...props}
    />
  )
}

export function NumberValueDetail({
  variant = "label",
  className,
  ...props
}: ComponentProps<"span"> & {
  variant?: "label" | "parenthetical"
}) {
  return (
    <span
      data-slot="number-value-detail"
      data-variant={variant}
      className={cn(
        variant === "label" && "text-xs text-muted-foreground",
        variant === "parenthetical" && "text-[0.8em] opacity-70",
        className
      )}
      {...props}
    />
  )
}

export function DeltaBadge({
  value,
  formatter = (nextValue) => nextValue.toLocaleString(),
  detail,
  invertTone = false,
  indicator = "arrow",
  className,
  ...props
}: Omit<ComponentProps<"span">, "children"> & {
  value: number
  formatter?: (absoluteValue: number) => ReactNode
  detail?: ReactNode
  invertTone?: boolean
  indicator?: "arrow" | "sign"
}) {
  const up = value >= 0
  const positive = invertTone ? !up : up
  const indicatorGlyph =
    indicator === "sign" ? (up ? "+" : "−") : up ? "↑" : "↓"
  const formattedValue = formatter(Math.abs(value))
  const compactSign =
    indicator === "sign" &&
    (typeof formattedValue === "string" || typeof formattedValue === "number")

  return (
    <span
      data-slot="delta-badge"
      data-direction={up ? "up" : "down"}
      data-tone={positive ? "positive" : "negative"}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-sm px-2 py-[3px] font-mono text-base font-medium whitespace-nowrap tabular-nums",
        positive
          ? "bg-positive/10 text-positive"
          : "bg-negative/10 text-negative",
        className
      )}
      {...props}
    >
      {compactSign ? (
        `${indicatorGlyph}${formattedValue}`
      ) : (
        <>
          <span aria-hidden={indicator === "arrow"}>{indicatorGlyph}</span>
          {formattedValue}
        </>
      )}
      {detail != null ? <span className="opacity-75">{detail}</span> : null}
    </span>
  )
}

export function Money({
  value,
  currency = "USD",
  locale = "en-US",
  compact = false,
  showCents = "auto",
  signDisplay = "auto",
  ...props
}: Omit<NumberValueProps, "formatter"> & {
  currency?: string
  locale?: string
  compact?: boolean
  showCents?: boolean | "auto"
  signDisplay?: Intl.NumberFormatOptions["signDisplay"]
}) {
  const formatter = new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    notation: compact ? "compact" : "standard",
    compactDisplay: "short",
    signDisplay,
    minimumFractionDigits: showCents === true ? 2 : showCents === false ? 0 : undefined,
    maximumFractionDigits: showCents === true ? 2 : showCents === false ? 0 : undefined,
  })

  return <NumberValue value={value} formatter={(nextValue) => formatter.format(nextValue)} {...props} />
}

export function Percent({
  value,
  locale = "en-US",
  fractionDigits = 1,
  fromFraction = false,
  signDisplay = "auto",
  ...props
}: Omit<NumberValueProps, "formatter"> & {
  locale?: string
  fractionDigits?: number
  fromFraction?: boolean
  signDisplay?: Intl.NumberFormatOptions["signDisplay"]
}) {
  const formatter = new Intl.NumberFormat(locale, {
    style: "percent",
    signDisplay,
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  })

  return (
    <NumberValue
      value={value}
      formatter={(nextValue) => formatter.format(fromFraction ? nextValue : nextValue / 100)}
      {...props}
    />
  )
}

export function DeltaValue({
  value,
  locale = "en-US",
  fractionDigits = 1,
  suffix,
  ...props
}: Omit<NumberValueProps, "formatter" | "tone"> & {
  locale?: string
  fractionDigits?: number
  suffix?: ReactNode
}) {
  const formatter = new Intl.NumberFormat(locale, {
    signDisplay: "exceptZero",
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  })

  return (
    <NumberValue
      value={value}
      tone="sign"
      formatter={(nextValue) => (
        <>
          {formatter.format(nextValue)}
          {suffix}
        </>
      )}
      {...props}
    />
  )
}

export function AnimatedNumber({
  value,
  duration = 420,
  ...props
}: NumberValueProps & {
  duration?: number
}) {
  const previousValue = useRef(value)
  const [displayValue, setDisplayValue] = useState(value)

  useEffect(() => {
    const startValue =
      typeof previousValue.current === "number" && Number.isFinite(previousValue.current)
        ? previousValue.current
        : value
    previousValue.current = value

    if (
      typeof value !== "number" ||
      !Number.isFinite(value) ||
      typeof startValue !== "number" ||
      !Number.isFinite(startValue) ||
      duration <= 0 ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      setDisplayValue(value)
      return
    }

    let animationFrame = 0
    const startTime = performance.now()
    const tick = (now: number) => {
      const progress = Math.min((now - startTime) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setDisplayValue(startValue + (value - startValue) * eased)
      if (progress < 1) animationFrame = requestAnimationFrame(tick)
    }

    animationFrame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(animationFrame)
  }, [duration, value])

  return <NumberValue value={displayValue} {...props} />
}
