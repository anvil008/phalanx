import {
  useEffect,
  useState,
  type FormEvent,
  type ReactNode,
} from "react"
import {
  BotIcon,
  CheckIcon,
  CircleAlertIcon,
  PlayIcon,
  TerminalSquareIcon,
} from "lucide-react"

import { cn } from "../lib/utils"
import { Alert, AlertDescription, AlertTitle } from "./alert"
import { Bubble, BubbleContent } from "./bubble"
import { Button } from "./button"
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "./empty"
import {
  Item,
  ItemContent,
  ItemDescription,
  ItemMedia,
  ItemTitle,
} from "./item"
import {
  Message,
  MessageContent,
  MessageHeader,
} from "./message"
import {
  MessageScroller,
  MessageScrollerButton,
  MessageScrollerContent,
  MessageScrollerItem,
  MessageScrollerProvider,
  MessageScrollerViewport,
} from "./message-scroller"
import { Spinner } from "./spinner"
import { StatusBadge } from "./status-badge"
import { Textarea } from "./textarea"

export type AgentRunItem =
  | {
      id: string
      type: "message"
      role: "user" | "assistant"
      content: ReactNode
      label?: ReactNode
    }
  | {
      id: string
      type: "tool"
      name: string
      status: "running" | "complete" | "error"
      input?: ReactNode
      output?: ReactNode
    }
  | {
      id: string
      type: "status"
      label: ReactNode
    }
  | {
      id: string
      type: "error"
      message: ReactNode
    }

function toDate(value: Date | number | string) {
  return value instanceof Date ? value : new Date(value)
}

function relativeAge(value: Date | number | string) {
  const milliseconds = Date.now() - toDate(value).getTime()
  const seconds = Math.max(0, Math.floor(milliseconds / 1000))
  if (seconds < 60) return `${seconds}s ago`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}

export function FreshnessStamp({
  asOf,
  cached = false,
  className,
}: {
  asOf?: Date | number | string | null
  cached?: boolean
  className?: string
}) {
  if (asOf == null) return null
  const date = toDate(asOf)
  if (!Number.isFinite(date.getTime())) return null

  const exact = new Intl.DateTimeFormat("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "UTC",
    hour12: false,
  }).format(date)

  return (
    <span
      data-slot="freshness-stamp"
      title={date.toISOString()}
      className={cn("font-mono text-2xs text-muted-foreground", className)}
    >
      as of {exact} UTC · {relativeAge(date)}
      {cached ? " · cached" : ""}
    </span>
  )
}

export function RerunPrompt({
  asOf,
  costLabel,
  onUseCached,
  onRerun,
  className,
}: {
  asOf: Date | number | string
  costLabel: ReactNode
  onUseCached: () => void
  onRerun: () => void
  className?: string
}) {
  return (
    <div
      data-slot="rerun-prompt"
      role="alertdialog"
      aria-label="Cached result available"
      className={cn("rounded-lg border border-border bg-well px-3 py-2.5", className)}
    >
      <div className="text-sm text-foreground">
        A cached result from {relativeAge(asOf)} is available.
      </div>
      <div className="mt-1 font-mono text-2xs text-muted-foreground">
        Re-run cost · {costLabel}
      </div>
      <div className="mt-2.5 flex items-center gap-2">
        <Button type="button" size="xs" variant="outline" onClick={onUseCached}>
          Use cached
        </Button>
        <Button type="button" size="xs" onClick={onRerun}>
          Re-run
        </Button>
      </div>
    </div>
  )
}

export function AgentToolEvent({
  name,
  status,
  input,
  output,
}: Extract<AgentRunItem, { type: "tool" }>) {
  return (
    <Item variant="outline" size="xs" className="bg-row">
      <ItemMedia variant="icon" className="text-info">
        {status === "running" ? (
          <Spinner className="size-3.5" />
        ) : status === "error" ? (
          <CircleAlertIcon className="size-3.5 text-destructive" />
        ) : (
          <CheckIcon className="size-3.5 text-positive" />
        )}
      </ItemMedia>
      <ItemContent>
        <ItemTitle className="font-mono text-xs">
          <TerminalSquareIcon className="size-3 text-subtle" />
          {name}
        </ItemTitle>
        {(input || output) && (
          <ItemDescription className="line-clamp-3 font-mono text-2xs">
            {output ?? input}
          </ItemDescription>
        )}
      </ItemContent>
      <StatusBadge
        tone={status === "complete" ? "online" : status === "error" ? "error" : "info"}
        pulse={status === "running"}
      >
        {status}
      </StatusBadge>
    </Item>
  )
}

export function AgentRunPanel({
  prompt = "",
  onPromptChange = () => {},
  onRun = () => {},
  items = [],
  running = false,
  title = "Agent run",
  description = "Ask for an analysis grounded in the current application context.",
  placeholder = "Ask the agent…",
  runLabel = "Run analysis",
  emptyTitle = "Ready for a task",
  emptyDescription = "Run an analysis to stream responses and tool activity here.",
  freshness,
  footer,
  className,
}: {
  prompt?: string
  onPromptChange?: (prompt: string) => void
  onRun?: (prompt: string) => void
  items?: AgentRunItem[]
  running?: boolean
  title?: ReactNode
  description?: ReactNode
  placeholder?: string
  runLabel?: string
  emptyTitle?: string
  emptyDescription?: string
  freshness?: ReactNode
  footer?: ReactNode
  className?: string
}) {
  const [elapsed, setElapsed] = useState(0)

  useEffect(() => {
    if (!running) return
    setElapsed(0)
    const interval = window.setInterval(() => setElapsed((value) => value + 1), 1000)
    return () => window.clearInterval(interval)
  }, [running])

  const submit = (event: FormEvent) => {
    event.preventDefault()
    if (!running && prompt.trim()) onRun(prompt.trim())
  }

  return (
    <section
      data-slot="agent-run-panel"
      className={cn("overflow-hidden rounded-lg border border-border bg-card", className)}
    >
      <div className="flex items-start justify-between gap-4 border-b border-hairline px-4 py-3">
        <div>
          <div className="text-base font-semibold text-strong">{title}</div>
          <div className="mt-0.5 text-2xs text-muted-foreground">{description}</div>
        </div>
        {running ? (
          <StatusBadge tone="info" pulse>
            {elapsed}s
          </StatusBadge>
        ) : (
          freshness
        )}
      </div>

      <div className="h-72 min-h-0">
        {items.length === 0 && !running ? (
          <Empty className="min-h-full rounded-none border-0">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <BotIcon className="size-4" />
              </EmptyMedia>
              <EmptyTitle>{emptyTitle}</EmptyTitle>
              <EmptyDescription>{emptyDescription}</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <MessageScrollerProvider autoScroll>
            <MessageScroller>
              <MessageScrollerViewport>
                <MessageScrollerContent className="gap-3 p-4">
                  {items.map((item, index) => (
                    <MessageScrollerItem
                      key={item.id}
                      scrollAnchor={index === items.length - 1}
                    >
                      <AgentRunBlock item={item} />
                    </MessageScrollerItem>
                  ))}
                  {running && (
                    <MessageScrollerItem scrollAnchor>
                      <div className="flex items-center gap-2 font-mono text-2xs text-muted-foreground">
                        <Spinner className="size-3" />
                        working · {elapsed}s
                      </div>
                    </MessageScrollerItem>
                  )}
                </MessageScrollerContent>
              </MessageScrollerViewport>
              <MessageScrollerButton />
            </MessageScroller>
          </MessageScrollerProvider>
        )}
      </div>

      <form onSubmit={submit} className="border-t border-hairline p-3">
        <div className="flex items-start gap-2">
          <Textarea
            value={prompt}
            onChange={(event) => onPromptChange(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
                submit(event)
              }
            }}
            placeholder={placeholder}
            rows={2}
            className="min-h-14 flex-1"
          />
          <Button type="submit" disabled={running || !prompt.trim()} aria-busy={running}>
            {running ? <Spinner /> : <PlayIcon />}
            {running ? "Running" : runLabel}
          </Button>
        </div>
        {footer && (
          <div className="mt-2 flex min-h-4 items-center justify-between gap-3">
            <span className="text-2xs text-muted-foreground">{footer}</span>
          </div>
        )}
      </form>
    </section>
  )
}

function AgentRunBlock({ item }: { item: AgentRunItem }) {
  if (item.type === "tool") return <AgentToolEvent {...item} />

  if (item.type === "status") {
    return <div className="font-mono text-2xs text-muted-foreground">{item.label}</div>
  }

  if (item.type === "error") {
    return (
      <Alert variant="destructive">
        <CircleAlertIcon />
        <AlertTitle>Agent run failed</AlertTitle>
        <AlertDescription>{item.message}</AlertDescription>
      </Alert>
    )
  }

  const isUser = item.role === "user"
  return (
    <Message align={isUser ? "end" : "start"}>
      <MessageContent>
        {item.label && <MessageHeader>{item.label}</MessageHeader>}
        <Bubble align={isUser ? "end" : "start"} variant={isUser ? "default" : "outline"}>
          <BubbleContent>{item.content}</BubbleContent>
        </Bubble>
      </MessageContent>
    </Message>
  )
}
