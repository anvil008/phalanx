import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ComponentProps,
  type ReactNode,
} from "react"
import { createPortal } from "react-dom"

import { cn } from "../lib/utils"

type PageChromeContextValue = {
  title: string | null
  subtitle: string | null
  setTitle: (title: string | null) => void
  setSubtitle: (subtitle: string | null) => void
  actionsElement: HTMLElement | null
  setActionsElement: (element: HTMLElement | null) => void
}

const PageChromeContext = createContext<PageChromeContextValue | null>(null)

export function PageChromeProvider({ children }: { children: ReactNode }) {
  const [title, setTitle] = useState<string | null>(null)
  const [subtitle, setSubtitle] = useState<string | null>(null)
  const [actionsElement, setActionsElement] = useState<HTMLElement | null>(null)

  return (
    <PageChromeContext.Provider
      value={{
        title,
        subtitle,
        setTitle,
        setSubtitle,
        actionsElement,
        setActionsElement,
      }}
    >
      {children}
    </PageChromeContext.Provider>
  )
}

function usePageChrome() {
  const context = useContext(PageChromeContext)
  if (!context) {
    throw new Error("PageChrome components must be rendered inside PageChromeProvider")
  }
  return context
}

export function usePageTitle(title: string, subtitle?: string) {
  const { setTitle, setSubtitle } = usePageChrome()

  useEffect(() => {
    setTitle(title)
    setSubtitle(subtitle ?? null)
    return () => {
      setTitle(null)
      setSubtitle(null)
    }
  }, [setSubtitle, setTitle, subtitle, title])
}

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string
  subtitle?: string
  actions?: ReactNode
}) {
  usePageTitle(title, subtitle)
  return actions ? <HeaderActions>{actions}</HeaderActions> : null
}

export function HeaderActions({ children }: { children: ReactNode }) {
  const { actionsElement } = usePageChrome()
  return actionsElement ? createPortal(children, actionsElement) : null
}

export function PageChromeBar({
  fallbackTitle,
  leading,
  className,
}: {
  fallbackTitle: string
  leading?: ReactNode
  className?: string
}) {
  const { title, subtitle, setActionsElement } = usePageChrome()

  return (
    <header
      data-slot="page-chrome"
      className={cn(
        "sticky top-0 z-30 flex h-(--chrome-height) shrink-0 items-center justify-between gap-3 border-b border-border bg-background/95 px-5 backdrop-blur",
        className
      )}
    >
      <div className="flex min-w-0 items-center gap-2.5">
        {leading}
        <div className="flex min-w-0 items-baseline gap-2.5">
          <h1 className="truncate text-base font-semibold tracking-[-0.02em] text-strong">
            {title ?? fallbackTitle}
          </h1>
          {subtitle && (
            <span className="hidden truncate font-mono text-2xs text-subtle sm:inline">
              {subtitle}
            </span>
          )}
        </div>
      </div>
      <div
        ref={setActionsElement}
        aria-label="Page actions"
        className="flex shrink-0 items-center gap-2"
      />
    </header>
  )
}

export function PageContent({
  className,
  ...props
}: ComponentProps<"div">) {
  return (
    <div
      data-slot="page-content"
      className={cn(
        "flex min-w-0 flex-1 flex-col gap-4 overflow-y-auto px-5 py-5",
        className
      )}
      {...props}
    />
  )
}
