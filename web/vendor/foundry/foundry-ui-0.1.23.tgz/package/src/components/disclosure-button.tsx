import * as React from "react"

import { Button } from "./button"
import { cn } from "../lib/utils"

/**
 * A quiet disclosure control. Its expanded state communicates structure via
 * its indicator and `aria-expanded`, never by turning the control into a
 * filled button. This is deliberately separate from the general ghost button:
 * menus and selection controls can still use an active surface when useful.
 */
function DisclosureButton({
  className,
  ...props
}: Omit<React.ComponentProps<typeof Button>, "variant">) {
  return (
    <Button
      variant="ghost"
      className={cn(
        "border-transparent bg-transparent hover:bg-transparent active:bg-transparent aria-expanded:bg-transparent",
        className,
      )}
      {...props}
    />
  )
}

export { DisclosureButton }
