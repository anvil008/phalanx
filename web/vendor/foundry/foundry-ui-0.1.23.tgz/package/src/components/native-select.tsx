import * as React from "react"
import { ChevronDownIcon } from "lucide-react"

import { cn } from "../lib/utils"
import { formControlVariants, type FormControlVariantProps } from "../lib/form-control"
import { useFieldContext } from "./field"

export interface NativeSelectProps
  extends Omit<React.ComponentProps<"select">, "size">,
    FormControlVariantProps {
  size?: "sm" | "default" | "lg"
}

function NativeSelect({
  className,
  size = "default",
  controlSize,
  variant = "default",
  ...props
}: NativeSelectProps) {
  const fieldContext = useFieldContext()
  const effectiveSize = controlSize || size
  const id = props.id || (fieldContext.fieldId ? `${fieldContext.fieldId}-control` : undefined)
  const ariaInvalid = props["aria-invalid"] ?? (fieldContext.invalid ? true : undefined)
  const ariaDescribedBy =
    props["aria-describedby"] ||
    (fieldContext.invalid && fieldContext.errorId
      ? fieldContext.errorId
      : fieldContext.descriptionId || undefined)

  return (
    <div
      className={cn(
        "group/native-select relative w-fit has-[select:disabled]:opacity-50",
        className
      )}
      data-slot="native-select-wrapper"
      data-size={effectiveSize}
    >
      <select
        id={id}
        data-slot="native-select"
        data-size={effectiveSize}
        aria-invalid={ariaInvalid}
        aria-describedby={ariaDescribedBy}
        disabled={props.disabled ?? fieldContext.disabled}
        className={cn(
          "rounded-control appearance-none pr-8 pl-2.5 text-sm font-semibold tracking-[-0.01em] text-muted-foreground select-none selection:bg-primary selection:text-primary-foreground hover:text-foreground focus-visible:text-foreground",
          formControlVariants({ controlSize: effectiveSize, variant }),
          effectiveSize === "sm" && "h-7",
          effectiveSize === "default" && "h-8",
          effectiveSize === "lg" && "h-9"
        )}
        {...props}
      />
      <ChevronDownIcon
        className="pointer-events-none absolute top-1/2 right-2.5 size-3.5 -translate-y-1/2 text-muted-foreground select-none"
        aria-hidden="true"
        data-slot="native-select-icon"
      />
    </div>
  )
}

function NativeSelectOption({
  className,
  ...props
}: React.ComponentProps<"option">) {
  return (
    <option
      data-slot="native-select-option"
      className={cn("bg-[Canvas] text-[CanvasText]", className)}
      {...props}
    />
  )
}

function NativeSelectOptGroup({
  className,
  ...props
}: React.ComponentProps<"optgroup">) {
  return (
    <optgroup
      data-slot="native-select-optgroup"
      className={cn("bg-[Canvas] text-[CanvasText]", className)}
      {...props}
    />
  )
}

export { NativeSelect, NativeSelectOptGroup, NativeSelectOption }
