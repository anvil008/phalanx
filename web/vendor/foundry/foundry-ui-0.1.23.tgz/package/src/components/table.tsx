"use client"

import * as React from "react"

import {
  tableInteractiveSurfaceClass,
  tableSurfaceClass,
  tableSurfaceStyle,
} from "../lib/table-surface"
import { cn } from "../lib/utils"

function Table({ className, ...props }: React.ComponentProps<"table">) {
  return (
    <div
      data-slot="table-container"
      className="relative w-full overflow-x-auto bg-card"
    >
      <table
        data-slot="table"
        className={cn("w-full caption-bottom bg-card text-sm", className)}
        {...props}
      />
    </div>
  )
}

function TableHeader({
  className,
  style,
  ...props
}: React.ComponentProps<"thead">) {
  return (
    <thead
      data-slot="table-header"
      className={cn(tableSurfaceClass, "[&_tr]:border-b", className)}
      style={{ ...tableSurfaceStyle("structural"), ...style }}
      {...props}
    />
  )
}

function TableBody({
  className,
  style,
  ...props
}: React.ComponentProps<"tbody">) {
  return (
    <tbody
      data-slot="table-body"
      className={cn("[&_tr:last-child]:border-0", className)}
      style={{ ...tableSurfaceStyle("base"), ...style }}
      {...props}
    />
  )
}

function TableFooter({
  className,
  style,
  ...props
}: React.ComponentProps<"tfoot">) {
  return (
    <tfoot
      data-slot="table-footer"
      className={cn(
        tableSurfaceClass,
        "border-t font-medium [&>tr]:last:border-b-0",
        className
      )}
      style={{ ...tableSurfaceStyle("structural"), ...style }}
      {...props}
    />
  )
}

function TableRow({ className, ...props }: React.ComponentProps<"tr">) {
  return (
    <tr
      data-slot="table-row"
      className={cn(
        tableInteractiveSurfaceClass,
        "border-b transition-colors data-[state=selected]:[--foundry-table-surface:var(--muted)] data-[state=selected]:[--foundry-table-surface-image:none]",
        className
      )}
      {...props}
    />
  )
}

type TableBandVariant = "section" | "summary"

/** A semantic structural row; sections and summaries intentionally match. */
function TableBandRow({
  className,
  style,
  variant = "section",
  ...props
}: React.ComponentProps<"tr"> & { variant?: TableBandVariant }) {
  return (
    <tr
      data-slot="table-band-row"
      data-variant={variant}
      className={cn(
        tableSurfaceClass,
        "border-b",
        variant === "summary" && "font-semibold",
        className,
      )}
      style={{ ...tableSurfaceStyle("structural"), ...style }}
      {...props}
    />
  )
}

function TableHead({ className, ...props }: React.ComponentProps<"th">) {
  return (
    <th
      data-slot="table-head"
      className={cn(
        tableSurfaceClass,
        "h-10 px-2 text-left align-middle font-medium whitespace-nowrap text-foreground [&:has([role=checkbox])]:pr-0",
        className
      )}
      {...props}
    />
  )
}

/** Opaque sticky header cell that follows its owning row/header surface. */
function TableStickyHead({ className, ...props }: React.ComponentProps<"th">) {
  return (
    <TableHead
      data-slot="table-sticky-head"
      className={cn("sticky left-0 z-10", className)}
      {...props}
    />
  )
}

function TableCell({ className, ...props }: React.ComponentProps<"td">) {
  return (
    <td
      data-slot="table-cell"
      className={cn(
        tableSurfaceClass,
        "p-2 align-middle whitespace-nowrap [&:has([role=checkbox])]:pr-0",
        className
      )}
      {...props}
    />
  )
}

/** Opaque sticky body/footer cell that follows its owning row surface. */
function TableStickyCell({ className, ...props }: React.ComponentProps<"td">) {
  return (
    <TableCell
      data-slot="table-sticky-cell"
      className={cn(tableSurfaceClass, "sticky left-0 z-10", className)}
      {...props}
    />
  )
}

function TableCaption({
  className,
  ...props
}: React.ComponentProps<"caption">) {
  return (
    <caption
      data-slot="table-caption"
      className={cn("mt-4 text-sm text-muted-foreground", className)}
      {...props}
    />
  )
}

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableStickyHead,
  TableRow,
  TableBandRow,
  TableCell,
  TableStickyCell,
  TableCaption,
}
