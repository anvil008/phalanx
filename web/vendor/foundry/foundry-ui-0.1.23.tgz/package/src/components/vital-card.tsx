import * as React from "react"
import { cn } from "../lib/utils"

export interface VitalCardProps extends Omit<React.ComponentProps<"div">, "title"> {
  title: React.ReactNode
  value: number | string
  unit?: React.ReactNode
  ageStamp?: string
  zScore?: number
  percentile?: number
  deltaVsBaseline?: string
  sparkline?: React.ReactNode
  footerNote?: string
  onClick?: () => void
}

export function VitalCard({
  title,
  value,
  unit,
  ageStamp,
  zScore,
  percentile,
  deltaVsBaseline,
  sparkline,
  footerNote,
  onClick,
  className,
  ...props
}: VitalCardProps) {
  const isClickable = onClick !== undefined

  return (
    <div
      data-slot="vital-card"
      onClick={onClick}
      className={cn(
        "flex flex-col justify-between rounded-lg border border-border bg-card p-3.5 transition-all font-sans",
        isClickable && "cursor-pointer hover:border-subtle hover:bg-well/40",
        className
      )}
      {...props}
    >
      <div className="flex items-start justify-between gap-2">
        <span className="text-xs font-semibold text-muted-foreground">{title}</span>
        {ageStamp && <span className="font-mono text-2xs text-subtle">{ageStamp}</span>}
      </div>

      <div className="flex items-baseline gap-1.5 my-2">
        <span className="font-mono text-2xl font-bold tracking-tight text-strong">{value}</span>
        {unit && <span className="font-mono text-xs text-muted-foreground">{unit}</span>}
      </div>

      {/* Deviation / Baseline chips */}
      <div className="flex flex-wrap items-center gap-1.5 font-mono text-2xs mb-2">
        {zScore !== undefined && (
          <span className={cn(
            "px-1.5 py-0.5 rounded font-semibold",
            Math.abs(zScore) >= 2 ? "bg-destructive/10 text-destructive" : "bg-control text-secondary-foreground"
          )}>
            {zScore >= 0 ? "+" : ""}{zScore.toFixed(1)}σ
          </span>
        )}
        {percentile !== undefined && (
          <span className="bg-control px-1.5 py-0.5 rounded text-muted-foreground">
            {percentile}th pct
          </span>
        )}
        {deltaVsBaseline && (
          <span className="text-subtle">{deltaVsBaseline}</span>
        )}
      </div>

      {sparkline && <div className="mt-1">{sparkline}</div>}

      {footerNote && (
        <div className="mt-2 pt-2 border-t border-hairline font-mono text-2xs text-subtle truncate">
          {footerNote}
        </div>
      )}
    </div>
  )
}
