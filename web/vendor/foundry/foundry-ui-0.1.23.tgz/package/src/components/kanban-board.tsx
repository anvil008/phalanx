import * as React from "react"
import { PlusIcon } from "lucide-react"
import { cn } from "../lib/utils"
import { Button } from "./button"

export type KanbanPriority = "urgent" | "high" | "medium" | "low"

export interface KanbanTask {
  id: string
  title: string
  description?: string
  priority?: KanbanPriority
  actor?: { name: string; avatarUrl?: string; isBot?: boolean }
  tags?: string[]
  laneId: string
}

export interface KanbanLaneData {
  id: string
  title: string
  tasks: KanbanTask[]
  limit?: number
}

export interface KanbanBoardProps {
  lanes: KanbanLaneData[]
  onTaskMove?: (taskId: string, targetLaneId: string) => void
  onAddTask?: (laneId: string) => void
  onTaskClick?: (task: KanbanTask) => void
  className?: string
}

export function KanbanBoard({
  lanes,
  onTaskMove,
  onAddTask,
  onTaskClick,
  className,
}: KanbanBoardProps) {
  const [draggedTaskId, setDraggedTaskId] = React.useState<string | null>(null)

  const priorityStripe = (p?: KanbanPriority) => {
    switch (p) {
      case "urgent": return "border-l-4 border-l-destructive"
      case "high": return "border-l-4 border-l-warning"
      case "medium": return "border-l-4 border-l-info"
      default: return "border-l-2 border-l-border"
    }
  }

  return (
    <div
      data-slot="kanban-board"
      className={cn("flex gap-4 overflow-x-auto pb-4 items-start w-full min-h-[420px]", className)}
    >
      {lanes.map((lane) => (
        <div
          key={lane.id}
          onDragOver={(e) => e.preventDefault()}
          onDrop={() => {
            if (draggedTaskId) {
              onTaskMove?.(draggedTaskId, lane.id)
              setDraggedTaskId(null)
            }
          }}
          className="flex flex-col flex-1 min-w-[260px] max-w-[340px] rounded-lg border border-border bg-card/60 overflow-hidden"
        >
          {/* Lane Header */}
          <div className="flex items-center justify-between border-b border-hairline bg-well/40 px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-xs text-strong">{lane.title}</span>
              <span className="rounded-full bg-control px-2 py-0.5 font-mono text-2xs text-muted-foreground">
                {lane.tasks.length}
              </span>
            </div>
            {onAddTask && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onAddTask(lane.id)}
                className="size-6 text-muted-foreground hover:text-foreground"
              >
                <PlusIcon className="size-3.5" />
              </Button>
            )}
          </div>

          {/* Task List */}
          <div className="p-2 space-y-2 flex-1 overflow-y-auto min-h-[120px]">
            {lane.tasks.map((task) => (
              <div
                key={task.id}
                draggable
                onDragStart={() => setDraggedTaskId(task.id)}
                onClick={() => onTaskClick?.(task)}
                className={cn(
                  "flex flex-col gap-1.5 rounded border border-border bg-card p-2.5 transition-all cursor-grab active:cursor-grabbing hover:border-subtle/60 hover:bg-well/40 select-none shadow-xs",
                  priorityStripe(task.priority)
                )}
              >
                <div className="text-xs font-medium text-strong leading-snug">{task.title}</div>
                {task.description && (
                  <div className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                    {task.description}
                  </div>
                )}
                <div className="flex items-center justify-between pt-1 mt-0.5 border-t border-hairline text-2xs text-subtle">
                  {task.actor && (
                    <span className="font-mono flex items-center gap-1">
                      {task.actor.isBot ? "🤖" : "👤"} {task.actor.name}
                    </span>
                  )}
                  {task.tags && task.tags.length > 0 && (
                    <div className="flex gap-1">
                      {task.tags.map((t) => (
                        <span key={t} className="bg-control px-1.5 py-0.5 rounded text-2xs font-mono">
                          {t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
