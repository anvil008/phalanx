import type { ReactNode } from "react"

import { Badge } from "./badge"
import { cn } from "../lib/utils"
import { getToneBadgeClasses, type StatusToneInput } from "../lib/status-intent"

export interface StatusBadgeProps {
  children: ReactNode
  tone?: StatusToneInput
  pulse?: boolean
  className?: string
}

export function StatusBadge({
  children,
  tone = "neutral",
  pulse = false,
  className,
}: StatusBadgeProps) {
  const badgeClasses = getToneBadgeClasses(tone)

  return (
    <Badge
      variant="outline"
      className={cn("gap-1.5 rounded-full px-2 font-mono text-2xs uppercase tracking-wider", badgeClasses, className)}
    >
      <span className="relative flex size-1.5">
        {pulse && <span className="absolute -inset-0.5 rounded-full border border-current opacity-35" />}
        <span className="relative inline-flex size-1.5 rounded-full bg-current" />
      </span>
      {children}
    </Badge>
  )
}
