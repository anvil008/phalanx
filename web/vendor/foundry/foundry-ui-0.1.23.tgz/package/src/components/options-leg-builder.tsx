import * as React from "react"
import { PlusIcon, Trash2Icon } from "lucide-react"
import { cn } from "../lib/utils"
import { Button } from "./button"
import { SegmentedControl } from "./segmented-control"

export interface OptionLeg {
  id: string
  action: "BUY" | "SELL"
  quantity: number
  type: "CALL" | "PUT"
  strike: number
  expiration: string
  price: number
  delta?: number
}

export interface OptionsLegBuilderProps {
  legs: OptionLeg[]
  onChange: (legs: OptionLeg[]) => void
  underlyingPrice?: number
  className?: string
}

export function OptionsLegBuilderTable({
  legs,
  onChange,
  underlyingPrice,
  className,
}: OptionsLegBuilderProps) {
  const addLeg = () => {
    const newLeg: OptionLeg = {
      id: String(Date.now()),
      action: "BUY",
      quantity: 1,
      type: "CALL",
      strike: underlyingPrice ? Math.round(underlyingPrice) : 100,
      expiration: "30 DTE",
      price: 2.50,
      delta: 0.50,
    }
    onChange([...legs, newLeg])
  }

  const removeLeg = (id: string) => {
    onChange(legs.filter((l) => l.id !== id))
  }

  const updateLeg = (id: string, updates: Partial<OptionLeg>) => {
    onChange(legs.map((l) => (l.id === id ? { ...l, ...updates } : l)))
  }

  const netCreditDebit = React.useMemo(() => {
    return legs.reduce((sum, leg) => {
      const mult = leg.action === "BUY" ? -1 : 1
      return sum + (leg.price * leg.quantity * 100 * mult)
    }, 0)
  }, [legs])

  return (
    <div
      data-slot="options-leg-builder"
      className={cn("flex flex-col rounded-lg border border-border bg-card overflow-hidden font-mono text-xs", className)}
    >
      <div className="flex items-center justify-between border-b border-hairline bg-well/60 px-4 py-2.5">
        <span className="font-semibold text-strong">Strategy Constructor</span>
        <Button variant="ghost" size="sm" onClick={addLeg} className="h-6 gap-1 px-2 text-xs">
          <PlusIcon className="size-3" />
          <span>Add Leg</span>
        </Button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-hairline bg-well/20 text-muted-foreground text-2xs uppercase">
              <th className="py-2 px-3">Side</th>
              <th className="py-2 px-3">Qty</th>
              <th className="py-2 px-3">Type</th>
              <th className="py-2 px-3">Strike</th>
              <th className="py-2 px-3">Expiry</th>
              <th className="py-2 px-3">Mid</th>
              <th className="py-2 px-3">Δ</th>
              <th className="py-2 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-hairline">
            {legs.map((leg) => (
              <tr key={leg.id} className="hover:bg-well/40">
                <td className="py-2 px-3">
                  <SegmentedControl
                    size="xs"
                    value={leg.action}
                    onChange={(val) => updateLeg(leg.id, { action: val as "BUY" | "SELL" })}
                    options={["BUY", "SELL"]}
                  />
                </td>
                <td className="py-2 px-3">
                  <input
                    type="number"
                    value={leg.quantity}
                    onChange={(e) => updateLeg(leg.id, { quantity: Math.max(1, parseInt(e.target.value) || 1) })}
                    className="w-12 bg-control border border-border rounded px-1.5 py-0.5 text-center font-bold text-strong"
                  />
                </td>
                <td className="py-2 px-3">
                  <SegmentedControl
                    size="xs"
                    value={leg.type}
                    onChange={(val) => updateLeg(leg.id, { type: val as "CALL" | "PUT" })}
                    options={["CALL", "PUT"]}
                  />
                </td>
                <td className="py-2 px-3">
                  <input
                    type="number"
                    value={leg.strike}
                    onChange={(e) => updateLeg(leg.id, { strike: parseFloat(e.target.value) || 0 })}
                    className="w-16 bg-control border border-border rounded px-1.5 py-0.5 font-bold text-strong"
                  />
                </td>
                <td className="py-2 px-3 text-secondary-foreground">{leg.expiration}</td>
                <td className="py-2 px-3 text-strong">${leg.price.toFixed(2)}</td>
                <td className="py-2 px-3 text-muted-foreground">{leg.delta ? leg.delta.toFixed(2) : "—"}</td>
                <td className="py-2 px-3 text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeLeg(leg.id)}
                    className="size-6 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2Icon className="size-3" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between border-t border-hairline bg-well/40 px-4 py-2 text-xs">
        <span className="text-muted-foreground">Net Position:</span>
        <span className={cn("font-bold text-sm", netCreditDebit >= 0 ? "text-positive" : "text-negative")}>
          {netCreditDebit >= 0 ? `Credit: +$${netCreditDebit.toFixed(2)}` : `Debit: -$${Math.abs(netCreditDebit).toFixed(2)}`}
        </span>
      </div>
    </div>
  )
}
