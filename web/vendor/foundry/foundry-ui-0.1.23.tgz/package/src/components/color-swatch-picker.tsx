import type { CSSProperties } from "react"

import { ToggleGroup, ToggleGroupItem } from "./toggle-group"

export function ColorSwatchPicker({
  value,
  onValueChange,
  onChange,
  colors,
  palette,
  label = "Choose color",
  disabled = false,
  className,
}: {
  value: string
  onValueChange?: (value: string) => void
  onChange?: (value: string) => void
  colors?: readonly string[]
  palette?: readonly string[]
  label?: string
  disabled?: boolean
  className?: string
}) {
  const activeColors = colors ?? palette ?? []
  const handleChange = onValueChange ?? onChange ?? (() => {})

  return (
    <ToggleGroup
      value={[value]}
      onValueChange={(nextValues) => {
        const nextValue = activeColors.find(
          (color) => color === nextValues.at(-1)
        )
        if (nextValue) handleChange(nextValue)
      }}
      disabled={disabled}
      spacing={1}
      variant="outline"
      aria-label={label}
      className={className}
    >
      {activeColors.map((color) => (
        <ToggleGroupItem
          key={color}
          value={color}
          aria-label={`${label}: ${color}`}
          className="size-7 p-0"
          style={{ "--swatch-color": color } as CSSProperties}
        >
          <span
            aria-hidden
            className="size-3 rounded-full border border-foreground/15 bg-[var(--swatch-color)]"
          />
        </ToggleGroupItem>
      ))}
    </ToggleGroup>
  )
}
