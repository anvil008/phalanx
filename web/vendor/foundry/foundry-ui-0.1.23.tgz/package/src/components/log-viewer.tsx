import * as React from "react"
import { CopyIcon, CheckIcon, ArrowDownIcon, SearchIcon } from "lucide-react"
import { cn } from "../lib/utils"
import { Button } from "./button"
import { Input } from "./input"

export interface LogEntry {
  id: string | number
  timestamp?: string | Date
  level?: "info" | "warn" | "error" | "debug" | "trace"
  source?: string
  message: string
}

export interface LogViewerProps {
  logs: LogEntry[]
  height?: number | string
  autoScroll?: boolean
  showLineNumbers?: boolean
  showTimestamps?: boolean
  showSearch?: boolean
  className?: string
}

export function LogViewer({
  logs,
  height = 360,
  autoScroll: defaultAutoScroll = true,
  showLineNumbers = true,
  showTimestamps = true,
  showSearch = true,
  className,
}: LogViewerProps) {
  const [copied, setCopied] = React.useState(false)
  const [filter, setFilter] = React.useState("")
  const [autoScroll, setAutoScroll] = React.useState(defaultAutoScroll)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  const filteredLogs = React.useMemo(() => {
    if (!filter) return logs
    const q = filter.toLowerCase()
    return logs.filter(
      (l) =>
        l.message.toLowerCase().includes(q) ||
        l.source?.toLowerCase().includes(q) ||
        l.level?.toLowerCase().includes(q)
    )
  }, [logs, filter])

  React.useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [filteredLogs, autoScroll])

  const copyAll = () => {
    const text = filteredLogs.map((l) => `${l.timestamp ? l.timestamp + " " : ""}[${l.level ?? "INFO"}] ${l.message}`).join("\n")
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const levelColor = (level?: string) => {
    switch (level) {
      case "error": return "text-destructive"
      case "warn": return "text-warning"
      case "debug": return "text-info"
      case "trace": return "text-subtle"
      default: return "text-secondary-foreground"
    }
  }

  return (
    <div
      data-slot="log-viewer"
      className={cn("flex flex-col rounded-lg border border-border bg-card overflow-hidden font-mono text-xs", className)}
    >
      {/* Log Header Toolbar */}
      <div className="flex items-center justify-between border-b border-hairline bg-well/60 px-3 py-2">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-strong">Console Logs</span>
          <span className="text-2xs text-muted-foreground">({filteredLogs.length} lines)</span>
        </div>

        <div className="flex items-center gap-2">
          {showSearch && (
            <div className="relative w-40">
              <SearchIcon className="absolute left-2 top-1/2 -translate-y-1/2 size-3 text-muted-foreground" />
              <Input
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                placeholder="Filter logs..."
                className="h-6 pl-6 text-xs"
              />
            </div>
          )}

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setAutoScroll(!autoScroll)}
            className={cn("h-6 gap-1 px-2 text-2xs", autoScroll ? "bg-primary-surface text-primary" : "text-muted-foreground")}
          >
            <ArrowDownIcon className="size-3" />
            <span>Follow</span>
          </Button>

          <Button variant="ghost" size="sm" onClick={copyAll} className="h-6 gap-1 px-2 text-2xs">
            {copied ? <CheckIcon className="size-3 text-positive" /> : <CopyIcon className="size-3" />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </Button>
        </div>
      </div>

      {/* Log Output Area */}
      <div
        ref={scrollRef}
        style={{ height }}
        className="overflow-y-auto p-3 space-y-1 font-mono text-xs leading-relaxed select-text"
      >
        {filteredLogs.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground">No log entries matching filter.</div>
        ) : (
          filteredLogs.map((log, idx) => (
            <div key={log.id ?? idx} className="flex items-start gap-2 hover:bg-well/40 px-1 rounded">
              {showLineNumbers && (
                <span className="w-8 text-right shrink-0 select-none text-muted-foreground/50">
                  {idx + 1}
                </span>
              )}
              {showTimestamps && log.timestamp && (
                <span className="text-subtle shrink-0 select-none">
                  {typeof log.timestamp === "string" ? log.timestamp : log.timestamp.toLocaleTimeString()}
                </span>
              )}
              {log.level && (
                <span className={cn("uppercase text-2xs font-semibold shrink-0 w-12", levelColor(log.level))}>
                  [{log.level}]
                </span>
              )}
              <span className={cn("break-all flex-1", levelColor(log.level))}>{log.message}</span>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
