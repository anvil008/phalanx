import * as React from "react"
import { cn } from "../lib/utils"

export interface PnlValueProps {
  value: number
  currency?: string
  percent?: number
  showSign?: boolean
  showColor?: boolean
  compact?: boolean
  className?: string
}

export function PnlValue({
  value,
  currency,
  percent,
  showSign = true,
  showColor = true,
  compact = false,
  className,
}: PnlValueProps) {
  const isPos = value > 0
  const isNeg = value < 0
  const isZero = value === 0

  const colorClass = !showColor
    ? "text-strong"
    : isPos
      ? "text-positive"
      : isNeg
        ? "text-negative"
        : "text-muted-foreground"

  const sign = showSign && isPos ? "+" : ""

  const formattedVal = React.useMemo(() => {
    const absVal = Math.abs(value)
    let formattedNumber = absVal.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })

    if (currency) {
      formattedNumber = `${currency} ${formattedNumber}`
    }

    if (isNeg) {
      return `-${formattedNumber}`
    }
    return `${sign}${formattedNumber}`
  }, [value, currency, isNeg, sign])

  return (
    <span
      data-slot="pnl-value"
      className={cn(
        "inline-flex items-baseline gap-1 font-mono font-medium tracking-tight",
        colorClass,
        className
      )}
    >
      <span>{formattedVal}</span>
      {percent !== undefined && (
        <span className="text-2xs font-normal opacity-80">
          ({isPos ? "+" : ""}{percent.toFixed(2)}%)
        </span>
      )}
    </span>
  )
}

export interface SlidingNumberProps {
  value: number
  precision?: number
  className?: string
}

export function SlidingNumber({
  value,
  precision = 2,
  className,
}: SlidingNumberProps) {
  return (
    <span className={cn("font-mono tabular-nums", className)}>
      {value.toFixed(precision)}
    </span>
  )
}
