import type { ReactNode } from "react"
import { ArrowDownRightIcon, ArrowUpRightIcon, MinusIcon } from "lucide-react"

import { Card, CardContent, CardHeader } from "./card"
import { cn } from "../lib/utils"

export function MetricCard({
  label,
  value,
  delta,
  trend = "up",
  icon,
  chart,
  className,
}: {
  label: string
  value: string
  delta?: string
  trend?: "up" | "down" | "flat"
  icon?: ReactNode
  chart?: ReactNode
  className?: string
}) {
  const TrendIcon =
    trend === "up" ? ArrowUpRightIcon : trend === "down" ? ArrowDownRightIcon : MinusIcon

  return (
    <Card className={cn("gap-0 overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-0">
        <span className="font-mono text-xs uppercase tracking-[0.14em] text-muted-foreground">
          {label}
        </span>
        {icon && <span className="text-muted-foreground">{icon}</span>}
      </CardHeader>
      <CardContent className="pt-2.5">
        <div className="flex items-end justify-between gap-3">
          <div>
            <div className="font-mono text-xl font-semibold tracking-[-0.035em] tabular-nums">{value}</div>
            {delta && (
              <div
                className={cn(
                  "mt-1 flex items-center gap-1 text-xs",
                  trend === "up" && "text-positive",
                  trend === "down" && "text-destructive",
                  trend === "flat" && "text-muted-foreground",
                )}
              >
                <TrendIcon className="size-3.5" />
                {delta}
              </div>
            )}
          </div>
          {chart && <div className="min-w-28 flex-1">{chart}</div>}
        </div>
      </CardContent>
    </Card>
  )
}
