import type { ReactNode } from "react"

import { cn } from "../lib/utils"

/* Terminal Glitch aberration colors */
const GHOST_CYAN = "#4cc9d9"
const GHOST_RED = "#f2565f"

export function ProductBrand({
  name,
  mark,
  compact = false,
  className,
}: {
  name: string
  mark: ReactNode
  descriptor?: ReactNode
  compact?: boolean
  className?: string
}) {
  const displayName = typeof name === "string" ? name.toLowerCase() : name

  return (
    <div
      data-slot="product-brand"
      className={cn(
        "inline-flex items-center gap-2.5 brand-glitch-interactive cursor-default",
        className
      )}
    >
      {mark}
      {!compact && (
        <span
          data-slot="product-brand-name"
          className="truncate font-mono text-[14px] font-semibold leading-none tracking-[0.02em] text-foreground brand-glitch-text"
          style={{
            textShadow: `-1.2px 0 ${GHOST_CYAN}b3, 1.2px 0 ${GHOST_RED}b3`,
          }}
        >
          {displayName}
        </span>
      )}
    </div>
  )
}

/**
 * Core Tile app-shell lockup based on shared UI 0.1.11 as vendored by Ledger
 * at 96270ef. Product-specific identity stays inside the mark.
 */
export function CoreTileProductBrand({
  name,
  mark,
  compact = false,
  className,
}: {
  name: string
  mark: ReactNode
  compact?: boolean
  className?: string
}) {
  return (
    <span
      data-slot="core-tile-product-brand"
      className={cn("inline-flex items-center gap-2.5", className)}
    >
      {mark}
      {!compact && (
        <span className="flex min-w-0 flex-col">
          <span
            data-slot="core-tile-product-brand-name"
            className="truncate text-[13.5px] font-semibold tracking-[-0.025em] text-strong"
          >
            {name}
          </span>
        </span>
      )}
    </span>
  )
}
