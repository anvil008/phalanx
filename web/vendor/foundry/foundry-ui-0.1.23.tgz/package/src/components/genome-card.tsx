import * as React from "react"
import { DnaIcon, BookOpenIcon, ExternalLinkIcon } from "lucide-react"
import { cn } from "../lib/utils"
import { StatusBadge } from "./status-badge"

export interface GenomeCardProps {
  gene: string
  rsid?: string
  genotype?: string
  traitName: string
  classification: string
  mechanism?: string
  clinicalGuidance?: string
  evidenceLevel?: string
  citations?: string[]
  className?: string
}

export function GenomeCard({
  gene,
  rsid,
  genotype,
  traitName,
  classification,
  mechanism,
  clinicalGuidance,
  evidenceLevel = "Level A",
  citations = [],
  className,
}: GenomeCardProps) {
  return (
    <div
      data-slot="genome-card"
      className={cn("flex flex-col gap-3 rounded-lg border border-border bg-card p-4 font-sans text-xs", className)}
    >
      {/* Header with Gene and RSID */}
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 font-mono text-xs font-bold text-primary bg-primary-surface px-2 py-0.5 rounded">
              <DnaIcon className="size-3" />
              {gene}
            </span>
            {genotype && (
              <span className="font-mono text-xs font-semibold text-strong bg-control px-2 py-0.5 rounded">
                {genotype}
              </span>
            )}
            {rsid && <span className="font-mono text-xs text-muted-foreground">{rsid}</span>}
          </div>
          <h4 className="text-sm font-semibold text-strong">{traitName}</h4>
        </div>
        <StatusBadge tone="info">{classification}</StatusBadge>
      </div>

      {mechanism && (
        <p className="text-muted-foreground leading-relaxed">{mechanism}</p>
      )}

      {clinicalGuidance && (
        <div className="rounded border border-primary/20 bg-primary-surface/10 p-2.5 text-xs leading-relaxed text-secondary-foreground">
          <span className="font-semibold text-primary block mb-0.5 font-mono text-2xs uppercase">
            Clinical Guidance
          </span>
          {clinicalGuidance}
        </div>
      )}

      <div className="flex items-center justify-between pt-2 border-t border-hairline font-mono text-2xs text-subtle">
        <span>Evidence: {evidenceLevel}</span>
        {citations.length > 0 && <span>{citations.length} CPIC / ClinVar source(s)</span>}
      </div>
    </div>
  )
}
