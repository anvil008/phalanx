import * as React from "react"
import { LockIcon } from "lucide-react"
import { cn } from "../lib/utils"

export function FinancialGridTodayDivider({ className }: { className?: string }) {
  return (
    <div
      data-slot="financial-grid-today-divider"
      className={cn("w-0.5 bg-primary absolute top-0 bottom-0 z-10 pointer-events-none shadow-sm", className)}
    />
  )
}

export function FinancialGridLockedCell({
  children,
  reason = "Statement frozen",
  className,
}: {
  children: React.ReactNode
  reason?: string
  className?: string
}) {
  return (
    <div
      data-slot="financial-grid-locked-cell"
      title={reason}
      className={cn("relative flex items-center justify-between gap-1 bg-well/40 text-muted-foreground px-2 py-1 select-none", className)}
    >
      <span className="truncate">{children}</span>
      <LockIcon className="size-3 text-subtle shrink-0 opacity-70" />
    </div>
  )
}

export function FinancialGridDueMarker({
  status = "scheduled",
  label,
  className,
}: {
  status?: "overdue" | "due-today" | "due-soon" | "scheduled" | "paid"
  label?: string
  className?: string
}) {
  const toneMap = {
    overdue: "bg-destructive text-destructive-foreground",
    "due-today": "bg-warning text-warning-foreground font-bold",
    "due-soon": "bg-warning/20 text-warning",
    scheduled: "bg-control text-muted-foreground",
    paid: "bg-positive/20 text-positive",
  }[status]

  return (
    <span
      data-slot="financial-grid-due-marker"
      className={cn("inline-flex items-center px-1.5 py-0.5 rounded font-mono text-2xs uppercase", toneMap, className)}
    >
      {label ?? status}
    </span>
  )
}
