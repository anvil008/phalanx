import * as React from "react"
import { ShieldAlertIcon, CheckCircleIcon, XCircleIcon, TerminalIcon, HashIcon } from "lucide-react"
import { cn } from "../lib/utils"
import { Button } from "./button"
import { StatusBadge } from "./status-badge"

export type GovernanceTier = "tier_0" | "tier_1" | "tier_2" | "tier_3"
export type ApprovalStatus = "pending" | "approved" | "rejected" | "executing" | "completed" | "expired"

export interface ApprovalRequest {
  id: string
  title: string
  tier: GovernanceTier
  status: ApprovalStatus
  sourceAgent: string
  timestamp: string | Date
  targetResource: string
  sha256Digest?: string
  payloadJson?: string
  summary: string
}

export interface ApprovalInspectionPanelProps {
  request: ApprovalRequest
  onApprove?: (id: string) => void
  onReject?: (id: string) => void
  className?: string
}

export function ApprovalInspectionPanel({
  request,
  onApprove,
  onReject,
  className,
}: ApprovalInspectionPanelProps) {
  const isPending = request.status === "pending"

  const tierBadge = {
    tier_3: { label: "TIER 3 · HARD FLOOR", tone: "error" as const },
    tier_2: { label: "TIER 2 · QUORUM", tone: "warning" as const },
    tier_1: { label: "TIER 1 · SUPERVISOR", tone: "info" as const },
    tier_0: { label: "TIER 0 · AUTO", tone: "online" as const },
  }[request.tier]

  return (
    <div
      data-slot="approval-inspection-panel"
      className={cn("flex flex-col rounded-lg border border-border bg-card overflow-hidden font-mono text-xs", className)}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-hairline bg-well/60 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <ShieldAlertIcon className="size-4 text-warning" />
          <span className="font-semibold text-strong text-sm">Action Approval Inspection</span>
          <StatusBadge tone={tierBadge.tone}>{tierBadge.label}</StatusBadge>
        </div>
        <span className="text-2xs text-muted-foreground">{request.id}</span>
      </div>

      {/* Body Details */}
      <div className="p-4 space-y-3 font-sans text-xs">
        <div>
          <div className="text-xs font-semibold text-strong uppercase font-mono tracking-wider text-muted-foreground">Action Summary</div>
          <div className="text-sm font-medium text-strong mt-0.5">{request.title}</div>
          <div className="text-muted-foreground mt-1 leading-relaxed">{request.summary}</div>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-2 border-t border-hairline font-mono text-xs">
          <div>
            <span className="text-muted-foreground">Source Agent:</span>
            <div className="font-semibold text-strong">{request.sourceAgent}</div>
          </div>
          <div>
            <span className="text-muted-foreground">Target Resource:</span>
            <div className="font-semibold text-strong">{request.targetResource}</div>
          </div>
        </div>

        {request.sha256Digest && (
          <div className="pt-2 border-t border-hairline font-mono text-xs">
            <div className="flex items-center gap-1 text-muted-foreground">
              <HashIcon className="size-3" />
              <span>SHA-256 Digest Verification:</span>
            </div>
            <div className="bg-well p-1.5 rounded mt-1 break-all text-secondary-foreground select-all text-2xs">
              {request.sha256Digest}
            </div>
          </div>
        )}

        {request.payloadJson && (
          <div className="pt-2 border-t border-hairline font-mono">
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
              <TerminalIcon className="size-3" />
              <span>Admitted Payload (Immutable):</span>
            </div>
            <pre className="bg-well p-2.5 rounded overflow-auto max-h-48 text-2xs leading-tight text-secondary-foreground select-text">
              {request.payloadJson}
            </pre>
          </div>
        )}
      </div>

      {/* Decision Footer */}
      {isPending && (
        <div className="flex items-center justify-end gap-2 border-t border-hairline bg-well/40 px-4 py-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onReject?.(request.id)}
            className="h-8 gap-1.5 text-xs text-destructive hover:bg-destructive/10 border-destructive/30"
          >
            <XCircleIcon className="size-3.5" />
            <span>Reject Action</span>
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => onApprove?.(request.id)}
            className="h-8 gap-1.5 text-xs bg-positive hover:bg-positive/90 text-positive-foreground font-semibold"
          >
            <CheckCircleIcon className="size-3.5" />
            <span>Authorize Execution</span>
          </Button>
        </div>
      )}
    </div>
  )
}
