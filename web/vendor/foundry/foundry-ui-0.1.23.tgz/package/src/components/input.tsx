import * as React from "react"
import { Input as InputPrimitive } from "@base-ui/react/input"

import { cn } from "../lib/utils"
import { formControlVariants, type FormControlVariantProps } from "../lib/form-control"
import { useFieldContext } from "./field"

export interface InputProps
  extends Omit<React.ComponentProps<"input">, "size">,
    FormControlVariantProps {}

function Input({ className, type, controlSize = "default", variant = "default", ...props }: InputProps) {
  const fieldContext = useFieldContext()
  const id = props.id || (fieldContext.fieldId ? `${fieldContext.fieldId}-control` : undefined)
  const ariaInvalid = props["aria-invalid"] ?? (fieldContext.invalid ? true : undefined)
  const ariaDescribedBy =
    props["aria-describedby"] ||
    (fieldContext.invalid && fieldContext.errorId
      ? fieldContext.errorId
      : fieldContext.descriptionId || undefined)

  return (
    <InputPrimitive
      type={type}
      id={id}
      data-slot="input"
      aria-invalid={ariaInvalid}
      aria-describedby={ariaDescribedBy}
      disabled={props.disabled ?? fieldContext.disabled}
      className={cn(
        "rounded-control",
        formControlVariants({ controlSize, variant }),
        "[&[inputmode=decimal]]:font-mono [&[inputmode=decimal]]:tabular-nums [&[inputmode=numeric]]:font-mono [&[inputmode=numeric]]:tabular-nums file:inline-flex file:h-6 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground",
        className
      )}
      {...props}
    />
  )
}

export { Input }
