import {
  useMemo,
  useState,
  type ComponentProps,
  type CSSProperties,
  type Key,
  type ReactNode,
} from "react"

import { cn } from "../lib/utils"
import { tableSurfaceClass, tableSurfaceStyle } from "../lib/table-surface"

export function MicroLabel({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        "font-sans text-2xs leading-none font-semibold tracking-[0.16em] text-subtle uppercase",
        className
      )}
    >
      {children}
    </div>
  )
}

export function Panel({
  children,
  flush = false,
  className,
  ...props
}: ComponentProps<"section"> & {
  flush?: boolean
}) {
  return (
    <section
      {...props}
      data-slot="panel"
      className={cn(
        "rounded-lg border border-border bg-card",
        flush ? "overflow-hidden" : "px-5 py-[18px]",
        className
      )}
    >
      {children}
    </section>
  )
}

export function PanelSection({
  label,
  description,
  trailing,
  children,
  open = true,
  onToggle,
  className,
  bodyClassName,
}: {
  label: ReactNode
  description?: ReactNode
  trailing?: ReactNode
  children: ReactNode
  open?: boolean
  onToggle?: () => void
  className?: string
  bodyClassName?: string
}) {
  const interactive = typeof onToggle === "function"
  const heading = (
    <div className="flex min-h-12 items-center justify-between gap-5 px-[18px] py-3">
      <div className="min-w-0">
        <span className="flex items-center gap-2">
          {interactive && (
            <span aria-hidden className="w-2.5 text-xs text-subtle">
              {open ? "▾" : "▸"}
            </span>
          )}
          {typeof label === "string" ? <MicroLabel>{label}</MicroLabel> : label}
        </span>
        {description && (
          <div className={cn("mt-1 text-xs text-muted-foreground", interactive && "pl-[18px]")}>
            {description}
          </div>
        )}
      </div>
      {trailing}
    </div>
  )

  return (
    <Panel flush className={className}>
      {interactive ? (
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          className="w-full text-left transition-colors hover:bg-background"
        >
          {heading}
        </button>
      ) : (
        heading
      )}
      {open && (
        <div className={cn("border-t border-hairline", bodyClassName)}>
          {children}
        </div>
      )}
    </Panel>
  )
}

export function RailLayout({
  children,
  rail,
  railWidth = 320,
  className,
}: {
  children: ReactNode
  rail: ReactNode
  railWidth?: 300 | 320 | 340
  className?: string
}) {
  return (
    <div
      data-slot="rail-layout"
      className={cn(
        "grid grid-cols-1 content-start gap-4 xl:grid-cols-[minmax(0,1fr)_var(--rail-width)]",
        className
      )}
      style={{ "--rail-width": `${railWidth}px` } as CSSProperties}
    >
      <div className="flex min-w-0 flex-col gap-4">{children}</div>
      <aside className="flex min-w-0 flex-col gap-4">{rail}</aside>
    </div>
  )
}

export function StatGrid({
  children,
  columns = 4,
  divided = true,
  gap = "md",
  className,
}: {
  children: ReactNode
  columns?: 2 | 3 | 4 | 5
  divided?: boolean
  gap?: "none" | "sm" | "md"
  className?: string
}) {
  return (
    <div
      data-slot="stat-grid"
      data-divided={divided}
      className={cn(
        "grid grid-cols-2 md:grid-cols-[repeat(var(--stat-columns),minmax(0,1fr))]",
        !divided && gap === "sm" && "gap-2",
        !divided && gap === "md" && "gap-3.5",
        divided &&
          "[&>*:nth-child(even)]:border-l [&>*:nth-child(even)]:border-hairline md:[&>*+*]:border-l md:[&>*+*]:border-hairline",
        className
      )}
      style={{ "--stat-columns": columns } as CSSProperties}
    >
      {children}
    </div>
  )
}

export function StatTile({
  label,
  value,
  sub,
  tone = "default",
  bare = false,
  framed = false,
  size = "md",
  className,
}: {
  label: ReactNode
  value: ReactNode
  sub?: ReactNode
  tone?: "default" | "positive" | "negative" | "muted"
  bare?: boolean
  framed?: boolean
  size?: "sm" | "md"
  className?: string
}) {
  const content = (
    <>
      <MicroLabel className={size === "sm" ? "truncate text-2xs" : undefined}>
        {label}
      </MicroLabel>
      <div
        className={cn(
          "font-mono leading-none font-semibold tracking-[-0.035em] tabular-nums",
          size === "sm" ? "mt-1 text-base" : "mt-2 text-xl",
          tone === "default" && "text-strong",
          tone === "positive" && "text-positive",
          tone === "negative" && "text-negative",
          tone === "muted" && "text-muted-foreground"
        )}
      >
        {value}
      </div>
      {sub && <div className="mt-1.5 text-2xs text-muted-foreground">{sub}</div>}
    </>
  )

  const tile = (
    <div
      data-slot="stat-tile"
      data-bare={bare}
      data-size={size}
      className={cn(
        "min-w-0",
        !bare && !framed && "px-4 py-3.5",
        !framed && className
      )}
    >
      {content}
    </div>
  )

  return framed ? <Panel className={className}>{tile}</Panel> : tile
}

export function KeyValueList({
  rows,
  total,
  className,
}: {
  rows: { label: ReactNode; value: ReactNode }[]
  total?: { label: ReactNode; value: ReactNode }
  className?: string
}) {
  return (
    <div className={className}>
      {rows.map((row, index) => (
        <div
          key={index}
          className="flex items-center justify-between gap-4 border-b border-hairline py-2 text-sm text-muted-foreground"
        >
          <span>{row.label}</span>
          <div className="min-w-0 font-mono text-foreground tabular-nums">
            {row.value}
          </div>
        </div>
      ))}
      {total && (
        <div className="flex items-center justify-between gap-4 pt-3 pb-1 text-sm font-semibold text-strong">
          <span>{total.label}</span>
          <div className="min-w-0 font-mono tabular-nums">{total.value}</div>
        </div>
      )}
    </div>
  )
}

type DataGridCellRenderer<Row> =
  | {
      render: (row: Row, index: number) => ReactNode
      cell?: never
    }
  | {
      /** Compatibility name for applications migrating an existing grid. */
      cell: (row: Row, index: number) => ReactNode
      render?: never
    }

type DataGridColumnBase = {
  key: string
  header: ReactNode
  width: string
  align?: "start" | "center" | "end" | "left" | "right"
}

/**
 * Every data column is sortable. Selection and row-action columns must opt
 * into `kind: "control"` so an unsortable header is always an explicit,
 * reviewable exception rather than an accidental omission.
 */
export type DataGridColumn<Row> = DataGridColumnBase &
  DataGridCellRenderer<Row> &
  (
    | {
        kind?: "data"
        sortValue: (row: Row) => DataGridSortValue
      }
    | {
        kind: "control"
        sortValue?: never
      }
  )

export type DataGridGroup<Row> = {
  key: string
  rows: Row[]
}

export type DataGridSortValue =
  | string
  | number
  | boolean
  | Date
  | null
  | undefined
export type DataGridSortDirection = "ascending" | "descending"
export type DataGridSort = {
  key: string
  direction: DataGridSortDirection
}

export type DataGridProps<Row> = {
  columns: DataGridColumn<Row>[]
  rows: Row[]
  rowKey: (row: Row, index: number) => Key
  minWidth?: number
  defaultSort?: DataGridSort | null
  /** Supply with `onSortChange` when sorting is owned by a query or parent. */
  sort?: DataGridSort | null
  onSortChange?: (sort: DataGridSort) => void
  onRowClick?: (row: Row) => void
  groupOf?: (row: Row) => string
  renderGroup?: (group: string, rowsInGroup: Row[]) => ReactNode
  empty?: ReactNode
  bare?: boolean
  dense?: boolean
  stickyHeader?: boolean
  className?: string
}

function columnSortValue<Row>(column: DataGridColumn<Row>) {
  return column.kind === "control" ? undefined : column.sortValue
}

function renderDataGridCell<Row>(
  column: DataGridColumn<Row>,
  row: Row,
  index: number
) {
  return "render" in column && column.render
    ? column.render(row, index)
    : column.cell(row, index)
}

function dataGridAlignment(align: DataGridColumnBase["align"]) {
  if (align === "end" || align === "right") return "text-right justify-end"
  if (align === "center") return "text-center justify-center"
  return "text-left justify-start"
}

function groupDataGridRows<Row>(
  rows: Row[],
  groupOf: (row: Row) => string
): DataGridGroup<Row>[] {
  const groups: DataGridGroup<Row>[] = []

  for (const row of rows) {
    const key = groupOf(row)
    const previous = groups.at(-1)
    if (previous?.key === key) previous.rows.push(row)
    else groups.push({ key, rows: [row] })
  }

  return groups
}

function compareDataGridValues(
  left: DataGridSortValue,
  right: DataGridSortValue,
  direction: DataGridSortDirection
) {
  if (Object.is(left, right)) return 0
  if (left == null) return 1
  if (right == null) return -1

  const normalizedLeft = left instanceof Date ? left.getTime() : left
  const normalizedRight = right instanceof Date ? right.getTime() : right

  let result: number

  if (typeof normalizedLeft === "number" && typeof normalizedRight === "number") {
    result = normalizedLeft - normalizedRight
  } else if (typeof normalizedLeft === "boolean" && typeof normalizedRight === "boolean") {
    result = Number(normalizedLeft) - Number(normalizedRight)
  } else {
    result = String(normalizedLeft).localeCompare(String(normalizedRight), undefined, {
      numeric: true,
      sensitivity: "base",
    })
  }

  return direction === "ascending" ? result : -result
}

export function DataGrid<Row>({
  columns,
  rows,
  rowKey,
  minWidth,
  defaultSort = null,
  sort: controlledSort,
  onSortChange,
  onRowClick,
  groupOf,
  renderGroup,
  empty = "Nothing here.",
  bare = false,
  dense = false,
  stickyHeader = false,
  className,
}: DataGridProps<Row>) {
  const tracks = columns.map((column) => column.width).join(" ")
  const [uncontrolledSort, setUncontrolledSort] = useState<DataGridSort | null>(
    defaultSort
  )
  const sort = controlledSort === undefined ? uncontrolledSort : controlledSort
  const activeColumn =
    sort == null
      ? undefined
      : columns.find(
          (column) =>
            column.kind !== "control" &&
            column.key === sort.key
        )
  const sortedRows = useMemo(() => {
    const sortValue = activeColumn
      ? columnSortValue(activeColumn)
      : undefined
    if (!sort || !sortValue) return rows

    return rows
      .map((row, index) => ({ row, index }))
      .sort((left, right) => {
        const comparison = compareDataGridValues(
          sortValue(left.row),
          sortValue(right.row),
          sort.direction
        )

        return comparison || left.index - right.index
      })
      .map(({ row }) => row)
  }, [activeColumn, rows, sort])

  const changeSort = (column: DataGridColumn<Row>) => {
    if (column.kind === "control") return

    const nextSort: DataGridSort = {
      key: column.key,
      direction:
        sort?.key === column.key && sort.direction === "ascending"
          ? "descending"
          : "ascending",
    }

    if (controlledSort === undefined) setUncontrolledSort(nextSort)
    onSortChange?.(nextSort)
  }

  const renderRow = (row: Row, index: number) => (
    <div
      key={rowKey(row, index)}
      role="row"
      tabIndex={onRowClick ? 0 : undefined}
      onClick={() => onRowClick?.(row)}
      onKeyDown={(event) => {
        if (onRowClick && (event.key === "Enter" || event.key === " ")) {
          event.preventDefault()
          onRowClick(row)
        }
      }}
      className={cn(
        `grid items-center border-b border-hairline ${tableSurfaceClass} transition-colors last:border-b-0 hover:bg-well`,
        dense ? "gap-2 px-3 py-2" : "gap-3.5 px-[18px] py-2.5",
        onRowClick && "cursor-pointer"
      )}
      style={{ ...tableSurfaceStyle("base"), gridTemplateColumns: tracks }}
    >
      {columns.map((column) => (
        <div
          key={column.key}
          role="cell"
          className={cn(
            "flex min-w-0 items-center",
            dataGridAlignment(column.align)
          )}
        >
          {renderDataGridCell(column, row, index)}
        </div>
      ))}
    </div>
  )

  let body: ReactNode

  if (sortedRows.length === 0) {
    body = (
      <div className="px-[18px] py-10 text-center text-base text-subtle">
        {empty}
      </div>
    )
  } else if (groupOf) {
    body = groupDataGridRows(sortedRows, groupOf).map((group) => (
      <div key={group.key} role="rowgroup">
        {renderGroup ? (
          renderGroup(group.key, group.rows)
        ) : (
          <DataGridGroupBand label={group.key} />
        )}
        {group.rows.map(renderRow)}
      </div>
    ))
  } else {
    body = <div role="rowgroup">{sortedRows.map(renderRow)}</div>
  }

  return (
    <div
      data-slot="data-grid"
      role="table"
      className={cn(
        "overflow-x-auto bg-card",
        !bare && "rounded-lg border border-border",
        className
      )}
    >
      <div style={minWidth ? { minWidth } : undefined}>
        <div
          role="row"
          className={cn(
            `grid items-center border-b border-border ${tableSurfaceClass}`,
            dense ? "gap-2 px-3 py-2.5" : "gap-3.5 px-[18px] py-3",
            stickyHeader && "sticky top-0 z-10"
          )}
          style={{ ...tableSurfaceStyle("structural"), gridTemplateColumns: tracks }}
        >
          {columns.map((column) => {
            const isControl = column.kind === "control"
            const isActive = sort?.key === column.key

            return (
              <div
                key={column.key}
                role="columnheader"
                aria-sort={
                  isControl
                    ? undefined
                    : isActive
                      ? sort.direction
                      : "none"
                }
                className={cn(
                  "flex min-w-0 items-center",
                  dataGridAlignment(column.align)
                )}
              >
                {isControl ? (
                  column.header
                ) : (
                  <button
                    type="button"
                    onClick={() => changeSort(column)}
                    className={cn(
                      "group flex w-full min-w-0 min-h-[28px] bg-transparent py-1 px-1.5 rounded-control cursor-pointer items-center font-sans text-2xs font-semibold tracking-[0.12em] uppercase transition-colors hover:bg-transparent hover:text-foreground active:bg-transparent focus-visible:outline-1 focus-visible:-outline-offset-1 focus-visible:outline-ring",
                      isActive ? "text-foreground font-bold" : "text-faint",
                      dataGridAlignment(column.align)
                    )}
                  >
                    <span className="min-w-0 truncate">{column.header}</span>
                    {isActive && (
                      <span
                        aria-hidden
                        className="ml-1 shrink-0 font-mono text-2xs leading-none text-primary-surface-foreground"
                      >
                        {sort.direction === "ascending" ? "↑" : "↓"}
                      </span>
                    )}
                  </button>
                )}
              </div>
            )
          })}
        </div>
        {body}
      </div>
    </div>
  )
}

/**
 * Shared structural surface for grouped table rows, including bespoke
 * multi-column group rows that are not rendered by DataGrid itself.
 */
export function DataGridGroupRow({
  className,
  style,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="data-grid-group-row"
      className={cn(
        `border-b border-hairline ${tableSurfaceClass}`,
        className,
      )}
      style={{ ...tableSurfaceStyle("structural"), ...style }}
      {...props}
    />
  )
}

export function DataGridGroupBand({
  label,
  trailing,
  className,
  role = "row",
  ...props
}: {
  label: ReactNode
  trailing?: ReactNode
} & React.ComponentProps<"div">) {
  return (
    <DataGridGroupRow
      data-slot="data-grid-group"
      role={role}
      className={cn(
        "flex items-center justify-between px-[18px] py-1.5",
        className
      )}
      {...props}
    >
      <span
        role={role === "row" ? "cell" : undefined}
        className="text-xs font-medium text-muted-foreground"
      >
        {label}
      </span>
      {trailing === undefined ? null : (
        <span role={role === "row" ? "cell" : undefined}>{trailing}</span>
      )}
    </DataGridGroupRow>
  )
}

/** Backwards-compatible name for a standardized DataGrid group row. */
export const GroupBand = DataGridGroupBand
