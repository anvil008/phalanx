import * as React from "react"
import { cn } from "../lib/utils"
import { getToneDotClasses, normalizeTone, type StatusToneInput } from "../lib/status-intent"

export type StatusDotTone =
  | "neutral"
  | "positive"
  | "negative"
  | "warning"
  | "info"
  | "faint"

export interface StatusDotProps extends React.ComponentProps<"span"> {
  tone?: StatusToneInput
  pulse?: boolean
  size?: "xs" | "sm" | "md"
}

export function StatusDot({
  className,
  tone = "neutral",
  pulse = false,
  size = "sm",
  ...props
}: StatusDotProps) {
  const sizeMap = {
    xs: "size-1.5",
    sm: "size-2",
    md: "size-2.5",
  }[size]

  const normalizedTone = normalizeTone(tone)
  const toneClasses = getToneDotClasses(tone)

  return (
    <span
      data-slot="status-dot"
      data-tone={normalizedTone}
      data-pulse={pulse ? "true" : undefined}
      className={cn("relative inline-flex items-center justify-center shrink-0", sizeMap, className)}
      {...props}
    >
      <span className={cn("size-full rounded-full", toneClasses.dot)} />
      {pulse && (
        <span
          className={cn(
            "absolute -inset-0.5 rounded-full border animate-ping pointer-events-none",
            toneClasses.pulse
          )}
        />
      )}
    </span>
  )
}
