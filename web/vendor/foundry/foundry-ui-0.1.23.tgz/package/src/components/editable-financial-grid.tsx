import * as React from "react";
import { ChevronDown, ChevronRight } from "lucide-react";

import { Button } from "./button";
import { DisclosureButton } from "./disclosure-button";
import { Input } from "./input";
import {
  tableInteractiveSurfaceClass,
  tableSurfaceClass,
  tableSurfaceInteractionStyle,
  tableSurfaceStyle,
} from "../lib/table-surface";
import { cn } from "../lib/utils";

type BandVariant = "section" | "total";

/**
 * A row-owned surface is inherited by its cells. This lets a band remain
 * continuous under both ordinary and sticky cells without falling back to the
 * page's black background while horizontally scrolling.
 */
export function financialGridBandStyle(
  _variant: BandVariant,
): React.CSSProperties {
  return tableSurfaceStyle("structural");
}

const financialGridSurfaceClass = tableSurfaceClass;

export function FinancialGridFrame({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="financial-grid-frame"
      className={cn(
        "min-w-0 overflow-x-auto rounded-lg border border-border bg-card text-card-foreground",
        className,
      )}
      {...props}
    />
  );
}

export function FinancialGridTable({
  className,
  ...props
}: React.ComponentProps<"table">) {
  return (
    <table
      data-slot="financial-grid-table"
      className={cn("w-max min-w-full border-collapse bg-card text-sm", className)}
      {...props}
    />
  );
}

/** Base/detail row with a continuous hover surface across opaque cells. */
export function FinancialGridDetailRow({
  className,
  style,
  ...props
}: React.ComponentProps<"tr">) {
  return (
    <tr
      data-slot="financial-grid-detail-row"
      className={cn(
        tableInteractiveSurfaceClass,
        "border-b border-border/40 transition-colors last:border-b-0",
        className,
      )}
      style={{ ...tableSurfaceInteractionStyle("base"), ...style }}
      {...props}
    />
  );
}

export function FinancialGridCell({
  className,
  ...props
}: React.ComponentProps<"td">) {
  return (
    <td
      data-slot="financial-grid-cell"
      className={cn(
        `border-r border-border/40 ${financialGridSurfaceClass} px-4 py-1 text-right tabular-nums whitespace-nowrap`,
        className,
      )}
      {...props}
    />
  );
}

/** Semantic body label. Set `sticky` for the pinned first column. */
export function FinancialGridRowHeader({
  className,
  scope = "row",
  sticky = false,
  ...props
}: React.ComponentProps<"th"> & { sticky?: boolean }) {
  return (
    <th
      data-slot="financial-grid-row-header"
      scope={scope}
      className={cn(
        `border-r border-border/40 ${financialGridSurfaceClass} px-4 py-1 text-left font-normal whitespace-nowrap`,
        sticky && "sticky left-0 z-10 min-w-60",
        className,
      )}
      {...props}
    />
  );
}

export function FinancialGridHeaderCell({
  className,
  style,
  ...props
}: React.ComponentProps<"th">) {
  return (
    <th
      data-slot="financial-grid-header-cell"
      className={cn(
        `border-r border-border/40 ${financialGridSurfaceClass} px-4 py-2.5 text-right text-xs font-medium text-muted-foreground whitespace-nowrap`,
        className,
      )}
      style={{ ...tableSurfaceStyle("structural"), ...style }}
      {...props}
    />
  );
}

export function FinancialGridStickyCell({
  className,
  band,
  style,
  ...props
}: React.ComponentProps<"td"> & { band?: BandVariant }) {
  return (
    <td
      data-slot="financial-grid-sticky-cell"
      className={cn(
        `sticky left-0 z-10 min-w-60 border-r border-border/40 ${financialGridSurfaceClass} px-4 py-1`,
        className,
      )}
      style={{
        ...(band ? financialGridBandStyle(band) : undefined),
        ...style,
      }}
      {...props}
    />
  );
}

export function FinancialGridStickyHeaderCell({
  className,
  style,
  ...props
}: React.ComponentProps<"th">) {
  return (
    <th
      data-slot="financial-grid-sticky-header-cell"
      className={cn(
        `sticky left-0 z-10 min-w-60 border-r border-border/40 ${financialGridSurfaceClass} px-4 py-2.5 text-left text-xs font-medium text-muted-foreground`,
        className,
      )}
      style={{ ...tableSurfaceStyle("structural"), ...style }}
      {...props}
    />
  );
}

export function FinancialGridBandRow({
  variant = "section",
  className,
  style,
  ...props
}: React.ComponentProps<"tr"> & { variant?: BandVariant }) {
  return (
    <tr
      data-slot="financial-grid-band-row"
      data-variant={variant}
      className={cn(
        variant === "section"
          ? "border-b border-border/50"
          : "border-b-2 border-border font-semibold",
        className,
      )}
      style={{ ...financialGridBandStyle(variant), ...style }}
      {...props}
    />
  );
}

export function FinancialGridDisclosureButton({
  expanded,
  children,
  className,
  ...props
}: Omit<React.ComponentProps<typeof Button>, "variant" | "size"> & {
  expanded: boolean;
}) {
  const Chevron = expanded ? ChevronDown : ChevronRight;
  return (
    <DisclosureButton
      type="button"
      size="xs"
      aria-expanded={expanded}
      className={cn(
        "min-w-0 justify-start gap-1 border-0 px-0 py-0 text-left text-foreground",
        className,
      )}
      {...props}
    >
      <Chevron className="size-3.5 shrink-0 text-muted-foreground" />
      {children}
    </DisclosureButton>
  );
}

export function FinancialGridActionButton({
  className,
  ...props
}: Omit<React.ComponentProps<typeof Button>, "variant" | "size">) {
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon-xs"
      className={cn(
        "shrink-0 text-muted-foreground hover:text-foreground",
        className,
      )}
      {...props}
    />
  );
}

export function FinancialGridField({
  prefix,
  className,
  children,
  ...props
}: React.ComponentProps<"span"> & { prefix?: React.ReactNode }) {
  return (
    <span
      data-slot="financial-grid-field"
      className={cn(
        "inline-flex min-h-7 items-center gap-1 rounded-control border border-border bg-control px-2 py-0.5 focus-within:border-ring focus-within:ring-2 focus-within:ring-ring/25",
        className,
      )}
      {...props}
    >
      {prefix === undefined ? null : (
        <span className="text-xs text-faint" aria-hidden>
          {prefix}
        </span>
      )}
      {children}
    </span>
  );
}

export function FinancialGridInput({
  className,
  ...props
}: React.ComponentProps<typeof Input>) {
  return (
    <Input
      data-slot="financial-grid-input"
      className={cn("h-7 min-w-0 rounded-control px-2 py-1 text-xs", className)}
      {...props}
    />
  );
}

export function FinancialGridRowActions({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="financial-grid-row-actions"
      className={cn("flex shrink-0 items-center gap-0.5", className)}
      {...props}
    />
  );
}
