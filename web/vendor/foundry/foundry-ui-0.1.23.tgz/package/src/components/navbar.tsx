import React, { useState } from "react"
import { ChevronDownIcon, MenuIcon, XIcon } from "lucide-react"

import { cn } from "../lib/utils"
import { Button } from "./button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./dropdown-menu"

export interface NavbarSubmenuItem {
  label: string
  href?: string
  description?: string
  icon?: React.ComponentType<{ className?: string }>
  badge?: string
  onClick?: () => void
  disabled?: boolean
}

export interface NavbarNavItem {
  id: string
  label: string
  href?: string
  isActive?: boolean
  onClick?: () => void
  items?: NavbarSubmenuItem[]
}

export interface NavbarProps extends Omit<React.HTMLAttributes<HTMLElement>, "onSelect"> {
  brand?: React.ReactNode
  items?: NavbarNavItem[]
  actions?: React.ReactNode
  activeId?: string
  onSelect?: (id: string, item?: NavbarNavItem | NavbarSubmenuItem) => void
  compact?: boolean
  bordered?: boolean
}

export function Navbar({
  brand,
  items = [],
  actions,
  activeId,
  onSelect,
  compact = false,
  bordered = true,
  className,
  ...props
}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header
      data-slot="navbar"
      className={cn(
        "relative z-30 flex w-full items-center justify-between bg-sidebar px-4 transition-colors",
        compact ? "h-11" : "h-(--chrome-height)",
        bordered && "border-b border-sidebar-border",
        className
      )}
      {...props}
    >
      {/* Brand area */}
      <div className="flex items-center gap-6">
        {brand && <div data-slot="navbar-brand" className="flex items-center">{brand}</div>}

        {/* Desktop Primary Nav Links with Sub-menus */}
        <nav data-slot="navbar-nav" aria-label="Primary navigation" className="hidden md:flex items-center gap-1">
          {items.map((item) => {
            const isItemActive = activeId === item.id || item.isActive

            if (item.items && item.items.length > 0) {
              return (
                <DropdownMenu key={item.id}>
                  <DropdownMenuTrigger
                    render={
                      <Button
                        variant="ghost"
                        size={compact ? "sm" : "default"}
                        className={cn(
                          "gap-1.5 px-2.5 text-xs font-medium transition-colors cursor-pointer",
                          isItemActive
                            ? "bg-sidebar-accent text-sidebar-accent-foreground font-semibold"
                            : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
                        )}
                        aria-expanded={undefined}
                      />
                    }
                  >
                    <span>{item.label}</span>
                    <ChevronDownIcon className="size-3.5 opacity-60 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align="start"
                    sideOffset={6}
                    className="w-56 p-1.5 shadow-glass-menu border border-sidebar-border bg-popover/95 backdrop-blur-md"
                  >
                    <DropdownMenuLabel className="px-2 py-1 text-2xs uppercase font-mono tracking-wider text-muted-foreground/70">
                      {item.label}
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator className="my-1" />
                    <DropdownMenuGroup>
                      {item.items.map((subItem, idx) => {
                        const Icon = subItem.icon
                        return (
                          <DropdownMenuItem
                            key={subItem.label ?? idx}
                            disabled={subItem.disabled}
                            onClick={() => {
                              subItem.onClick?.()
                              onSelect?.(item.id, subItem)
                            }}
                            className="flex items-start gap-2.5 rounded-control p-2 text-xs cursor-pointer hover:bg-sidebar-accent"
                          >
                            {Icon && <Icon className="size-4 shrink-0 text-muted-foreground mt-0.5" />}
                            <div className="flex flex-col min-w-0 flex-1">
                              <div className="flex items-center justify-between">
                                <span className="font-medium text-foreground">{subItem.label}</span>
                                {subItem.badge && (
                                  <span className="font-mono text-2xs px-1 py-0.5 rounded bg-primary-surface text-primary border border-primary-border">
                                    {subItem.badge}
                                  </span>
                                )}
                              </div>
                              {subItem.description && (
                                <span className="text-xs text-muted-foreground line-clamp-1">
                                  {subItem.description}
                                </span>
                              )}
                            </div>
                          </DropdownMenuItem>
                        )
                      })}
                    </DropdownMenuGroup>
                  </DropdownMenuContent>
                </DropdownMenu>
              )
            }

            return (
              <Button
                key={item.id}
                variant="ghost"
                size={compact ? "sm" : "default"}
                onClick={() => {
                  item.onClick?.()
                  onSelect?.(item.id, item)
                }}
                className={cn(
                  "px-2.5 text-xs font-medium transition-colors cursor-pointer",
                  isItemActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-semibold"
                    : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
                )}
              >
                <span>{item.label}</span>
              </Button>
            )
          })}
        </nav>
      </div>

      {/* Right actions slot */}
      <div className="flex items-center gap-2">
        {actions}

        {/* Mobile menu toggle button */}
        {items.length > 0 && (
          <Button
            variant="ghost"
            size="icon-sm"
            className="md:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label="Toggle navigation menu"
          >
            {mobileOpen ? <XIcon className="size-4" /> : <MenuIcon className="size-4" />}
          </Button>
        )}
      </div>

      {/* Mobile Collapsible Submenu Panel */}
      {mobileOpen && (
        <div
          data-slot="navbar-mobile-panel"
          className="absolute top-full left-0 right-0 z-40 flex flex-col border-b border-sidebar-border bg-sidebar/98 p-3 shadow-xl backdrop-blur-md md:hidden"
        >
          <div className="flex flex-col gap-1">
            {items.map((item) => (
              <div key={item.id} className="flex flex-col">
                <Button
                  variant="ghost"
                  className={cn(
                    "justify-start text-xs font-medium",
                    activeId === item.id && "bg-sidebar-accent text-foreground font-semibold"
                  )}
                  onClick={() => {
                    if (!item.items) {
                      item.onClick?.()
                      onSelect?.(item.id, item)
                      setMobileOpen(false)
                    }
                  }}
                >
                  <span>{item.label}</span>
                </Button>
                {item.items && (
                  <div className="ml-4 my-1 flex flex-col gap-1 border-l border-sidebar-border/60 pl-2">
                    {item.items.map((sub, idx) => (
                      <button
                        key={sub.label ?? idx}
                        onClick={() => {
                          sub.onClick?.()
                          onSelect?.(item.id, sub)
                          setMobileOpen(false)
                        }}
                        className="flex items-center justify-between py-1 px-2 text-left text-xs text-muted-foreground hover:text-foreground rounded hover:bg-sidebar-accent/50"
                      >
                        <span>{sub.label}</span>
                        {sub.badge && (
                          <span className="font-mono text-2xs px-1 py-0.2 rounded bg-primary-surface text-primary">
                            {sub.badge}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </header>
  )
}
