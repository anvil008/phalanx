import type { ReactNode } from "react"

import { cn } from "../lib/utils"

/* foundry//zero brand — Terminal Glitch (final).
 * Reactor-core glyph with RGB-split ghosts (cyan left, red right).
 * Aberration colors are fixed brand constants, NOT semantic tokens,
 * so they never follow --info/--destructive theme changes. */
const GHOST_CYAN = "#4cc9d9"
const GHOST_RED = "#f2565f"

function ReactorGlyph({ color, withRing = false }: { color: string; withRing?: boolean }) {
  return (
    <>
      <path
        d="M9.2 3.2h5.6M17.6 5.1l2.8 4.9M20.4 14l-2.8 4.9M14.8 20.8H9.2M6.4 18.9L3.6 14M3.6 10l2.8-4.9"
        stroke={color}
        strokeWidth="1.9"
        strokeLinecap="round"
      />
      <circle cx="12" cy="12" r="3.1" fill={color} />
      {withRing && (
        <circle
          cx="12"
          cy="12"
          r="5.6"
          stroke={color}
          strokeWidth="1.1"
          strokeDasharray="1.6 3.4"
          strokeLinecap="round"
          opacity="0.6"
        />
      )}
    </>
  )
}

export function FoundryZeroMark({
  className,
  size = 28,
}: {
  className?: string
  size?: number
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0 brand-glitch-jitter", className)}
      aria-hidden="true"
    >
      <g className="brand-glitch-ghost-cyan" opacity="0.55">
        <ReactorGlyph color={GHOST_CYAN} />
      </g>
      <g className="brand-glitch-ghost-red" opacity="0.55">
        <ReactorGlyph color={GHOST_RED} />
      </g>
      <ReactorGlyph color="var(--foreground, #f5f5f5)" withRing />
    </svg>
  )
}

export function BrandMark({
  className,
  compact = false,
}: {
  className?: string
  compact?: boolean
}) {
  return (
    <div
      className={cn(
        "inline-flex items-center gap-2.5 brand-glitch-interactive cursor-default",
        className
      )}
    >
      <FoundryZeroMark size={28} />
      {!compact && (
        <span
          className="truncate font-mono text-[14px] font-semibold leading-none tracking-[0.02em] text-foreground brand-glitch-text"
          style={{
            textShadow: `-1.2px 0 ${GHOST_CYAN}b3, 1.2px 0 ${GHOST_RED}b3`,
          }}
        >
          foundry_zero
        </span>
      )}
    </div>
  )
}

export function CoreTileMark({
  product,
  className,
  children,
}: {
  product: string
  className?: string
  children: ReactNode
}) {
  return (
    <span
      aria-hidden="true"
      data-slot="core-tile-product-mark"
      data-core-product={product}
      className={cn("grid size-7 shrink-0 place-items-center rounded-control", className)}
    >
      {children}
    </span>
  )
}

export function CoreTileFoundryGlyph({ color = "currentColor" }: { color?: string }) {
  return (
    <>
      <path
        d="M9.2 3.5h5.6M17.4 5.3l2.7 4.7M20.1 14l-2.7 4.7M14.8 20.5H9.2M6.6 18.7L3.9 14M3.9 10l2.7-4.7"
        stroke={color}
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <circle cx="12" cy="12" r="3" fill={color} />
    </>
  )
}

export function CoreTileFoundryMark({ className }: { className?: string }) {
  return (
    <CoreTileMark
      product="foundry"
      className={cn("bg-brand-foundry text-core-tile-foreground", className)}
    >
      <svg className="size-4" viewBox="0 0 24 24" fill="none" focusable="false">
        <CoreTileFoundryGlyph />
      </svg>
    </CoreTileMark>
  )
}

export function AlphaMark({
  className,
  size = 28,
}: {
  className?: string
  size?: number
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0 brand-glitch-jitter", className)}
      aria-hidden="true"
    >
      <g className="brand-glitch-ghost-cyan" opacity="0.45">
        <rect x="4" y="13.5" width="4" height="7" rx="1" fill={GHOST_CYAN} />
        <rect x="10" y="9" width="4" height="11.5" rx="1" fill={GHOST_CYAN} />
        <rect x="16" y="4.5" width="4" height="16" rx="1" fill={GHOST_CYAN} />
      </g>
      <g className="brand-glitch-ghost-red" opacity="0.45">
        <rect x="4" y="13.5" width="4" height="7" rx="1" fill={GHOST_RED} />
        <rect x="10" y="9" width="4" height="11.5" rx="1" fill={GHOST_RED} />
        <rect x="16" y="4.5" width="4" height="16" rx="1" fill={GHOST_RED} />
      </g>
      <rect x="4" y="13.5" width="4" height="7" rx="1" fill="#3b82f6" />
      <rect x="10" y="9" width="4" height="11.5" rx="1" fill="#60a5fa" />
      <rect x="16" y="4.5" width="4" height="16" rx="1" fill="#34d399" />
    </svg>
  )
}

function LedgerGlyph({ color }: { color: string }) {
  return (
    <g stroke={color} strokeWidth="2.2" strokeLinecap="round">
      <path d="M4 6.5h16" />
      <path d="M4 12h11" />
      <path d="M4 17.5h14" />
    </g>
  )
}

export function LedgerMark({
  className,
  size = 28,
}: {
  className?: string
  size?: number
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0 brand-glitch-jitter", className)}
      aria-hidden="true"
    >
      <g className="brand-glitch-ghost-cyan" opacity="0.45">
        <LedgerGlyph color={GHOST_CYAN} />
      </g>
      <g className="brand-glitch-ghost-red" opacity="0.45">
        <LedgerGlyph color={GHOST_RED} />
      </g>
      <LedgerGlyph color="#3ecf8e" />
    </svg>
  )
}

function BiofeedGlyph({ color }: { color: string }) {
  return (
    <path
      d="M3 12h3.5l2.2-6.5 3.8 13 2.5-8.5 1.8 2H21"
      stroke={color}
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  )
}

export function BiofeedMark({
  className,
  size = 28,
}: {
  className?: string
  size?: number
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0 brand-glitch-jitter", className)}
      aria-hidden="true"
    >
      <g className="brand-glitch-ghost-cyan" opacity="0.45">
        <BiofeedGlyph color={GHOST_CYAN} />
      </g>
      <g className="brand-glitch-ghost-red" opacity="0.45">
        <BiofeedGlyph color={GHOST_RED} />
      </g>
      <BiofeedGlyph color="#7edfc5" />
    </svg>
  )
}

export function NexusDialGlyph({ color }: { color: string }) {
  return (
    <>
      <path
        d="M28.07 12.77A12.5 12.5 0 1 1 19.24 3.93"
        stroke={color}
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <circle cx="24.84" cy="7.16" r="2.7" fill={color} />
      <circle cx="16" cy="16" r="3.4" fill={color} />
    </>
  )
}

function NexusGlyph({ color }: { color: string }) {
  return (
    <>
      <circle cx="6.5" cy="7.5" r="2.4" fill={color} />
      <circle cx="17.5" cy="7.5" r="2.4" fill={color} />
      <circle cx="12" cy="17" r="2.4" fill={color} />
      <path
        d="M8.5 9l2.5 5.5M15.5 9L13 14.5M8.5 7.5h7"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </>
  )
}

export function NexusMark({
  className,
  size = 28,
}: {
  className?: string
  size?: number
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0 brand-glitch-jitter", className)}
      aria-hidden="true"
    >
      <g className="brand-glitch-ghost-cyan" opacity="0.45">
        <NexusGlyph color={GHOST_CYAN} />
      </g>
      <g className="brand-glitch-ghost-red" opacity="0.45">
        <NexusGlyph color={GHOST_RED} />
      </g>
      <NexusGlyph color="#e0a33e" />
    </svg>
  )
}

export function NexusDialMark({
  className,
  size = 28,
}: {
  className?: string
  size?: number
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("shrink-0 brand-glitch-jitter", className)}
      aria-hidden="true"
    >
      <g className="brand-glitch-ghost-cyan" opacity="0.45">
        <NexusDialGlyph color={GHOST_CYAN} />
      </g>
      <g className="brand-glitch-ghost-red" opacity="0.45">
        <NexusDialGlyph color={GHOST_RED} />
      </g>
      <NexusDialGlyph color="var(--brand-nexus)" />
    </svg>
  )
}
