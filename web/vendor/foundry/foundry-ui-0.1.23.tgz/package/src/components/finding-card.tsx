import * as React from "react"
import { AlertTriangleIcon, CheckCircle2Icon, InfoIcon, ShieldAlertIcon } from "lucide-react"
import { cn } from "../lib/utils"
import { ReadoutStack, type ReadoutItemData } from "./readout-stack"

export type FindingSeverity = "attn" | "watch" | "good" | "instr" | "flat"

export interface FindingCardProps extends Omit<React.ComponentProps<"div">, "title"> {
  severity?: FindingSeverity
  title: React.ReactNode
  eyebrow?: React.ReactNode
  description?: React.ReactNode
  glyph?: React.ReactNode
  confidence?: string
  confidenceReason?: string
  readouts?: ReadoutItemData[]
  children?: React.ReactNode
}

export function FindingCard({
  severity = "good",
  title,
  eyebrow,
  description,
  glyph,
  confidence,
  confidenceReason,
  readouts,
  children,
  className,
  ...props
}: FindingCardProps) {
  const stripeColor = {
    attn: "border-l-4 border-l-destructive",
    watch: "border-l-4 border-l-warning",
    good: "border-l-4 border-l-positive",
    instr: "border-l-4 border-l-info",
    flat: "border-l-2 border-l-border",
  }[severity]

  return (
    <div
      data-slot="finding-card"
      data-severity={severity}
      className={cn(
        "flex flex-col gap-3 rounded-lg border border-border bg-card p-4 transition-all shadow-xs",
        stripeColor,
        className
      )}
      {...props}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-0.5 min-w-0">
          {eyebrow && (
            <div className="font-mono text-2xs uppercase tracking-wider text-muted-foreground font-semibold">
              {eyebrow}
            </div>
          )}
          <h4 className="text-sm font-semibold text-strong leading-snug">{title}</h4>
        </div>
        {glyph}
      </div>

      {description && (
        <p className="text-xs text-muted-foreground leading-relaxed font-sans">{description}</p>
      )}

      {readouts && readouts.length > 0 && <ReadoutStack items={readouts} />}

      {children}

      {/* Confidence & Footnote */}
      {(confidence || confidenceReason) && (
        <div className="pt-2 border-t border-hairline font-mono text-2xs text-subtle flex flex-wrap items-baseline gap-2">
          {confidence && (
            <span className="font-semibold text-muted-foreground">Confidence: {confidence}</span>
          )}
          {confidenceReason && <span>· {confidenceReason}</span>}
        </div>
      )}
    </div>
  )
}
