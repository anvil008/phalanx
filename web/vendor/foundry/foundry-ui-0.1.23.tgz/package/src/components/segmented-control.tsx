import * as React from "react"
import { cn } from "../lib/utils"

export type SegmentedControlVariant = "pill" | "tab" | "quiet"
export type SegmentedControlSize = "sm" | "md" | "xs"

export interface SegmentedControlOption<T extends string = string> {
  value: T
  label: React.ReactNode
  icon?: React.ReactNode
  badge?: React.ReactNode
  disabled?: boolean
  tooltip?: string
}

export interface SegmentedControlProps<T extends string = string> {
  value: T
  onChange: (value: T) => void
  options: readonly (SegmentedControlOption<T> | T)[]
  variant?: SegmentedControlVariant
  size?: SegmentedControlSize
  disabled?: boolean
  fullWidth?: boolean
  className?: string
  name?: string
  id?: string
  "aria-label"?: string
}

export function SegmentedControl<T extends string = string>({
  value,
  onChange,
  options,
  variant = "pill",
  size = "sm",
  disabled = false,
  fullWidth = false,
  className,
  name,
  id,
  "aria-label": ariaLabel,
}: SegmentedControlProps<T>) {
  const normalizedOptions: SegmentedControlOption<T>[] = options.map((opt) =>
    typeof opt === "string" ? { value: opt as T, label: opt } : opt
  )

  const sizeClasses = {
    xs: "h-6 p-0.5 text-xs",
    sm: "h-7 p-0.5 text-xs",
    md: "h-8 p-1 text-xs",
  }[size]

  const itemSizeClasses = {
    xs: "px-2 py-0.5",
    sm: "px-2.5 py-1",
    md: "px-3 py-1",
  }[size]

  return (
    <div
      role="radiogroup"
      id={id}
      aria-label={ariaLabel}
      className={cn(
        "inline-flex items-center rounded-control border border-border bg-control/60 text-muted-foreground",
        sizeClasses,
        fullWidth && "flex w-full",
        disabled && "opacity-50 pointer-events-none",
        variant === "tab" && "rounded-none border-b border-t-0 border-x-0 bg-transparent gap-1 p-0",
        className
      )}
    >
      {normalizedOptions.map((option) => {
        const isSelected = value === option.value
        const isDisabled = disabled || option.disabled

        return (
          <button
            key={option.value}
            type="button"
            role="radio"
            name={name}
            aria-checked={isSelected}
            disabled={isDisabled}
            title={option.tooltip}
            onClick={() => !isDisabled && onChange(option.value)}
            className={cn(
              "relative flex items-center justify-center gap-1.5 rounded-item font-medium transition-all select-none whitespace-nowrap focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
              itemSizeClasses,
              fullWidth && "flex-1",
              isSelected
                ? "bg-card text-strong shadow-sm font-semibold"
                : "hover:bg-muted/50 hover:text-foreground active:bg-muted",
              variant === "tab" && [
                "rounded-none border-b-2 bg-transparent shadow-none",
                isSelected
                  ? "border-primary text-foreground font-semibold"
                  : "border-transparent hover:border-border text-muted-foreground hover:text-foreground",
              ]
            )}
          >
            {option.icon && <span className="size-3.5 shrink-0">{option.icon}</span>}
            <span>{option.label}</span>
            {option.badge && <span className="ml-0.5">{option.badge}</span>}
          </button>
        )
      })}
    </div>
  )
}
