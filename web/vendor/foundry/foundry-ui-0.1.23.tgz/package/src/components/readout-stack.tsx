import * as React from "react"
import { cn } from "../lib/utils"
import { getToneTextClass, type StatusToneInput } from "../lib/status-intent"

export interface ReadoutItemData {
  label: string
  value: string | number
  unit?: string
  normalRange?: string
  delta?: string | number
  trend?: "up" | "down" | "flat"
  tone?: StatusToneInput
}

export interface ReadoutStackProps {
  items: ReadoutItemData[]
  className?: string
}

export function ReadoutStack({ items, className }: ReadoutStackProps) {
  return (
    <div
      data-slot="readout-stack"
      className={cn("divide-y divide-hairline rounded border border-border bg-card/60 font-mono text-xs", className)}
    >
      {items.map((item, idx) => (
        <div key={idx} className="flex items-center justify-between px-3 py-2 hover:bg-well/40 transition-colors">
          <div className="flex flex-col">
            <span className="text-xs font-medium text-strong">{item.label}</span>
            {item.normalRange && (
              <span className="text-2xs text-muted-foreground">Range: {item.normalRange}</span>
            )}
          </div>
          <div className="flex items-baseline gap-1.5 text-right">
            <span className={cn("font-semibold text-sm", getToneTextClass(item.tone))}>
              {item.value}
            </span>
            {item.unit && <span className="text-2xs text-muted-foreground">{item.unit}</span>}
          </div>
        </div>
      ))}
    </div>
  )
}
