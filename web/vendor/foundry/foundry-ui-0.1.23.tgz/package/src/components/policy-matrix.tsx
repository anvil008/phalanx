import * as React from "react"
import { ShieldIcon, TerminalIcon, AlertTriangleIcon } from "lucide-react"
import { cn } from "../lib/utils"
import { StatusBadge } from "./status-badge"

export interface PolicyRule {
  id: string
  toolName: string
  domain: string
  effect: "read" | "write" | "execute" | "admin"
  declaredTier: "tier_0" | "tier_1" | "tier_2" | "tier_3"
  observedTier?: "tier_0" | "tier_1" | "tier_2" | "tier_3"
  disposition: "allow" | "deny" | "quorum_required" | "dual_auth_required"
  hasDrift?: boolean
}

export interface PolicyMatrixTableProps extends Omit<React.ComponentProps<"div">, "title"> {
  rules: PolicyRule[]
  title?: React.ReactNode
  description?: React.ReactNode
  className?: string
}

export function PolicyMatrixTable({
  rules,
  title = "Authority & Policy Matrix",
  description = "Dual-authority reconciliation between static catalog declarations and runtime discovery.",
  className,
  ...props
}: PolicyMatrixTableProps) {
  return (
    <div
      data-slot="policy-matrix-table"
      className={cn("flex flex-col rounded-lg border border-border bg-card overflow-hidden font-mono text-xs", className)}
      {...props}
    >
      <div className="border-b border-hairline bg-well/60 px-4 py-3">
        <div className="flex items-center gap-2">
          <ShieldIcon className="size-4 text-primary" />
          <span className="font-semibold text-strong text-sm font-sans">{title}</span>
        </div>
        {description && <div className="text-xs text-muted-foreground mt-0.5 font-sans">{description}</div>}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-hairline bg-well/20 text-muted-foreground text-2xs uppercase">
              <th className="py-2.5 px-3 font-medium">Tool / Resource</th>
              <th className="py-2.5 px-3 font-medium">Domain</th>
              <th className="py-2.5 px-3 font-medium">Effect</th>
              <th className="py-2.5 px-3 font-medium">Declared Tier</th>
              <th className="py-2.5 px-3 font-medium">Observed Tier</th>
              <th className="py-2.5 px-3 font-medium">Disposition</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-hairline">
            {rules.map((r) => (
              <tr key={r.id} className="hover:bg-well/40 transition-colors">
                <td className="py-2.5 px-3 font-semibold text-strong flex items-center gap-1.5">
                  <TerminalIcon className="size-3.5 text-muted-foreground" />
                  <span>{r.toolName}</span>
                </td>
                <td className="py-2.5 px-3 text-secondary-foreground">{r.domain}</td>
                <td className="py-2.5 px-3">
                  <span className={cn(
                    "uppercase text-2xs px-1.5 py-0.5 rounded font-semibold",
                    r.effect === "execute" || r.effect === "admin" ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"
                  )}>
                    {r.effect}
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  <span className="uppercase text-2xs text-strong font-medium">{r.declaredTier}</span>
                </td>
                <td className="py-2.5 px-3">
                  <span className={cn("uppercase text-2xs font-medium", r.hasDrift ? "text-warning font-bold flex items-center gap-1" : "text-secondary-foreground")}>
                    {r.hasDrift && <AlertTriangleIcon className="size-3" />}
                    {r.observedTier ?? r.declaredTier}
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  <StatusBadge tone={r.disposition === "allow" ? "online" : r.disposition === "deny" ? "error" : "warning"}>
                    {r.disposition.toUpperCase()}
                  </StatusBadge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
