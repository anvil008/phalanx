import * as React from "react"

import { cn } from "../lib/utils"
import { formControlVariants, type FormControlVariantProps } from "../lib/form-control"
import { useFieldContext } from "./field"

export interface TextareaProps
  extends React.ComponentProps<"textarea">,
    FormControlVariantProps {}

function Textarea({ className, controlSize = "default", variant = "default", ...props }: TextareaProps) {
  const fieldContext = useFieldContext()
  const id = props.id || (fieldContext.fieldId ? `${fieldContext.fieldId}-control` : undefined)
  const ariaInvalid = props["aria-invalid"] ?? (fieldContext.invalid ? true : undefined)
  const ariaDescribedBy =
    props["aria-describedby"] ||
    (fieldContext.invalid && fieldContext.errorId
      ? fieldContext.errorId
      : fieldContext.descriptionId || undefined)

  return (
    <textarea
      id={id}
      data-slot="textarea"
      aria-invalid={ariaInvalid}
      aria-describedby={ariaDescribedBy}
      disabled={props.disabled ?? fieldContext.disabled}
      className={cn(
        "rounded-control flex field-sizing-content min-h-16 resize-none",
        formControlVariants({ controlSize, variant }),
        "py-2",
        className
      )}
      {...props}
    />
  )
}

export { Textarea }
