import { Avatar, AvatarFallback, AvatarImage } from "./avatar"
import { cn } from "../lib/utils"

export function identityInitials(name: string) {
  return (
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((word) => word[0])
      .join("")
      .toUpperCase() || "?"
  )
}

export function IdentityAvatar({
  name,
  src,
  tone = "neutral",
  size = "xs",
  className,
}: {
  name: string
  src?: string
  tone?: "neutral" | "income"
  size?: "xs" | "sm" | "default" | "lg"
  className?: string
}) {
  return (
    <Avatar
      data-slot="identity-avatar"
      size={size}
      shape="square"
      className={className}
    >
      {src ? <AvatarImage src={src} alt="" aria-hidden="true" /> : null}
      <AvatarFallback
        className={cn(
          "text-xs font-semibold",
          tone === "income"
            ? "bg-positive/15 text-positive"
            : "bg-well text-secondary-foreground"
        )}
      >
        {identityInitials(name)}
      </AvatarFallback>
    </Avatar>
  )
}
