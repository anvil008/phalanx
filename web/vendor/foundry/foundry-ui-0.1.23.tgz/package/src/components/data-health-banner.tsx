import * as React from "react"
import { AlertTriangleIcon, RefreshCwIcon, XIcon } from "lucide-react"
import { cn } from "../lib/utils"
import { Button } from "./button"
import { getToneBannerClasses, type StatusToneInput } from "../lib/status-intent"

export type DataHealthStatus =
  | "degraded"
  | "stale"
  | "disconnected"
  | "syncing"
  | "error"
  | "warning"
  | "positive"
  | "neutral"

export interface DataHealthBannerProps extends Omit<React.ComponentProps<"div">, "title"> {
  status?: StatusToneInput
  title?: React.ReactNode
  description?: React.ReactNode
  lastSync?: Date | string | number
  onRefresh?: () => void
  onDismiss?: () => void
  action?: React.ReactNode
  compact?: boolean
}

export function DataHealthBanner({
  status = "warning",
  title,
  description,
  lastSync,
  onRefresh,
  onDismiss,
  action,
  compact = false,
  className,
  ...props
}: DataHealthBannerProps) {
  const bannerClasses = getToneBannerClasses(status)

  return (
    <div
      role="alert"
      data-slot="data-health-banner"
      className={cn(
        "flex items-center justify-between gap-3 rounded-control border px-3 py-2 text-xs",
        bannerClasses,
        compact ? "py-1 text-xs" : "py-2.5",
        className
      )}
      {...props}
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <AlertTriangleIcon className="size-4 shrink-0" />
        <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 min-w-0">
          {title && <span className="font-semibold text-strong">{title}</span>}
          {description && <span className="text-muted-foreground">{description}</span>}
          {lastSync && (
            <span className="font-mono text-2xs text-subtle">
              Last sync: {String(lastSync)}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {action}
        {onRefresh && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onRefresh}
            className="h-6 gap-1 px-2 text-xs text-foreground hover:bg-well"
          >
            <RefreshCwIcon className="size-3" />
            <span>Refresh</span>
          </Button>
        )}
        {onDismiss && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onDismiss}
            className="size-6 text-muted-foreground hover:text-foreground"
          >
            <XIcon className="size-3.5" />
          </Button>
        )}
      </div>
    </div>
  )
}
