import * as React from "react"
import {
  CalendarIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from "lucide-react"
import { Popover as PopoverPrimitive } from "@base-ui/react/popover"
import { cn } from "../lib/utils"
import { Button } from "./button"
import { Popover, PopoverContent } from "./popover"

export type PeriodMode = "month" | "quarter" | "year" | "range"

export interface PeriodValue {
  year: number
  month?: number // 1-12
  quarter?: number // 1-4
  startDate?: string
  endDate?: string
}

export interface PeriodPickerProps {
  value: PeriodValue
  onChange: (value: PeriodValue) => void
  mode?: PeriodMode
  minYear?: number
  maxYear?: number
  className?: string
  disabled?: boolean
}

export function PeriodPicker({
  value,
  onChange,
  mode = "month",
  minYear = 2018,
  maxYear = 2030,
  className,
  disabled = false,
}: PeriodPickerProps) {
  const [open, setOpen] = React.useState(false)
  const [viewYear, setViewYear] = React.useState(value.year)

  const MONTHS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ]

  const QUARTERS = ["Q1", "Q2", "Q3", "Q4"]

  const label = React.useMemo(() => {
    if (mode === "month" && value.month) {
      return `${MONTHS[value.month - 1]} ${value.year}`
    }
    if (mode === "quarter" && value.quarter) {
      return `Q${value.quarter} ${value.year}`
    }
    return `${value.year}`
  }, [value, mode])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverPrimitive.Trigger
        disabled={disabled}
        className={cn(
          "inline-flex items-center justify-between gap-2 rounded-control border border-border bg-control/60 px-2.5 font-mono text-xs font-medium text-foreground hover:bg-well min-w-[124px] h-7 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring select-none",
          disabled && "opacity-50 pointer-events-none",
          className
        )}
      >
        <div className="flex items-center gap-1.5 min-w-0">
          <CalendarIcon className="size-3.5 shrink-0 text-muted-foreground" />
          <span className="truncate">{label}</span>
        </div>
        <ChevronDownIcon className="size-3.5 shrink-0 text-muted-foreground" />
      </PopoverPrimitive.Trigger>
      <PopoverContent align="start" className="w-64 p-3 bg-popover border border-border">
        {/* Year Pager */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-hairline">
          <Button
            variant="ghost"
            size="icon"
            className="size-6"
            onClick={() => setViewYear((y) => Math.max(minYear, y - 1))}
            disabled={viewYear <= minYear}
          >
            <ChevronLeftIcon className="size-3.5" />
          </Button>
          <span className="font-mono text-xs font-semibold text-strong">{viewYear}</span>
          <Button
            variant="ghost"
            size="icon"
            className="size-6"
            onClick={() => setViewYear((y) => Math.min(maxYear, y + 1))}
            disabled={viewYear >= maxYear}
          >
            <ChevronRightIcon className="size-3.5" />
          </Button>
        </div>

        {/* Selection Grid */}
        {mode === "month" && (
          <div className="grid grid-cols-3 gap-1.5">
            {MONTHS.map((m, idx) => {
              const monthNum = idx + 1
              const isSelected = value.year === viewYear && value.month === monthNum
              return (
                <Button
                  key={m}
                  variant={isSelected ? "default" : "ghost"}
                  size="sm"
                  className={cn(
                    "h-8 text-xs font-medium",
                    isSelected ? "bg-primary text-primary-foreground font-semibold" : "text-muted-foreground hover:text-foreground"
                  )}
                  onClick={() => {
                    onChange({ year: viewYear, month: monthNum })
                    setOpen(false)
                  }}
                >
                  {m}
                </Button>
              )
            })}
          </div>
        )}

        {mode === "quarter" && (
          <div className="grid grid-cols-2 gap-2">
            {QUARTERS.map((q, idx) => {
              const qNum = idx + 1
              const isSelected = value.year === viewYear && value.quarter === qNum
              return (
                <Button
                  key={q}
                  variant={isSelected ? "default" : "ghost"}
                  size="sm"
                  className={cn(
                    "h-10 text-xs font-medium",
                    isSelected ? "bg-primary text-primary-foreground font-semibold" : "text-muted-foreground hover:text-foreground"
                  )}
                  onClick={() => {
                    onChange({ year: viewYear, quarter: qNum })
                    setOpen(false)
                  }}
                >
                  {q}
                </Button>
              )
            })}
          </div>
        )}

        {mode === "year" && (
          <div className="text-center py-2">
            <Button
              variant="default"
              size="sm"
              className="w-full"
              onClick={() => {
                onChange({ year: viewYear })
                setOpen(false)
              }}
            >
              Select {viewYear}
            </Button>
          </div>
        )}
      </PopoverContent>
    </Popover>
  )
}
