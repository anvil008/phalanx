import * as React from "react"
import { cn } from "../lib/utils"

export interface StatStripProps extends React.ComponentProps<"div"> {
  orientation?: "horizontal" | "vertical"
  divided?: boolean
  bordered?: boolean
}

export function StatStrip({
  className,
  orientation = "horizontal",
  divided = true,
  bordered = true,
  children,
  ...props
}: StatStripProps) {
  return (
    <div
      data-slot="stat-strip"
      className={cn(
        "flex w-full overflow-x-auto",
        orientation === "horizontal" ? "flex-row items-stretch" : "flex-col items-stretch",
        divided && (orientation === "horizontal" ? "divide-x divide-border" : "divide-y divide-border"),
        bordered && "rounded-control border border-border bg-card/60",
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

export type StatStripTileTone = "neutral" | "positive" | "negative" | "warning" | "info" | "brand"

const toneBorderClasses: Record<StatStripTileTone, string> = {
  neutral: "",
  positive: "border-t-2 border-t-positive",
  negative: "border-t-2 border-t-negative",
  warning: "border-t-2 border-t-warning",
  info: "border-t-2 border-t-info",
  brand: "border-t-2 border-t-primary",
}

export interface StatStripTileProps extends React.ComponentProps<"div"> {
  tone?: StatStripTileTone
  active?: boolean
  interactive?: boolean
}

export function StatStripTile({
  className,
  tone = "neutral",
  active = false,
  interactive = false,
  onClick,
  children,
  ...props
}: StatStripTileProps) {
  const isClickable = interactive || onClick !== undefined

  return (
    <div
      data-slot="stat-strip-tile"
      data-tone={tone}
      onClick={onClick}
      className={cn(
        "relative flex min-w-[130px] flex-1 flex-col justify-between gap-1 p-3 transition-colors",
        toneBorderClasses[tone],
        isClickable && "cursor-pointer hover:bg-well/60 focus-visible:bg-well focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
        active && "bg-well/80 shadow-inner",
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

export interface StatTileLabelProps extends React.ComponentProps<"div"> {
  icon?: React.ReactNode
  badge?: React.ReactNode
}

export function StatTileLabel({
  className,
  icon,
  badge,
  children,
  ...props
}: StatTileLabelProps) {
  return (
    <div
      data-slot="stat-tile-label"
      className={cn(
        "flex items-center justify-between gap-1.5 text-xs font-medium text-muted-foreground uppercase tracking-wider",
        className
      )}
      {...props}
    >
      <div className="flex items-center gap-1.5 truncate">
        {icon && <span className="size-3.5 shrink-0 opacity-75">{icon}</span>}
        <span className="truncate">{children}</span>
      </div>
      {badge && <span className="shrink-0">{badge}</span>}
    </div>
  )
}

export interface StatTileValueProps extends Omit<React.ComponentProps<"div">, "prefix"> {
  prefix?: React.ReactNode
  suffix?: React.ReactNode
  tone?: "neutral" | "positive" | "negative" | "warning" | "info" | "muted"
}

const valueToneClasses = {
  neutral: "text-strong",
  positive: "text-positive",
  negative: "text-negative",
  warning: "text-warning",
  info: "text-info",
  muted: "text-muted-foreground",
}

export function StatTileValue({
  className,
  prefix,
  suffix,
  tone = "neutral",
  children,
  ...props
}: StatTileValueProps) {
  return (
    <div
      data-slot="stat-tile-value"
      className={cn(
        "flex items-baseline gap-1 font-mono text-lg font-semibold tracking-tight",
        valueToneClasses[tone],
        className
      )}
      {...props}
    >
      {prefix && (
        <span className="text-xs font-normal text-muted-foreground opacity-80">
          {prefix}
        </span>
      )}
      <span>{children}</span>
      {suffix && (
        <span className="text-xs font-normal text-muted-foreground opacity-80">
          {suffix}
        </span>
      )}
    </div>
  )
}

export interface StatTileDetailProps extends React.ComponentProps<"div"> {
  tone?: "neutral" | "positive" | "negative" | "warning" | "info" | "muted"
}

export function StatTileDetail({
  className,
  tone = "muted",
  children,
  ...props
}: StatTileDetailProps) {
  return (
    <div
      data-slot="stat-tile-detail"
      className={cn(
        "flex items-center gap-1 text-2xs font-mono leading-tight",
        valueToneClasses[tone],
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}
