import * as React from "react"

export type TableSurfaceLevel = "base" | "structural"

const structuralSurfaceImage =
  "linear-gradient(color-mix(in oklab, var(--muted) 40%, transparent), color-mix(in oklab, var(--muted) 40%, transparent))"

export function tableSurfaceInteractionStyle(
  level: TableSurfaceLevel,
): React.CSSProperties {
  return {
    "--foundry-table-hover-surface":
      level === "structural"
        ? "var(--card)"
        : "color-mix(in oklab, var(--muted) 50%, var(--card))",
    "--foundry-table-hover-surface-image":
      level === "structural" ? structuralSurfaceImage : "none",
  } as React.CSSProperties
}

/**
 * Shared, opaque table surfaces.
 *
 * Base/detail rows rest on card. Structural rows (headers, group bands,
 * sections, and summaries) add the same 40% muted overlay. The surface is
 * expressed as row-owned custom properties so sticky and ordinary cells can
 * paint an identical opaque background while scrolling.
 */
export function tableSurfaceStyle(
  level: TableSurfaceLevel,
): React.CSSProperties {
  return {
    "--foundry-table-surface": "var(--card)",
    "--foundry-table-surface-image":
      level === "structural" ? structuralSurfaceImage : "none",
    ...tableSurfaceInteractionStyle(level),
  } as React.CSSProperties
}

/** Paints the row-owned surface, with an opaque card fallback. */
export const tableSurfaceClass =
  "bg-[var(--foundry-table-surface,var(--card))] [background-image:var(--foundry-table-surface-image,none)]"

/** Changes every opaque child cell through row-owned hover variables. */
export const tableInteractiveSurfaceClass =
  "hover:[--foundry-table-surface:var(--foundry-table-hover-surface)] hover:[--foundry-table-surface-image:var(--foundry-table-hover-surface-image)]"
