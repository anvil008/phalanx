import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "./utils"

export const formControlVariants = cva(
  "w-full min-w-0 rounded-control border border-border bg-control px-2.5 text-base transition-[background-color,border-color,box-shadow] duration-150 outline-none placeholder:text-muted-foreground hover:border-foreground/10 focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/25 disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-2 aria-invalid:ring-destructive/20 md:text-sm",
  {
    variants: {
      controlSize: {
        sm: "h-7 py-0.5 text-xs",
        default: "h-8 py-1 text-sm",
        lg: "h-9 py-1.5 text-base",
      },
      variant: {
        default: "",
        unstyled:
          "flex-1 rounded-none border-0 bg-transparent py-0 shadow-none ring-0 focus-visible:ring-0 aria-invalid:ring-0 dark:bg-transparent",
      },
    },
    defaultVariants: {
      controlSize: "default",
      variant: "default",
    },
  }
)

export type FormControlVariantProps = VariantProps<typeof formControlVariants>

export function getFormControlClasses(
  options?: FormControlVariantProps & { className?: string }
) {
  const { className, controlSize, variant } = options ?? {}
  return cn(formControlVariants({ controlSize, variant }), className)
}
