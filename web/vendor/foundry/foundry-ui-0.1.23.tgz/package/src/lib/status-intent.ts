/**
 * @foundry/ui status-intent
 * Centralized semantic intent, status normalization, and calibrated tone mappings.
 */

export type SemanticTone =
  | "positive"
  | "negative"
  | "warning"
  | "info"
  | "neutral"
  | "faint"
  | "muted"

export type LegacyStatusTone =
  | "online"
  | "error"
  | "destructive"
  | "degraded"
  | "stale"
  | "disconnected"
  | "syncing"

export type StatusToneInput = SemanticTone | LegacyStatusTone | (string & {})

const legacyAliasMap: Record<string, SemanticTone> = {
  online: "positive",
  error: "negative",
  destructive: "negative",
  degraded: "warning",
  stale: "warning",
  disconnected: "negative",
  syncing: "info",
}

/**
 * Normalizes any semantic or legacy tone string to a canonical SemanticTone.
 */
export function normalizeTone(tone?: StatusToneInput): SemanticTone {
  if (!tone) return "neutral"
  if (tone in legacyAliasMap) {
    return legacyAliasMap[tone]
  }
  switch (tone) {
    case "positive":
    case "negative":
    case "warning":
    case "info":
    case "neutral":
    case "faint":
    case "muted":
      return tone as SemanticTone
    default:
      return "neutral"
  }
}

/**
 * Returns Tailwind class names for StatusDot indicator and pulse ring.
 */
export function getToneDotClasses(tone?: StatusToneInput): { dot: string; pulse: string } {
  const normalized = normalizeTone(tone)
  const dotMap: Record<SemanticTone, string> = {
    neutral: "bg-muted-foreground",
    positive: "bg-positive",
    negative: "bg-negative",
    warning: "bg-warning",
    info: "bg-info",
    faint: "bg-muted-foreground/40",
    muted: "bg-muted-foreground/60",
  }

  const pulseMap: Record<SemanticTone, string> = {
    neutral: "border-muted-foreground/40",
    positive: "border-positive/40",
    negative: "border-negative/40",
    warning: "border-warning/40",
    info: "border-info/40",
    faint: "border-muted-foreground/20",
    muted: "border-muted-foreground/30",
  }

  return {
    dot: dotMap[normalized],
    pulse: pulseMap[normalized],
  }
}

/**
 * Returns Tailwind class names for StatusBadge outline and background styling.
 */
export function getToneBadgeClasses(tone?: StatusToneInput): string {
  const normalized = normalizeTone(tone)
  const badgeMap: Record<SemanticTone, string> = {
    positive: "border-positive/25 bg-positive/10 text-positive",
    warning: "border-warning/25 bg-warning/10 text-warning",
    negative: "border-negative/25 bg-negative/10 text-negative",
    info: "border-info/25 bg-info/10 text-info",
    neutral: "border-border bg-muted text-muted-foreground",
    faint: "border-border/60 bg-muted/50 text-subtle",
    muted: "border-border bg-muted/80 text-muted-foreground",
  }
  return badgeMap[normalized]
}

/**
 * Returns Tailwind class names for DataHealthBanner status container.
 */
export function getToneBannerClasses(status?: StatusToneInput): string {
  const normalized = normalizeTone(status)
  const bannerMap: Record<SemanticTone, string> = {
    positive: "border-positive/40 bg-positive/10 text-positive",
    warning: "border-warning/40 bg-warning/10 text-warning",
    negative: "border-negative/40 bg-destructive/10 text-destructive",
    info: "border-info/40 bg-info/10 text-info",
    neutral: "border-border bg-muted/40 text-muted-foreground",
    faint: "border-border/50 bg-muted/20 text-subtle",
    muted: "border-border bg-muted/30 text-muted-foreground",
  }
  return bannerMap[normalized]
}

/**
 * Returns text color class for a given semantic tone.
 */
export function getToneTextClass(tone?: StatusToneInput): string {
  const normalized = normalizeTone(tone)
  const textMap: Record<SemanticTone, string> = {
    positive: "text-positive",
    negative: "text-negative",
    warning: "text-warning",
    info: "text-info",
    neutral: "text-strong",
    faint: "text-subtle",
    muted: "text-muted-foreground",
  }
  return textMap[normalized]
}

/**
 * Returns border color class for a given semantic tone.
 */
export function getToneBorderClass(tone?: StatusToneInput): string {
  const normalized = normalizeTone(tone)
  const borderMap: Record<SemanticTone, string> = {
    positive: "border-positive/40",
    negative: "border-negative/40",
    warning: "border-warning/40",
    info: "border-info/40",
    neutral: "border-border",
    faint: "border-border/50",
    muted: "border-border/60",
  }
  return borderMap[normalized]
}
