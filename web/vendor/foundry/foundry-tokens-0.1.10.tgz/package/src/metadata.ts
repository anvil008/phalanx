/* @foundry/tokens metadata — v2 (M7 fix).
 * GENERATED from tokens.json — do not hand-edit (audit-enforced).
 * "surface" removed (was never a token); names align 1:1 with tokens.css. */
export const FOUNDRY_COLORS = [
  "background",
  "card",
  "foreground",
  "muted",
  "border",
  "primary",
  "accent",
  "positive",
  "negative",
  "warning",
  "destructive",
  "info",
] as const

export const FOUNDRY_DENSITIES = ["compact"] as const
export const FOUNDRY_RADII = ["sm", "md", "lg", "xl", "control", "item", "shell"] as const
export const FOUNDRY_THEMES = ["dark", "light"] as const
export const FOUNDRY_FONTS = {
  sans: '"Geist", ui-sans-serif, system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace',
} as const

/** Categorical palettes now live in tokens.json with dark/light values and a
 * documented ≥3:1 contrast floor against --background. Values unchanged in dark. */
export const ENTITY_COLOR_PALETTE = [
  "#7ce2fe", "#19d2a5", "#ffd278", "#ff7369", "#32aaf0", "#91dceb", "#1e5ac3",
] as const

export const LIABILITY_COLOR_PALETTE = [
  "#e3897f", "#e0a458", "#5fb3c4", "#9b8fd1", "#d98cc0", "#6b8fd6", "#7fcaa6",
] as const
