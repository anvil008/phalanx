import { useMemo } from "react"
import { cn } from "@foundry/ui/lib/utils"

export interface TimelineSpan {
  id: string
  label: string
  startMs: number
  endMs: number
  status: "running" | "success" | "failed" | "warning" | "queued" | "canceled"
  category?: string
}

export interface RunTimelineProps {
  spans: TimelineSpan[]
  totalDurationMs?: number
  height?: number | string
  className?: string
  onSpanClick?: (span: TimelineSpan) => void
}

export function RunTimeline({
  spans,
  totalDurationMs,
  height = "auto",
  className,
  onSpanClick,
}: RunTimelineProps) {
  const minStart = useMemo(() => Math.min(...spans.map((s) => s.startMs)), [spans])
  const maxEnd = useMemo(() => Math.max(...spans.map((s) => s.endMs)), [spans])
  const duration = totalDurationMs ?? Math.max(1, maxEnd - minStart)

  const statusColor = (status: TimelineSpan["status"]) => {
    switch (status) {
      case "running": return "bg-primary border-primary animate-pulse"
      case "success": return "bg-positive border-positive"
      case "failed": return "bg-destructive border-destructive"
      case "warning": return "bg-warning border-warning"
      case "queued": return "bg-muted-foreground/30 border-muted-foreground/40"
      default: return "bg-muted border-border"
    }
  }

  return (
    <div
      data-slot="run-timeline"
      style={{ height }}
      className={cn("w-full rounded-lg border border-border bg-card p-3 space-y-2 font-mono text-xs", className)}
    >
      <div className="flex justify-between text-2xs text-muted-foreground border-b border-hairline pb-1.5">
        <span>0ms</span>
        <span>{Math.round(duration / 2)}ms</span>
        <span>{duration}ms</span>
      </div>

      <div className="space-y-1.5 pt-1">
        {spans.map((span) => {
          const leftPct = Math.max(0, Math.min(100, ((span.startMs - minStart) / duration) * 100))
          const widthPct = Math.max(1, Math.min(100 - leftPct, ((span.endMs - span.startMs) / duration) * 100))

          return (
            <div key={span.id} className="relative flex items-center h-6 hover:bg-well/40 rounded px-1 group">
              <span className="w-28 text-xs truncate text-muted-foreground group-hover:text-foreground shrink-0 select-none">
                {span.label}
              </span>
              <div className="relative flex-1 h-3.5 bg-control/40 rounded overflow-hidden">
                <div
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                  onClick={() => onSpanClick?.(span)}
                  title={`${span.label}: ${span.endMs - span.startMs}ms (${span.status})`}
                  className={cn(
                    "absolute top-0 bottom-0 rounded border cursor-pointer opacity-90 hover:opacity-100 transition-opacity",
                    statusColor(span.status)
                  )}
                />
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
