import { useId } from "react"

import {
  Area,
  AreaChart,
  CartesianGrid,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import { cn } from "@foundry/ui/lib/utils"

import {
  SERIES_VAR,
  seriesVariable,
  type SeriesColor,
} from "./series"
import { formatNumber } from "./formatters"

export type AreaTrendPoint = Record<string, string | number>

export type AreaMarker = {
  x: string | number
  label: string
  color?: SeriesColor
}

export type ComparisonAreaTrendPoint = {
  label: string
  primary: number
  secondary?: number
}

export type ComparisonAreaTrendProps = {
  data: ComparisonAreaTrendPoint[]
  xKey?: never
  yKey?: never
  height?: number
  className?: string
}

export type AnnotatedAreaTrendProps = {
  data: AreaTrendPoint[]
  xKey: string
  yKey: string
  color?: SeriesColor
  height?: number
  marker?: AreaMarker
  markers?: AreaMarker[]
  threshold?: {
    y: number
    label: string
    color?: SeriesColor
  }
  valueFormatter?: (value: number) => string
  xTickFormatter?: (value: string | number) => string
  className?: string
}

export type AreaTrendProps =
  | ComparisonAreaTrendProps
  | AnnotatedAreaTrendProps

function isAnnotatedAreaTrend(
  props: AreaTrendProps
): props is AnnotatedAreaTrendProps {
  return typeof (props as AnnotatedAreaTrendProps).yKey === "string"
}

/**
 * Shared area-chart family.
 *
 * The default comparison form preserves the Foundry showcase API. Supplying
 * `xKey` and `yKey` selects the generic annotated form used for product data.
 */
export function AreaTrend(props: AreaTrendProps) {
  if (isAnnotatedAreaTrend(props)) {
    return <AnnotatedAreaTrend {...props} />
  }

  return <ComparisonAreaTrend {...props} />
}

function ComparisonAreaTrend({
  data,
  height = 260,
  className,
}: ComparisonAreaTrendProps) {
  const gradientId = useId().replace(/:/g, "")
  const primaryGradientId = `${gradientId}-primary`
  const secondaryGradientId = `${gradientId}-secondary`

  return (
    <div
      data-slot="area-trend"
      style={{ height }}
      className={cn("w-full text-xs", className)}
    >
      <ResponsiveContainer
        width="100%"
        height="100%"
        initialDimension={{ width: 640, height }}
      >
        <AreaChart
          data={data}
          margin={{ top: 8, right: 8, bottom: 0, left: 0 }}
        >
          <defs>
            <linearGradient
              id={primaryGradientId}
              x1="0"
              y1="0"
              x2="0"
              y2="1"
            >
              <stop
                offset="0%"
                stopColor="var(--chart-1)"
                stopOpacity={0.36}
              />
              <stop
                offset="100%"
                stopColor="var(--chart-1)"
                stopOpacity={0}
              />
            </linearGradient>
            <linearGradient
              id={secondaryGradientId}
              x1="0"
              y1="0"
              x2="0"
              y2="1"
            >
              <stop
                offset="0%"
                stopColor="var(--chart-2)"
                stopOpacity={0.2}
              />
              <stop
                offset="100%"
                stopColor="var(--chart-2)"
                stopOpacity={0}
              />
            </linearGradient>
          </defs>
          <CartesianGrid
            vertical={false}
            stroke="var(--border)"
            strokeDasharray="3 5"
          />
          <XAxis
            dataKey="label"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            width={32}
            tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
          />
          <Tooltip
            cursor={{ stroke: "var(--border)" }}
            contentStyle={{
              background: "var(--popover)",
              color: "var(--popover-foreground)",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius)",
              fontSize: 12,
            }}
          />
          <Area
            type="monotone"
            dataKey="secondary"
            stroke="var(--chart-2)"
            strokeWidth={1.5}
            fill={`url(#${secondaryGradientId})`}
            isAnimationActive={false}
          />
          <Area
            type="monotone"
            dataKey="primary"
            stroke="var(--chart-1)"
            strokeWidth={2}
            fill={`url(#${primaryGradientId})`}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}

function AnnotatedAreaTrend({
  data,
  xKey,
  yKey,
  color = "accent",
  height = 210,
  marker,
  markers,
  threshold,
  valueFormatter = (value) => formatNumber(value),
  xTickFormatter,
  className,
}: AnnotatedAreaTrendProps) {
  const gradientId = `${useId().replace(/:/g, "")}-area`
  const stroke = seriesVariable(color, "accent")
  const allMarkers = [...(marker ? [marker] : []), ...(markers ?? [])]

  return (
    <div
      data-slot="area-trend"
      className={cn("w-full", className)}
      style={{ height }}
    >
      <ResponsiveContainer
        width="100%"
        height="100%"
        initialDimension={{ width: 640, height }}
      >
        <AreaChart
          data={data}
          margin={{
            top: allMarkers.length ? 22 : 8,
            right: 8,
            bottom: 0,
            left: 0,
          }}
        >
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={stroke} stopOpacity={0.22} />
              <stop offset="100%" stopColor={stroke} stopOpacity={0} />
            </linearGradient>
          </defs>

          <CartesianGrid vertical={false} stroke="var(--hairline)" />
          <XAxis
            dataKey={xKey}
            tickLine={false}
            axisLine={false}
            tick={{
              fill: "var(--faint)",
              fontSize: 10,
              fontFamily: "var(--font-mono)",
            }}
            minTickGap={32}
            tickFormatter={xTickFormatter}
          />
          <YAxis hide domain={["dataMin", "dataMax"]} />
          <Tooltip
            cursor={{ stroke: "var(--border)", strokeWidth: 1 }}
            contentStyle={{
              background: "var(--popover)",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius-md)",
              fontSize: 12,
              padding: "8px 10px",
            }}
            labelStyle={{ color: "var(--subtle)", marginBottom: 2 }}
            itemStyle={{
              color: "var(--strong)",
              fontFamily: "var(--font-mono)",
            }}
            formatter={(value) =>
              typeof value === "number"
                ? valueFormatter(value)
                : String(value ?? "—")
            }
          />

          {threshold ? (
            <ReferenceLine
              y={threshold.y}
              stroke={SERIES_VAR[threshold.color ?? "violet"]}
              strokeDasharray="5 5"
              strokeWidth={1.5}
              label={{
                value: threshold.label,
                position: "insideTopRight",
                fill: SERIES_VAR[threshold.color ?? "violet"],
                fontSize: 10,
                fontFamily: "var(--font-mono)",
              }}
            />
          ) : null}

          {allMarkers.map((currentMarker) => (
            <ReferenceLine
              key={`${currentMarker.x}-${currentMarker.label}`}
              x={currentMarker.x}
              stroke={SERIES_VAR[currentMarker.color ?? "accent"]}
              strokeDasharray="4 4"
              strokeWidth={1.5}
              label={{
                value: currentMarker.label,
                position: "top",
                fill: SERIES_VAR[currentMarker.color ?? "accent"],
                fontSize: 10,
                fontFamily: "var(--font-mono)",
              }}
            />
          ))}

          <Area
            type="monotone"
            dataKey={yKey}
            stroke={stroke}
            strokeWidth={2.5}
            fill={`url(#${gradientId})`}
            dot={false}
            activeDot={{ r: 3.5, fill: stroke, stroke: "none" }}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
