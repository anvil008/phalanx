import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { cn } from "@foundry/ui/lib/utils"

export interface SleepEpoch {
  date: string
  deepMinutes: number
  remMinutes: number
  lightMinutes: number
  awakeMinutes: number
  totalSleepMinutes: number
}

export interface SleepHypnogramProps {
  data: SleepEpoch[]
  height?: number
  className?: string
}

export function SleepHypnogram({
  data,
  height = 260,
  className,
}: SleepHypnogramProps) {
  return (
    <div
      data-slot="sleep-hypnogram"
      style={{ height }}
      className={cn("w-full relative", className)}
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 12, right: 16, bottom: 8, left: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.5} vertical={false} />
          <XAxis
            dataKey="date"
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
          />
          <YAxis
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
            tickFormatter={(min) => `${Math.round(min / 60)}h`}
          />
          <Tooltip
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null
              const entry = payload[0].payload as SleepEpoch
              const hours = Math.floor(entry.totalSleepMinutes / 60)
              const mins = entry.totalSleepMinutes % 60
              return (
                <div className="rounded-control border border-border bg-popover/95 p-2.5 font-mono text-xs shadow-lg backdrop-blur-md space-y-1">
                  <div className="font-semibold text-strong">{label}</div>
                  <div className="text-primary font-bold">{hours}h {mins}m total sleep</div>
                  <div className="space-y-0.5 text-2xs pt-1 border-t border-hairline">
                    <div className="flex justify-between gap-3 text-chart-1">
                      <span>Deep:</span>
                      <span>{entry.deepMinutes}m</span>
                    </div>
                    <div className="flex justify-between gap-3 text-chart-2">
                      <span>REM:</span>
                      <span>{entry.remMinutes}m</span>
                    </div>
                    <div className="flex justify-between gap-3 text-chart-6">
                      <span>Light:</span>
                      <span>{entry.lightMinutes}m</span>
                    </div>
                    <div className="flex justify-between gap-3 text-muted-foreground">
                      <span>Awake:</span>
                      <span>{entry.awakeMinutes}m</span>
                    </div>
                  </div>
                </div>
              )
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: 10, fontFamily: "var(--font-mono)", paddingTop: 4 }}
          />
          <Bar dataKey="deepMinutes" name="Deep" stackId="sleep" fill="var(--chart-1)" />
          <Bar dataKey="remMinutes" name="REM" stackId="sleep" fill="var(--chart-2)" />
          <Bar dataKey="lightMinutes" name="Light" stackId="sleep" fill="var(--chart-6)" />
          <Bar dataKey="awakeMinutes" name="Awake" stackId="sleep" fill="var(--muted)" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
