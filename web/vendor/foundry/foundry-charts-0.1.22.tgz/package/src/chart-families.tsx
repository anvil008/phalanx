import { useId } from "react"

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Label,
  Line,
  LineChart,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  RadialBar,
  RadialBarChart,
  XAxis,
  YAxis,
} from "recharts"

import {
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@foundry/ui/components/chart"

export type ComparisonPoint = {
  label: string
  primary: number
  secondary?: number
}

export type BreakdownPoint = {
  label: string
  value: number
}

const axisTick = {
  fill: "var(--muted-foreground)",
  fontFamily: "var(--font-mono)",
  fontSize: 10,
}

function comparisonConfig(
  primaryLabel: string,
  secondaryLabel: string
) {
  return {
    primary: {
      label: primaryLabel,
      color: "var(--chart-1)",
    },
    secondary: {
      label: secondaryLabel,
      color: "var(--chart-2)",
    },
  } satisfies ChartConfig
}

export function AreaComparison({
  data,
  primaryLabel = "Primary",
  secondaryLabel = "Secondary",
  stacked = false,
  height = 240,
}: {
  data: ComparisonPoint[]
  primaryLabel?: string
  secondaryLabel?: string
  stacked?: boolean
  height?: number
}) {
  const config = comparisonConfig(primaryLabel, secondaryLabel)
  const gradientId = useId().replace(/:/g, "")
  const primaryGradientId = `${gradientId}-primary`
  const secondaryGradientId = `${gradientId}-secondary`

  return (
    <ChartContainer
      config={config}
      className="w-full aspect-auto"
      style={{ height }}
    >
      <AreaChart
        accessibilityLayer
        data={data}
        margin={{ top: 8, right: 8, bottom: 0, left: 0 }}
      >
        <defs>
          <linearGradient id={primaryGradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.34} />
            <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
          </linearGradient>
          <linearGradient id={secondaryGradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-secondary)" stopOpacity={0.22} />
            <stop offset="100%" stopColor="var(--color-secondary)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} stroke="var(--hairline)" />
        <XAxis dataKey="label" axisLine={false} tickLine={false} tick={axisTick} tickMargin={8} />
        <YAxis axisLine={false} tickLine={false} tick={axisTick} width={32} />
        <ChartTooltip content={<ChartTooltipContent indicator="line" />} />
        <ChartLegend content={<ChartLegendContent />} />
        <Area
          dataKey="primary"
          type="monotone"
          stackId={stacked ? "total" : undefined}
          stroke="var(--color-primary)"
          strokeWidth={1.75}
          fill={`url(#${primaryGradientId})`}
          isAnimationActive={false}
        />
        <Area
          dataKey="secondary"
          type="monotone"
          stackId={stacked ? "total" : undefined}
          stroke="var(--color-secondary)"
          strokeWidth={1.5}
          fill={`url(#${secondaryGradientId})`}
          isAnimationActive={false}
        />
      </AreaChart>
    </ChartContainer>
  )
}

export function BarComparison({
  data,
  primaryLabel = "Primary",
  secondaryLabel = "Secondary",
  horizontal = false,
  height = 240,
}: {
  data: ComparisonPoint[]
  primaryLabel?: string
  secondaryLabel?: string
  horizontal?: boolean
  height?: number
}) {
  const config = comparisonConfig(primaryLabel, secondaryLabel)

  return (
    <ChartContainer
      config={config}
      className="w-full aspect-auto"
      style={{ height }}
    >
      <BarChart
        accessibilityLayer
        data={data}
        layout={horizontal ? "vertical" : "horizontal"}
        margin={{ top: 8, right: 8, bottom: 0, left: horizontal ? 4 : 0 }}
      >
        <CartesianGrid
          vertical={!horizontal}
          horizontal={horizontal}
          stroke="var(--hairline)"
        />
        {horizontal ? (
          <>
            <XAxis type="number" axisLine={false} tickLine={false} tick={axisTick} />
            <YAxis
              type="category"
              dataKey="label"
              axisLine={false}
              tickLine={false}
              tick={axisTick}
              width={54}
            />
          </>
        ) : (
          <>
            <XAxis dataKey="label" axisLine={false} tickLine={false} tick={axisTick} tickMargin={8} />
            <YAxis axisLine={false} tickLine={false} tick={axisTick} width={32} />
          </>
        )}
        <ChartTooltip content={<ChartTooltipContent />} />
        <ChartLegend content={<ChartLegendContent />} />
        <Bar
          dataKey="primary"
          fill="var(--color-primary)"
          radius={horizontal ? [0, 3, 3, 0] : [3, 3, 0, 0]}
          isAnimationActive={false}
        />
        <Bar
          dataKey="secondary"
          fill="var(--color-secondary)"
          radius={horizontal ? [0, 3, 3, 0] : [3, 3, 0, 0]}
          isAnimationActive={false}
        />
      </BarChart>
    </ChartContainer>
  )
}

export function LineComparison({
  data,
  primaryLabel = "Primary",
  secondaryLabel = "Secondary",
  height = 240,
}: {
  data: ComparisonPoint[]
  primaryLabel?: string
  secondaryLabel?: string
  height?: number
}) {
  const config = comparisonConfig(primaryLabel, secondaryLabel)

  return (
    <ChartContainer
      config={config}
      className="w-full aspect-auto"
      style={{ height }}
    >
      <LineChart
        accessibilityLayer
        data={data}
        margin={{ top: 8, right: 8, bottom: 0, left: 0 }}
      >
        <CartesianGrid vertical={false} stroke="var(--hairline)" />
        <XAxis dataKey="label" axisLine={false} tickLine={false} tick={axisTick} tickMargin={8} />
        <YAxis axisLine={false} tickLine={false} tick={axisTick} width={32} />
        <ChartTooltip content={<ChartTooltipContent indicator="line" />} />
        <ChartLegend content={<ChartLegendContent />} />
        <Line
          dataKey="primary"
          type="monotone"
          stroke="var(--color-primary)"
          strokeWidth={1.75}
          dot={false}
          activeDot={{ r: 3 }}
          isAnimationActive={false}
        />
        <Line
          dataKey="secondary"
          type="monotone"
          stroke="var(--color-secondary)"
          strokeWidth={1.5}
          strokeDasharray="4 3"
          dot={false}
          activeDot={{ r: 3 }}
          isAnimationActive={false}
        />
      </LineChart>
    </ChartContainer>
  )
}

export function DonutBreakdown({
  data,
  label = "Total",
  height = 240,
}: {
  data: BreakdownPoint[]
  label?: string
  height?: number
}) {
  const palette = [
    "var(--chart-1)",
    "var(--chart-2)",
    "var(--chart-3)",
    "var(--chart-4)",
    "var(--chart-5)",
    "var(--chart-6)",
    "var(--chart-7)",
  ]
  const total = data.reduce((sum, item) => sum + item.value, 0)
  const chartData = data.map((item, index) => ({
    ...item,
    fill: palette[index % palette.length],
  }))
  const config = Object.fromEntries(
    data.map((item, index) => [
      item.label,
      { label: item.label, color: palette[index % palette.length] },
    ])
  ) satisfies ChartConfig

  return (
    <ChartContainer
      config={config}
      className="w-full aspect-auto"
      style={{ height }}
    >
      <PieChart accessibilityLayer>
        <ChartTooltip
          content={<ChartTooltipContent nameKey="label" hideLabel />}
        />
        <Pie
          data={chartData}
          dataKey="value"
          nameKey="label"
          innerRadius={58}
          outerRadius={82}
          paddingAngle={2}
          stroke="var(--card)"
          strokeWidth={2}
          isAnimationActive={false}
        >
          {chartData.map((entry) => (
            <Cell key={entry.label} fill={entry.fill} />
          ))}
          <Label
            position="center"
            content={({ viewBox }) => {
              if (!viewBox || !("cx" in viewBox) || !("cy" in viewBox)) return null

              return (
                <text
                  x={viewBox.cx}
                  y={viewBox.cy}
                  textAnchor="middle"
                  dominantBaseline="middle"
                >
                  <tspan
                    x={viewBox.cx}
                    y={viewBox.cy}
                    fill="var(--strong)"
                    className="font-mono text-lg font-semibold"
                  >
                    {total.toLocaleString()}
                  </tspan>
                  <tspan
                    x={viewBox.cx}
                    y={(viewBox.cy ?? 0) + 18}
                    fill="var(--muted-foreground)"
                    className="text-2xs"
                  >
                    {label}
                  </tspan>
                </text>
              )
            }}
          />
        </Pie>
        <ChartLegend content={<ChartLegendContent nameKey="label" />} />
      </PieChart>
    </ChartContainer>
  )
}

export function RadarComparison({
  data,
  primaryLabel = "Primary",
  secondaryLabel = "Secondary",
  height = 260,
}: {
  data: ComparisonPoint[]
  primaryLabel?: string
  secondaryLabel?: string
  height?: number
}) {
  const config = comparisonConfig(primaryLabel, secondaryLabel)

  return (
    <ChartContainer
      config={config}
      className="w-full aspect-auto"
      style={{ height }}
    >
      <RadarChart accessibilityLayer data={data} outerRadius="68%">
        <PolarGrid stroke="var(--hairline)" />
        <PolarAngleAxis dataKey="label" tick={axisTick} />
        <ChartTooltip content={<ChartTooltipContent />} />
        <ChartLegend content={<ChartLegendContent />} />
        <Radar
          dataKey="primary"
          stroke="var(--color-primary)"
          fill="var(--color-primary)"
          fillOpacity={0.18}
          strokeWidth={1.5}
          isAnimationActive={false}
        />
        <Radar
          dataKey="secondary"
          stroke="var(--color-secondary)"
          fill="var(--color-secondary)"
          fillOpacity={0.12}
          strokeWidth={1.5}
          isAnimationActive={false}
        />
      </RadarChart>
    </ChartContainer>
  )
}

export function RadialGauge({
  value,
  max = 100,
  label = "Utilization",
  height = 240,
}: {
  value: number
  max?: number
  label?: string
  height?: number
}) {
  const normalized = Math.max(0, Math.min(value, max))
  const config = {
    value: {
      label,
      color: "var(--chart-1)",
    },
  } satisfies ChartConfig

  return (
    <ChartContainer
      config={config}
      className="w-full aspect-auto"
      style={{ height }}
    >
      <RadialBarChart
        accessibilityLayer
        data={[{ name: label, value: normalized, fill: "var(--color-value)" }]}
        startAngle={90}
        endAngle={-270}
        innerRadius={72}
        outerRadius={96}
        barSize={12}
      >
        <PolarAngleAxis type="number" domain={[0, max]} tick={false} />
        <RadialBar
          dataKey="value"
          background={{ fill: "var(--muted)" }}
          cornerRadius={4}
          isAnimationActive={false}
        />
        <Label
          position="center"
          content={({ viewBox }) => {
            if (!viewBox || !("cx" in viewBox) || !("cy" in viewBox)) return null

            return (
              <text
                x={viewBox.cx}
                y={viewBox.cy}
                textAnchor="middle"
                dominantBaseline="middle"
              >
                <tspan
                  x={viewBox.cx}
                  y={viewBox.cy}
                  fill="var(--strong)"
                  className="font-mono text-2xl font-semibold"
                >
                  {normalized.toLocaleString()}
                </tspan>
                <tspan
                  x={viewBox.cx}
                  y={(viewBox.cy ?? 0) + 20}
                  fill="var(--muted-foreground)"
                  className="text-2xs"
                >
                  {label}
                </tspan>
              </text>
            )
          }}
        />
        <ChartTooltip content={<ChartTooltipContent hideLabel />} />
      </RadialBarChart>
    </ChartContainer>
  )
}
