import { cn } from "@foundry/ui/lib/utils"

import {
  SERIES_BG,
  type SeriesColor,
} from "./series"

export type SeriesSwatchProps = {
  color: SeriesColor | (string & {})
  className?: string
}

/**
 * Connects a legend or row to a categorical series. Explicit CSS colors are
 * supported for user-authored data identities; design colors use series slots.
 */
export function SeriesSwatch({
  color,
  className,
}: SeriesSwatchProps) {
  const preset = SERIES_BG[color as SeriesColor]

  return (
    <span
      data-slot="series-swatch"
      aria-hidden
      className={cn("size-2.5 flex-none rounded-[3px]", preset, className)}
      style={preset ? undefined : { backgroundColor: color }}
    />
  )
}

/** Ledger's existing public name; kept as an exact alias during migration. */
export const SeriesDot = SeriesSwatch
