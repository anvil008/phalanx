import {
  useEffect,
  useId,
  useRef,
  useState,
  type KeyboardEvent,
  type RefObject,
} from "react"
import {
  sankey,
  sankeyJustify,
  sankeyLinkHorizontal,
  type SankeyExtraProperties,
  type SankeyLink,
  type SankeyNode,
} from "d3-sankey"

import { cn } from "@foundry/ui/lib/utils"

export interface SankeyNodeDatum extends SankeyExtraProperties {
  /** Stable identity. `name` is accepted as a compatibility alias. */
  id?: string
  name?: string
  label?: string
  color?: string
  /** Optional share of its column total, expressed as a fraction from 0–1. */
  pct?: number
  /** Draw the label above the node instead of beside it. */
  labelAbove?: boolean
}

export interface SankeyLinkDatum extends SankeyExtraProperties {
  source: string | number
  target: string | number
  value: number
  label?: string
  color?: string
}

export type SankeyChartData = {
  nodes: SankeyNodeDatum[]
  links: SankeyLinkDatum[]
}

export interface SankeyMargin {
  top: number
  right: number
  bottom: number
  left: number
}

interface ResolvedNode extends SankeyExtraProperties {
  id: string
  name: string
  label?: string
  color?: string
  pct?: number
  labelAbove?: boolean
}

interface ResolvedLink extends SankeyExtraProperties {
  label?: string
  color?: string
}

export type LaidOutSankeyNode = SankeyNode<ResolvedNode, ResolvedLink>
export type LaidOutSankeyLink = SankeyLink<ResolvedNode, ResolvedLink>

export interface SankeyLayout {
  nodes: LaidOutSankeyNode[]
  links: LaidOutSankeyLink[]
  linkPath: (link: LaidOutSankeyLink) => string | null
  width: number
  height: number
}

export interface SankeyLayoutOptions {
  width: number
  height: number
  nodeWidth?: number
  nodePadding?: number
  iterations?: number
  margin?: SankeyMargin
  nodeOrder?: (identity: string) => number
}

export interface SankeyChartProps {
  data: SankeyChartData
  height?: number
  label?: string
  nodeWidth?: number
  nodePadding?: number
  iterations?: number
  margin?: SankeyMargin
  nodeOrder?: (identity: string) => number
  colorFor?: (identity: string, node: SankeyNodeDatum) => string
  formatValue?: (value: number) => string
  formatPercent?: (fraction: number) => string
  labelHalo?: boolean
  onNodeSelect?: (node: SankeyNodeDatum) => void
  nodeTitle?: (node: SankeyNodeDatum) => string
  selectedNodeId?: string | null
  className?: string
}

const DEFAULT_MARGIN: SankeyMargin = {
  top: 18,
  right: 116,
  bottom: 18,
  left: 116,
}

const tokenPalette = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
  "var(--chart-6)",
  "var(--chart-7)",
] as const

function identityOf(node: SankeyNodeDatum, index: number) {
  const identity = node.id ?? node.name
  if (!identity) {
    throw new Error(`Sankey node at index ${index} requires an id or name`)
  }
  return identity
}

function resolveData(data: SankeyChartData) {
  const nodes: ResolvedNode[] = data.nodes.map((node, index) => {
    const id = identityOf(node, index)
    return {
      ...node,
      id,
      name: node.name ?? id,
    }
  })

  const endpoint = (value: string | number) => {
    if (typeof value === "string") return value
    const node = nodes[value]
    if (!node) throw new Error(`Sankey link references missing node ${value}`)
    return node.id
  }

  const links = data.links.map((link) => ({
    ...link,
    source: endpoint(link.source),
    target: endpoint(link.target),
  }))

  return { nodes, links }
}

/**
 * Shared Sankey layout engine. It clones input before invoking d3-sankey, which
 * mutates nodes and links, so callers can safely reuse one data object.
 */
export function computeSankey(
  data: SankeyChartData,
  options: SankeyLayoutOptions
): SankeyLayout {
  const margin = options.margin ?? DEFAULT_MARGIN
  const innerWidth = Math.max(
    1,
    options.width - margin.left - margin.right
  )
  const innerHeight = Math.max(
    1,
    options.height - margin.top - margin.bottom
  )
  const resolved = resolveData(data)

  const generator = sankey<ResolvedNode, ResolvedLink>()
    .nodeId((node) => node.id)
    .nodeWidth(options.nodeWidth ?? 12)
    .nodePadding(options.nodePadding ?? 18)
    .nodeAlign(sankeyJustify)
    .iterations(options.iterations ?? 24)
    .extent([
      [margin.left, margin.top],
      [margin.left + innerWidth, margin.top + innerHeight],
    ])

  if (options.nodeOrder) {
    generator.nodeSort(
      (a, b) =>
        options.nodeOrder!(a.name) - options.nodeOrder!(b.name)
    )
  }

  const graph = generator({
    nodes: resolved.nodes.map((node) => ({ ...node })),
    links: resolved.links.map((link) => ({ ...link })),
  })

  return {
    nodes: graph.nodes,
    links: graph.links,
    linkPath: sankeyLinkHorizontal<ResolvedNode, ResolvedLink>(),
    width: options.width,
    height: options.height,
  }
}

function maxDepth(nodes: LaidOutSankeyNode[]) {
  return nodes.reduce((depth, node) => Math.max(depth, node.depth ?? 0), 0)
}

function labelSide(
  node: LaidOutSankeyNode,
  width: number,
  finalDepth: number
) {
  const depth = node.depth ?? 0
  if (depth === 0) return "left"
  if (depth === finalDepth) return "right"
  return (node.x0 ?? 0) < width / 2 ? "right" : "left"
}

function linkEndpoints(link: LaidOutSankeyLink) {
  const source = link.source as LaidOutSankeyNode
  const target = link.target as LaidOutSankeyNode
  return { source, target }
}

function useElementWidth<T extends HTMLElement>(
  fallback: number
): [RefObject<T | null>, number] {
  const ref = useRef<T>(null)
  const [width, setWidth] = useState(fallback)

  useEffect(() => {
    const element = ref.current
    if (!element) return

    const measure = () => {
      const nextWidth = Math.round(element.getBoundingClientRect().width)
      if (nextWidth > 0) setWidth(nextWidth)
    }

    measure()
    if (typeof ResizeObserver === "undefined") return

    const observer = new ResizeObserver((entries) => {
      const nextWidth = Math.round(entries[0]?.contentRect.width ?? 0)
      if (nextWidth > 0) setWidth(nextWidth)
    })
    observer.observe(element)
    return () => observer.disconnect()
  }, [])

  return [ref, width]
}

function publicNode(node: LaidOutSankeyNode): SankeyNodeDatum {
  return {
    id: node.id,
    name: node.name,
    label: node.label,
    color: node.color,
    pct: node.pct,
    labelAbove: node.labelAbove,
  }
}

/**
 * Responsive money-flow Sankey with gradient ribbons, deterministic ordering,
 * hover/selection emphasis, inline values, optional percentages, and
 * keyboard-accessible drill-down nodes.
 */
export function SankeyChart({
  data,
  height = 320,
  label = "Flow diagram",
  nodeWidth = 12,
  nodePadding = 18,
  iterations = 24,
  margin = DEFAULT_MARGIN,
  nodeOrder,
  colorFor,
  formatValue = (value) => value.toLocaleString(),
  formatPercent = (fraction) =>
    new Intl.NumberFormat(undefined, {
      style: "percent",
      maximumFractionDigits: 0,
    }).format(fraction),
  labelHalo = false,
  onNodeSelect,
  nodeTitle,
  selectedNodeId = null,
  className,
}: SankeyChartProps) {
  const [ref, width] = useElementWidth<HTMLDivElement>(820)
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null)
  const instanceId = useId().replaceAll(":", "")

  if (data.nodes.length === 0) {
    return (
      <div
        data-slot="sankey-chart"
        className={cn(
          "grid min-h-52 place-items-center rounded-lg border border-dashed border-border text-xs text-muted-foreground",
          className
        )}
      >
        No flow data
      </div>
    )
  }

  const graph = computeSankey(data, {
    width,
    height,
    nodeWidth,
    nodePadding,
    iterations,
    margin,
    nodeOrder,
  })
  const finalDepth = maxDepth(graph.nodes)
  const focus = hoveredNodeId ?? selectedNodeId
  const colors = new Map(
    graph.nodes.map((node, index) => {
      const sourceNode = data.nodes.find(
        (candidate, candidateIndex) =>
          identityOf(candidate, candidateIndex) === node.id
      )
      return [
        node.id,
        colorFor?.(node.name, sourceNode ?? node) ??
          node.color ??
          tokenPalette[index % tokenPalette.length],
      ]
    })
  )

  const selectNode = (
    event: KeyboardEvent<SVGGElement>,
    node: LaidOutSankeyNode
  ) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault()
      onNodeSelect?.(publicNode(node))
    }
  }

  return (
    <div
      ref={ref}
      data-slot="sankey-chart"
      className={cn("w-full", className)}
    >
      <svg
        role="img"
        aria-label={label}
        width={width}
        height={height}
        className="block overflow-visible"
      >
        <title>{label}</title>
        <defs>
          {graph.links.map((link, index) => {
            const { source, target } = linkEndpoints(link)
            const linkColor =
              typeof link.color === "string" ? link.color : undefined
            return (
              <linearGradient
                key={index}
                id={`${instanceId}-link-${index}`}
                gradientUnits="userSpaceOnUse"
                x1={source.x1 ?? 0}
                x2={target.x0 ?? 0}
              >
                <stop
                  offset="0%"
                  stopColor={linkColor ?? colors.get(source.id)}
                />
                <stop
                  offset="100%"
                  stopColor={linkColor ?? colors.get(target.id)}
                />
              </linearGradient>
            )
          })}
        </defs>

        <g fill="none">
          {graph.links.map((link, index) => {
            const { source, target } = linkEndpoints(link)
            const connected =
              !focus || source.id === focus || target.id === focus
            return (
              <path
                key={index}
                d={graph.linkPath(link) ?? undefined}
                stroke={`url(#${instanceId}-link-${index})`}
                strokeWidth={Math.max(1, link.width ?? 1)}
                strokeOpacity={connected ? (focus ? 0.58 : 0.45) : 0.08}
                className="transition-[stroke-opacity] duration-200"
              >
                <title>
                  {source.label ?? source.name} →{" "}
                  {target.label ?? target.name}: {formatValue(link.value)}
                </title>
              </path>
            )
          })}
        </g>

        <g>
          {graph.nodes.map((node) => {
            const x0 = node.x0 ?? 0
            const x1 = node.x1 ?? x0 + nodeWidth
            const y0 = node.y0 ?? 0
            const y1 = node.y1 ?? y0
            const left = labelSide(node, width, finalDepth) === "left"
            const selected = node.id === selectedNodeId
            const active = !focus || node.id === focus
            const above = node.labelAbove === true
            const labelX = above
              ? (x0 + x1) / 2
              : left
                ? x0 - 10
                : x1 + 10
            const labelY = above ? y0 - 8 : (y0 + y1) / 2
            const anchor = above ? "middle" : left ? "end" : "start"
            const sourceNode = publicNode(node)
            const title =
              nodeTitle?.(sourceNode) ??
              `${node.label ?? node.name}: ${formatValue(node.value ?? 0)}`
            const haloProps = labelHalo
              ? {
                  stroke: "var(--card)",
                  strokeWidth: 3,
                  style: { paintOrder: "stroke" as const },
                }
              : {}

            return (
              <g
                key={node.id}
                role={onNodeSelect ? "button" : undefined}
                tabIndex={onNodeSelect ? 0 : undefined}
                aria-label={title}
                onMouseEnter={() => setHoveredNodeId(node.id)}
                onMouseLeave={() => setHoveredNodeId(null)}
                onFocus={() => setHoveredNodeId(node.id)}
                onBlur={() => setHoveredNodeId(null)}
                onClick={() => onNodeSelect?.(sourceNode)}
                onKeyDown={(event) => selectNode(event, node)}
                className={
                  onNodeSelect
                    ? "cursor-pointer outline-none focus-visible:opacity-70"
                    : "cursor-default outline-none"
                }
              >
                {onNodeSelect ? <title>{title}</title> : null}
                <rect
                  x={x0}
                  y={y0}
                  width={Math.max(1, x1 - x0)}
                  height={Math.max(1, y1 - y0)}
                  rx={3}
                  fill={colors.get(node.id)}
                  fillOpacity={active ? 0.95 : 0.3}
                  stroke={selected ? "var(--foreground)" : undefined}
                  strokeWidth={selected ? 2 : undefined}
                  className="transition-[fill-opacity] duration-200"
                />
                <text
                  x={labelX}
                  y={labelY}
                  textAnchor={anchor}
                  dominantBaseline="middle"
                  fontSize={12}
                  className="fill-foreground transition-opacity duration-200"
                  opacity={active ? 1 : 0.35}
                  {...haloProps}
                >
                  <tspan
                    fontWeight={selected ? 700 : 500}
                    fontFamily="var(--font-sans)"
                  >
                    {node.label ?? node.name}
                  </tspan>
                  <tspan
                    className="fill-muted-foreground"
                    dx={7}
                    fontFamily="var(--font-mono)"
                    fontSize={11}
                  >
                    {formatValue(node.value ?? 0)}
                  </tspan>
                  {node.pct != null ? (
                    <tspan
                      className="fill-muted-foreground"
                      dx={5}
                      fontFamily="var(--font-mono)"
                      fontSize={11}
                    >
                      ({formatPercent(Math.abs(node.pct))})
                    </tspan>
                  ) : null}
                </text>
              </g>
            )
          })}
        </g>
      </svg>
    </div>
  )
}
