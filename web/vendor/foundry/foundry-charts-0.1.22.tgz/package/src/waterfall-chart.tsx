import { useMemo } from "react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { cn } from "@foundry/ui/lib/utils"

export interface WaterfallStep {
  name: string
  value: number
  isTotal?: boolean
  isSubtotal?: boolean
}

export interface WaterfallChartProps {
  data: WaterfallStep[]
  height?: number
  valueFormatter?: (val: number) => string
  className?: string
}

export function WaterfallChart({
  data,
  height = 300,
  valueFormatter = (val) => val.toLocaleString(),
  className,
}: WaterfallChartProps) {
  const chartData = useMemo(() => {
    let runningTotal = 0

    return data.map((step) => {
      if (step.isTotal) {
        return {
          name: step.name,
          base: 0,
          value: Math.abs(runningTotal),
          rawDelta: runningTotal,
          isTotal: true,
        }
      }

      if (step.isSubtotal) {
        return {
          name: step.name,
          base: 0,
          value: Math.abs(runningTotal),
          rawDelta: runningTotal,
          isSubtotal: true,
        }
      }

      const prev = runningTotal
      runningTotal += step.value
      const isPositive = step.value >= 0

      return {
        name: step.name,
        base: isPositive ? prev : runningTotal,
        value: Math.abs(step.value),
        rawDelta: step.value,
        isPositive,
      }
    })
  }, [data])

  return (
    <div
      data-slot="waterfall-chart"
      style={{ height }}
      className={cn("w-full relative", className)}
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData} margin={{ top: 16, right: 16, bottom: 12, left: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.5} vertical={false} />
          <XAxis
            dataKey="name"
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
          />
          <YAxis
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
            tickFormatter={valueFormatter}
          />
          <Tooltip
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null
              const entry = payload[0].payload
              const delta = entry.rawDelta
              const isPos = delta >= 0
              return (
                <div className="rounded-control border border-border bg-popover/95 p-2 font-mono text-xs shadow-lg backdrop-blur-md">
                  <div className="font-semibold text-strong">{label}</div>
                  <div className={cn("font-medium", isPos ? "text-positive" : "text-negative")}>
                    {isPos ? "+" : ""}{valueFormatter(delta)}
                  </div>
                </div>
              )
            }}
          />
          <ReferenceLine y={0} stroke="var(--border)" strokeWidth={1.5} />
          {/* Floating Transparent Base */}
          <Bar dataKey="base" stackId="stack" fill="transparent" isAnimationActive={false} />
          {/* Delta Pillar */}
          <Bar dataKey="value" stackId="stack" isAnimationActive={false} radius={[3, 3, 0, 0]}>
            {chartData.map((entry, index) => {
              let fill = "var(--primary)"
              if (entry.isTotal || entry.isSubtotal) {
                fill = "var(--chart-1)"
              } else if (entry.isPositive) {
                fill = "var(--positive)"
              } else {
                fill = "var(--negative)"
              }
              return <Cell key={`cell-${index}`} fill={fill} />
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
