import { useId, type ComponentProps } from "react";

import {
  Area,
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ReferenceArea,
  ReferenceDot,
  ReferenceLine,
  XAxis,
  YAxis,
} from "recharts";

import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "@foundry/ui/components/chart";

import { seriesVariable, type SeriesColor } from "./series";

type LineProps = ComponentProps<typeof Line>;
type AreaProps = ComponentProps<typeof Area>;
type BarProps = ComponentProps<typeof Bar>;

export type CartesianChartDatum = object;

export type CartesianLineSeries = {
  kind: "line";
  dataKey: string;
  name?: string;
  color?: SeriesColor | (string & {});
  props?: Omit<LineProps, "data" | "dataKey" | "name" | "stroke">;
};

export type CartesianAreaSeries = {
  kind: "area";
  dataKey: string;
  name?: string;
  color?: SeriesColor | (string & {});
  fill?: "gradient" | "solid" | "none";
  gradientOpacity?: readonly [start: number, end: number];
  props?: Omit<AreaProps, "data" | "dataKey" | "fill" | "name" | "stroke">;
};

export type CartesianBarSeries = {
  kind: "bar";
  dataKey: string;
  name?: string;
  color?: SeriesColor | (string & {});
  props?: Omit<BarProps, "data" | "dataKey" | "fill" | "name" | "stroke">;
};

export type CartesianSeries =
  | CartesianLineSeries
  | CartesianAreaSeries
  | CartesianBarSeries;

export type CartesianReferenceLine = Omit<
  ComponentProps<typeof ReferenceLine>,
  "stroke"
> & {
  id?: string;
  color?: SeriesColor | (string & {});
};

export type CartesianReferenceDot = Omit<
  ComponentProps<typeof ReferenceDot>,
  "fill" | "stroke"
> & {
  id?: string;
  color?: SeriesColor | (string & {});
  strokeColor?: SeriesColor | (string & {});
};

export type CartesianReferenceArea = Omit<
  ComponentProps<typeof ReferenceArea>,
  "fill" | "stroke"
> & {
  id?: string;
  color?: SeriesColor | (string & {});
  strokeColor?: SeriesColor | (string & {});
};

export type CartesianChartProps = {
  config: ChartConfig;
  data: CartesianChartDatum[];
  series: CartesianSeries[];
  className?: string;
  containerProps?: Omit<
    ComponentProps<typeof ChartContainer>,
    "children" | "className" | "config"
  >;
  chartProps?: Omit<ComponentProps<typeof ComposedChart>, "children" | "data">;
  grid?: false | ComponentProps<typeof CartesianGrid>;
  xAxis?: false | ComponentProps<typeof XAxis>;
  yAxis?: false | ComponentProps<typeof YAxis>;
  tooltip?: false | ComponentProps<typeof ChartTooltip>;
  legend?: false | true | ComponentProps<typeof Legend>;
  referenceLines?: CartesianReferenceLine[];
  referenceDots?: CartesianReferenceDot[];
  referenceAreas?: CartesianReferenceArea[];
};

function chartColor(
  color: SeriesColor | (string & {}) | undefined,
  fallback: SeriesColor,
) {
  return seriesVariable(color, fallback);
}

function gradientKey(dataKey: string, index: number) {
  return `${dataKey.replace(/[^a-zA-Z0-9_-]/g, "-")}-${index}`;
}

/**
 * Declarative shared family for Cartesian product charts.
 *
 * A single composed chart preserves stacked bars, mixed line/area series,
 * semantic gradients, annotations, custom tooltips, and native Recharts
 * interaction handlers without exposing Recharts imports to product code.
 */
export function CartesianChart({
  config,
  data,
  series,
  className,
  containerProps,
  chartProps,
  grid,
  xAxis,
  yAxis,
  tooltip,
  legend,
  referenceLines,
  referenceDots,
  referenceAreas,
}: CartesianChartProps) {
  const id = useId().replace(/:/g, "");
  const areaGradients = series.flatMap((entry, index) =>
    entry.kind === "area" && entry.fill === "gradient"
      ? [
          {
            entry,
            id: `${id}-${gradientKey(entry.dataKey, index)}`,
          },
        ]
      : [],
  );

  return (
    <ChartContainer {...containerProps} config={config} className={className}>
      <ComposedChart accessibilityLayer {...chartProps} data={data}>
        {areaGradients.length > 0 ? (
          <defs>
            {areaGradients.map(({ entry, id: gradientId }) => {
              const color = chartColor(entry.color, "accent");
              const [startOpacity, endOpacity] = entry.gradientOpacity ?? [
                0.24, 0,
              ];

              return (
                <linearGradient
                  key={gradientId}
                  id={gradientId}
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop
                    offset="0%"
                    stopColor={color}
                    stopOpacity={startOpacity}
                  />
                  <stop
                    offset="100%"
                    stopColor={color}
                    stopOpacity={endOpacity}
                  />
                </linearGradient>
              );
            })}
          </defs>
        ) : null}

        {grid === false || grid === undefined ? null : (
          <CartesianGrid {...grid} />
        )}
        {xAxis === false || xAxis === undefined ? null : <XAxis {...xAxis} />}
        {yAxis === false || yAxis === undefined ? null : <YAxis {...yAxis} />}
        {tooltip === false || tooltip === undefined ? null : (
          <ChartTooltip {...tooltip} />
        )}
        {legend === false || legend === undefined ? null : (
          <Legend {...(legend === true ? {} : legend)} />
        )}

        {referenceAreas?.map((reference, index) => {
          const { id: referenceId, color, strokeColor, ...props } = reference;

          return (
            <ReferenceArea
              key={referenceId ?? `area-${index}`}
              {...props}
              fill={chartColor(color, "accent")}
              stroke={chartColor(strokeColor ?? color, "accent")}
            />
          );
        })}
        {referenceLines?.map((reference, index) => {
          const { id: referenceId, color, ...props } = reference;

          return (
            <ReferenceLine
              key={referenceId ?? `line-${index}`}
              {...props}
              stroke={chartColor(color, "neutral")}
            />
          );
        })}
        {referenceDots?.map((reference, index) => {
          const { id: referenceId, color, strokeColor, ...props } = reference;

          return (
            <ReferenceDot
              key={referenceId ?? `dot-${index}`}
              {...props}
              fill={chartColor(color, "accent")}
              stroke={chartColor(strokeColor, "neutral")}
            />
          );
        })}

        {series.map((entry, index) => {
          const color = chartColor(entry.color, "accent");

          if (entry.kind === "bar") {
            return (
              <Bar
                key={`${entry.dataKey}-${index}`}
                {...entry.props}
                dataKey={entry.dataKey}
                name={entry.name}
                fill={color}
              />
            );
          }

          if (entry.kind === "area") {
            const gradient = areaGradients.find(
              ({ entry: candidate }) => candidate === entry,
            );
            const fill =
              entry.fill === "none"
                ? "none"
                : entry.fill === "gradient"
                  ? `url(#${gradient?.id})`
                  : color;

            return (
              <Area
                key={`${entry.dataKey}-${index}`}
                {...entry.props}
                dataKey={entry.dataKey}
                name={entry.name}
                stroke={color}
                fill={fill}
              />
            );
          }

          return (
            <Line
              key={`${entry.dataKey}-${index}`}
              {...entry.props}
              dataKey={entry.dataKey}
              name={entry.name}
              stroke={color}
            />
          );
        })}
      </ComposedChart>
    </ChartContainer>
  );
}
