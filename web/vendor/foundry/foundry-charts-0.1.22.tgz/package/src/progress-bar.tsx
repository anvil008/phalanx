import { cn } from "@foundry/ui/lib/utils"

import { SERIES_BG, type SeriesColor } from "./series"

export type ProgressBarProps = {
  value: number
  max?: number
  color?: SeriesColor
  over?: boolean
  size?: "sm" | "md"
  className?: string
}

/**
 * A compact, token-driven progress indicator for budgets, goals, and capacity.
 * `over` is a semantic danger state and therefore overrides the series color.
 */
export function ProgressBar({
  value,
  max = 100,
  color = "accent",
  over = false,
  size = "md",
  className,
}: ProgressBarProps) {
  const percentage =
    max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0

  return (
    <div
      data-slot="progress-bar"
      role="progressbar"
      aria-valuenow={Math.round(percentage)}
      aria-valuemin={0}
      aria-valuemax={100}
      className={cn(
        "w-full overflow-hidden rounded-full bg-well",
        size === "sm" ? "h-[5px]" : "h-1.5",
        className
      )}
    >
      <div
        data-slot="progress-bar-indicator"
        className={cn(
          "h-full rounded-full",
          over ? "bg-negative" : SERIES_BG[color]
        )}
        style={{ width: `${percentage}%` }}
      />
    </div>
  )
}
