import { useMemo } from "react"
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { cn } from "@foundry/ui/lib/utils"

export interface FanChartDataPoint {
  period: string | number
  p05: number
  p25: number
  p50: number // Median
  p75: number
  p95: number
  actual?: number
}

export interface PercentileFanChartProps {
  data: FanChartDataPoint[]
  milestones?: { period: string | number; label: string; value?: number }[]
  targetValue?: number
  targetLabel?: string
  height?: number
  valueFormatter?: (val: number) => string
  className?: string
}

export function PercentileFanChart({
  data,
  milestones = [],
  targetValue,
  targetLabel = "Target",
  height = 300,
  valueFormatter = (val) => val.toLocaleString(),
  className,
}: PercentileFanChartProps) {
  // Transform data for stacked area bands
  const transformedData = useMemo(() => {
    return data.map((d) => ({
      ...d,
      bandOuterLower: d.p05,
      bandOuterHeight: d.p95 - d.p05,
      bandInnerLower: d.p25,
      bandInnerHeight: d.p75 - d.p25,
    }))
  }, [data])

  return (
    <div
      data-slot="percentile-fan-chart"
      style={{ height }}
      className={cn("w-full relative", className)}
    >
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={transformedData} margin={{ top: 12, right: 16, bottom: 8, left: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.5} />
          <XAxis
            dataKey="period"
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
          />
          <YAxis
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
            tickFormatter={valueFormatter}
          />
          <Tooltip
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null
              const point = payload[0].payload as FanChartDataPoint
              return (
                <div className="rounded-control border border-border bg-popover/95 p-2.5 font-mono text-xs shadow-lg backdrop-blur-md">
                  <div className="font-semibold text-strong mb-1">{label}</div>
                  <div className="space-y-0.5 text-xs">
                    <div className="flex justify-between gap-3 text-muted-foreground">
                      <span>95th Pct:</span>
                      <span className="font-medium text-strong">{valueFormatter(point.p95)}</span>
                    </div>
                    <div className="flex justify-between gap-3 text-muted-foreground">
                      <span>75th Pct:</span>
                      <span className="font-medium text-strong">{valueFormatter(point.p75)}</span>
                    </div>
                    <div className="flex justify-between gap-3 text-primary">
                      <span>Median (P50):</span>
                      <span className="font-semibold text-primary">{valueFormatter(point.p50)}</span>
                    </div>
                    <div className="flex justify-between gap-3 text-muted-foreground">
                      <span>25th Pct:</span>
                      <span className="font-medium text-strong">{valueFormatter(point.p25)}</span>
                    </div>
                    <div className="flex justify-between gap-3 text-muted-foreground">
                      <span>5th Pct:</span>
                      <span className="font-medium text-strong">{valueFormatter(point.p05)}</span>
                    </div>
                    {point.actual !== undefined && (
                      <div className="flex justify-between gap-3 text-positive pt-1 border-t border-hairline">
                        <span>Actual:</span>
                        <span className="font-semibold">{valueFormatter(point.actual)}</span>
                      </div>
                    )}
                  </div>
                </div>
              )
            }}
          />

          {/* Shaded 5th-95th percentile envelope */}
          <Area
            dataKey="p95"
            stroke="transparent"
            fill="var(--chart-1)"
            fillOpacity={0.12}
            isAnimationActive={false}
          />
          {/* Shaded 25th-75th percentile envelope */}
          <Area
            dataKey="p75"
            stroke="transparent"
            fill="var(--chart-1)"
            fillOpacity={0.24}
            isAnimationActive={false}
          />
          {/* P50 Median Line */}
          <Line
            dataKey="p50"
            stroke="var(--chart-1)"
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />
          {/* Actual Trail if provided */}
          <Line
            dataKey="actual"
            stroke="var(--positive)"
            strokeWidth={2.5}
            dot={{ r: 3, fill: "var(--positive)" }}
            isAnimationActive={false}
          />

          {targetValue !== undefined && (
            <ReferenceLine
              y={targetValue}
              stroke="var(--warning)"
              strokeDasharray="4 4"
              label={{
                value: targetLabel,
                position: "insideTopRight",
                fill: "var(--warning)",
                fontSize: 10,
                fontFamily: "var(--font-mono)",
              }}
            />
          )}

          {milestones.map((m, idx) => (
            <ReferenceLine
              key={idx}
              x={m.period}
              stroke="var(--primary)"
              strokeDasharray="2 2"
              label={{
                value: m.label,
                position: "top",
                fill: "var(--primary)",
                fontSize: 9,
                fontFamily: "var(--font-mono)",
              }}
            />
          ))}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  )
}
