import {
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { cn } from "@foundry/ui/lib/utils"

export interface PayoffPoint {
  price: number
  expirationPnl: number
  currentPnl?: number
}

export interface OptionsPayoffChartProps {
  data: PayoffPoint[]
  currentSpot: number
  strikes?: { price: number; label?: string }[]
  breakevens?: number[]
  height?: number
  valueFormatter?: (val: number) => string
  className?: string
}

export function OptionsPayoffChart({
  data,
  currentSpot,
  strikes = [],
  breakevens = [],
  height = 300,
  valueFormatter = (val) => `$${val.toLocaleString()}`,
  className,
}: OptionsPayoffChartProps) {
  return (
    <div
      data-slot="options-payoff-chart"
      style={{ height }}
      className={cn("w-full relative", className)}
    >
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 12, right: 16, bottom: 8, left: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.5} />
          <XAxis
            dataKey="price"
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
            tickFormatter={(p) => `$${p}`}
          />
          <YAxis
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
            tickFormatter={valueFormatter}
          />
          <ReferenceLine y={0} stroke="var(--border)" strokeWidth={1.5} />
          <ReferenceLine
            x={currentSpot}
            stroke="var(--primary)"
            strokeWidth={1.5}
            strokeDasharray="4 4"
            label={{
              value: `Spot: $${currentSpot}`,
              position: "top",
              fill: "var(--primary)",
              fontSize: 10,
              fontFamily: "var(--font-mono)",
            }}
          />

          {strikes.map((s, idx) => (
            <ReferenceLine
              key={idx}
              x={s.price}
              stroke="var(--muted-foreground)"
              strokeDasharray="2 2"
              label={{
                value: s.label ?? `$${s.price}`,
                position: "insideTopLeft",
                fill: "var(--muted-foreground)",
                fontSize: 9,
                fontFamily: "var(--font-mono)",
              }}
            />
          ))}

          {breakevens.map((b, idx) => (
            <ReferenceLine
              key={`be-${idx}`}
              x={b}
              stroke="var(--warning)"
              strokeDasharray="2 2"
              label={{
                value: `BE $${b}`,
                position: "bottom",
                fill: "var(--warning)",
                fontSize: 9,
                fontFamily: "var(--font-mono)",
              }}
            />
          ))}

          <Tooltip
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null
              const pt = payload[0].payload as PayoffPoint
              return (
                <div className="rounded-control border border-border bg-popover/95 p-2 font-mono text-xs shadow-lg backdrop-blur-md">
                  <div className="font-semibold text-strong">Underlying: ${label}</div>
                  <div className={cn("font-medium", pt.expirationPnl >= 0 ? "text-positive" : "text-negative")}>
                    Expiry P&L: {valueFormatter(pt.expirationPnl)}
                  </div>
                  {pt.currentPnl !== undefined && (
                    <div className={cn("text-xs", pt.currentPnl >= 0 ? "text-positive" : "text-negative")}>
                      T+0 P&L: {valueFormatter(pt.currentPnl)}
                    </div>
                  )}
                </div>
              )
            }}
          />

          {/* Expiry Payoff Line */}
          <Line
            dataKey="expirationPnl"
            stroke="var(--strong)"
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />
          {/* Current T+0 Curve */}
          <Line
            dataKey="currentPnl"
            stroke="var(--primary)"
            strokeWidth={2}
            strokeDasharray="3 3"
            dot={false}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  )
}
