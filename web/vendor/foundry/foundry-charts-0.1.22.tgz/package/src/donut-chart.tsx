import { type ComponentProps } from "react";

import { Cell, Pie, PieChart } from "recharts";

import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "@foundry/ui/components/chart";

import { seriesVariable, type SeriesColor } from "./series";

export type DonutChartDatum = object & {
  color?: SeriesColor | (string & {});
};

export type DonutChartProps = {
  config: ChartConfig;
  data: DonutChartDatum[];
  dataKey?: string;
  nameKey?: string;
  keyKey?: string;
  className?: string;
  containerProps?: Omit<
    ComponentProps<typeof ChartContainer>,
    "children" | "className" | "config"
  >;
  chartProps?: Omit<ComponentProps<typeof PieChart>, "children">;
  pieProps?: Omit<
    ComponentProps<typeof Pie>,
    "children" | "data" | "dataKey" | "nameKey"
  >;
  tooltip?: false | ComponentProps<typeof ChartTooltip>;
};

/**
 * Token-driven donut family with per-slice semantic colors.
 */
export function DonutChart({
  config,
  data,
  dataKey = "value",
  nameKey = "name",
  keyKey = "id",
  className,
  containerProps,
  chartProps,
  pieProps,
  tooltip,
}: DonutChartProps) {
  return (
    <ChartContainer {...containerProps} config={config} className={className}>
      <PieChart accessibilityLayer {...chartProps}>
        {tooltip === false || tooltip === undefined ? null : (
          <ChartTooltip {...tooltip} />
        )}
        <Pie {...pieProps} data={data} dataKey={dataKey} nameKey={nameKey}>
          {data.map((entry, index) => (
            <Cell
              key={String((entry as Record<string, unknown>)[keyKey] ?? index)}
              fill={seriesVariable(entry.color, "accent")}
            />
          ))}
        </Pie>
      </PieChart>
    </ChartContainer>
  );
}
