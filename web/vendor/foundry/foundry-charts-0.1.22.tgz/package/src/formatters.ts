/**
 * Standardized telemetry and financial data formatters for @foundry/charts.
 * Configured for maximum clarity with Commit Mono tabular numerals.
 */

export interface NumberFormatOptions {
  decimals?: number
  currency?: string
  signDisplay?: "auto" | "always" | "never" | "exceptZero"
}

export function formatNumber(value: number, decimals: number = 0): string {
  if (!Number.isFinite(value)) return "—"
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value)
}

export function formatCurrency(
  value: number,
  currency: string = "USD",
  decimals: number = 2
): string {
  if (!Number.isFinite(value)) return "—"
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value)
}

export function formatPercent(value: number, decimals: number = 1): string {
  if (!Number.isFinite(value)) return "—"
  const formatted = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value)
  return `${value > 0 ? "+" : ""}${formatted}%`
}

export function formatCompactNumber(value: number): string {
  if (!Number.isFinite(value)) return "—"
  const abs = Math.abs(value)
  const sign = value < 0 ? "-" : ""

  if (abs >= 1_000_000_000) {
    return `${sign}${(abs / 1_000_000_000).toFixed(1)}B`
  }
  if (abs >= 1_000_000) {
    return `${sign}${(abs / 1_000_000).toFixed(1)}M`
  }
  if (abs >= 1_000) {
    return `${sign}${(abs / 1_000).toFixed(1)}k`
  }
  return `${value}`
}
