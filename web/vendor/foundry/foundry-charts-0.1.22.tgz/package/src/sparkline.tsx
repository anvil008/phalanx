import { useId } from "react"

import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts"

import { cn } from "@foundry/ui/lib/utils"

import {
  SERIES_VAR,
  type SeriesColor,
} from "./series"

export type SparklinePoint = {
  label: string
  value: number
}

export type SparklineChartProps = {
  data: SparklinePoint[]
  points?: never
  color?: string
  height?: number
  className?: string
}

export type CompactSparklineProps = {
  points: number[]
  data?: never
  color?: SeriesColor
  width?: number
  height?: number
  className?: string
}

export type SparklineProps = SparklineChartProps | CompactSparklineProps

function isCompactSparkline(
  props: SparklineProps
): props is CompactSparklineProps {
  return Array.isArray((props as CompactSparklineProps).points)
}

export function Sparkline(props: SparklineProps) {
  if (isCompactSparkline(props)) {
    return <CompactSparkline {...props} />
  }

  return <ChartSparkline {...props} />
}

function CompactSparkline({
  points,
  color,
  width = 72,
  height = 24,
  className,
}: CompactSparklineProps) {
  if (points.length < 2) {
    return (
      <svg
        data-slot="sparkline"
        width={width}
        height={height}
        aria-hidden
        className={className}
      />
    )
  }

  const min = Math.min(...points)
  const max = Math.max(...points)
  const span = max - min || 1
  const padding = 2
  const path = points
    .map((point, index) => {
      const x = (index / (points.length - 1)) * width
      const y =
        height -
        padding -
        ((point - min) / span) * (height - padding * 2)

      return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`
    })
    .join(" ")
  const rising = points[points.length - 1]! >= points[0]!
  const stroke = SERIES_VAR[color ?? (rising ? "accent" : "red")]

  return (
    <svg
      data-slot="sparkline"
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      fill="none"
      aria-hidden
      className={cn("opacity-70", className)}
    >
      <path
        d={path}
        stroke={stroke}
        strokeWidth={1.6}
        fill="none"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  )
}

function ChartSparkline({
  data,
  color = "var(--chart-1)",
  height = 72,
  className,
}: SparklineChartProps) {
  const gradientId = `${useId().replace(/:/g, "")}-spark`

  return (
    <div
      data-slot="sparkline"
      style={{ height }}
      className={cn("w-full", className)}
    >
      <ResponsiveContainer
        width="100%"
        height="100%"
        initialDimension={{ width: 160, height }}
      >
        <AreaChart data={data} margin={{ top: 6, right: 2, bottom: 0, left: 2 }}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.38} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Tooltip
            cursor={false}
            contentStyle={{
              background: "var(--popover)",
              color: "var(--popover-foreground)",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius)",
              fontFamily: "var(--font-mono)",
              fontSize: 11,
            }}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2}
            fill={`url(#${gradientId})`}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
