/**
 * Shared categorical series slots.
 *
 * Components use the class map for HTML fills and the variable map for SVG
 * strokes/fills. Product themes can remap the underlying chart tokens without
 * changing component code.
 */
export type SeriesColor =
  | "accent"
  | "violet"
  | "emerald"
  | "amber"
  | "red"
  | "neutral"
  | "cyan"
  | "orange"
  | "warm"
  | "chart-1"
  | "chart-2"
  | "chart-3"
  | "chart-4"
  | "chart-5"
  | "chart-6"
  | "chart-7"
  | "chart-8"

export const SERIES_BG: Record<SeriesColor, string> = {
  accent: "bg-chart-1",
  violet: "bg-chart-2",
  emerald: "bg-chart-2",
  amber: "bg-chart-3",
  red: "bg-chart-4",
  neutral: "bg-chart-5",
  cyan: "bg-chart-6",
  orange: "bg-chart-7",
  warm: "bg-chart-7",
  "chart-1": "bg-chart-1",
  "chart-2": "bg-chart-2",
  "chart-3": "bg-chart-3",
  "chart-4": "bg-chart-4",
  "chart-5": "bg-chart-5",
  "chart-6": "bg-chart-6",
  "chart-7": "bg-chart-7",
  "chart-8": "bg-chart-8",
}

export const SERIES_VAR: Record<SeriesColor, string> = {
  accent: "var(--chart-1)",
  violet: "var(--chart-2)",
  emerald: "var(--chart-2)",
  amber: "var(--chart-3)",
  red: "var(--chart-4)",
  neutral: "var(--chart-5)",
  cyan: "var(--chart-6)",
  orange: "var(--chart-7)",
  warm: "var(--chart-7)",
  "chart-1": "var(--chart-1)",
  "chart-2": "var(--chart-2)",
  "chart-3": "var(--chart-3)",
  "chart-4": "var(--chart-4)",
  "chart-5": "var(--chart-5)",
  "chart-6": "var(--chart-6)",
  "chart-7": "var(--chart-7)",
  "chart-8": "var(--chart-8)",
}

export function isSeriesColor(value: string): value is SeriesColor {
  return value in SERIES_VAR
}

export function seriesVariable(
  color: SeriesColor | (string & {}) | undefined,
  fallback: SeriesColor = "accent"
): string {
  return color && isSeriesColor(color) ? SERIES_VAR[color] : color ?? SERIES_VAR[fallback]
}
