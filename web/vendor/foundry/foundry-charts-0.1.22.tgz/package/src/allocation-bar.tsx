import type {
  CSSProperties,
  ReactNode,
} from "react"

import { cn } from "@foundry/ui/lib/utils"

import {
  SERIES_BG,
  type SeriesColor,
  isSeriesColor,
  seriesVariable,
} from "./series"

export type AllocationSegment = {
  id?: string
  label: string
  value: number
  color?: SeriesColor | (string & {})
}

export type AllocationBarProps = {
  segments: AllocationSegment[]
  label?: string
  formatValue?: (
    value: number,
    segment: AllocationSegment
  ) => ReactNode
  showLegend?: boolean
  /** Compact-family compatibility name for `showLegend`. */
  legend?: boolean
  legendAs?: "value" | "percent"
  legendLayout?: "stack" | "inline"
  variant?: "detailed" | "compact"
  emptyState?: ReactNode
  className?: string
}

const tokenPalette = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
  "var(--chart-6)",
  "var(--chart-7)",
] as const

function segmentColor(segment: AllocationSegment, index: number) {
  return segment.color ?? tokenPalette[index % tokenPalette.length]!
}

function segmentKey(segment: AllocationSegment, index: number) {
  return segment.id ?? `${segment.label}-${index}`
}

/**
 * Part-to-whole composition for both detailed cards and compact operational
 * rails. Shares always use absolute magnitude, so signed financial values keep
 * their truthful displayed value without producing invalid negative widths.
 */
export function AllocationBar({
  segments,
  label = "Allocation",
  formatValue = (value) => value.toLocaleString(),
  showLegend,
  legend,
  legendAs = "value",
  legendLayout = "stack",
  variant = "detailed",
  emptyState = "No allocation",
  className,
}: AllocationBarProps) {
  const normalized = segments.filter((segment) =>
    Number.isFinite(segment.value)
  )
  const total = normalized.reduce(
    (sum, segment) => sum + Math.abs(segment.value),
    0
  )
  const share = (value: number) =>
    total > 0 ? (Math.abs(value) / total) * 100 : 0
  const displayLegend = legend ?? showLegend ?? true

  if (variant === "compact") {
    return (
      <CompactAllocationBar
        segments={normalized}
        total={total}
        share={share}
        displayLegend={displayLegend}
        legendAs={legendAs}
        legendLayout={legendLayout}
        formatValue={formatValue}
        className={className}
      />
    )
  }

  if (total <= 0) {
    return (
      <div
        data-slot="allocation-bar"
        className={cn(
          "rounded-md border border-dashed border-border bg-background px-3 py-5 text-center text-xs text-muted-foreground",
          className
        )}
      >
        {emptyState}
      </div>
    )
  }

  return (
    <div data-slot="allocation-bar" className={className}>
      <div
        role="img"
        aria-label={`${label}: ${normalized
          .map(
            (segment) =>
              `${segment.label} ${Math.round(share(segment.value))}%`
          )
          .join(", ")}`}
        className="flex h-7 w-full overflow-hidden rounded-md border border-border bg-well"
      >
        {normalized.map((segment, index) => {
          const percentage = share(segment.value)
          const color = seriesVariable(
            segmentColor(segment, index),
            "accent"
          )

          return (
            <div
              key={segmentKey(segment, index)}
              title={`${segment.label}: ${formatValue(segment.value, segment)} (${percentage.toFixed(1)}%)`}
              className="relative grid min-w-px place-items-center border-r border-background/35 last:border-r-0"
              style={
                {
                  flexBasis: `${percentage}%`,
                  background: color,
                } as CSSProperties
              }
            >
              {percentage >= 12 ? (
                <span className="truncate px-1 font-mono text-2xs font-semibold text-background">
                  {Math.round(percentage)}%
                </span>
              ) : null}
            </div>
          )
        })}
      </div>

      {displayLegend ? (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {normalized.map((segment, index) => {
            const percentage = share(segment.value)

            return (
              <div
                key={segmentKey(segment, index)}
                className="flex min-w-0 items-center gap-2"
              >
                <span
                  aria-hidden
                  className="size-2 shrink-0 rounded-[2px]"
                  style={{
                    background: seriesVariable(
                      segmentColor(segment, index),
                      "accent"
                    ),
                  }}
                />
                <span className="min-w-0 flex-1 truncate text-xs text-muted-foreground">
                  {segment.label}
                </span>
                <span className="font-mono text-2xs text-foreground tabular-nums">
                  {formatValue(segment.value, segment)} ·{" "}
                  {percentage.toFixed(1)}%
                </span>
              </div>
            )
          })}
        </div>
      ) : null}
    </div>
  )
}

function CompactAllocationBar({
  segments,
  total,
  share,
  displayLegend,
  legendAs,
  legendLayout,
  formatValue,
  className,
}: {
  segments: AllocationSegment[]
  total: number
  share: (value: number) => number
  displayLegend: boolean
  legendAs: "value" | "percent"
  legendLayout: "stack" | "inline"
  formatValue: (
    value: number,
    segment: AllocationSegment
  ) => ReactNode
  className?: string
}) {
  return (
    <div data-slot="allocation-bar" className={className}>
      <div
        role="img"
        aria-label={segments.length ? "Allocation" : "No allocation"}
        className="flex h-2 gap-0.5 overflow-hidden rounded-sm bg-well"
      >
        {total > 0
          ? segments.map((segment, index) => {
              const color = segmentColor(segment, index)
              const preset = isSeriesColor(color)
                ? SERIES_BG[color]
                : undefined

              return (
                <div
                  key={segmentKey(segment, index)}
                  className={preset}
                  style={{
                    width: `${share(segment.value)}%`,
                    backgroundColor: preset ? undefined : color,
                  }}
                  title={`${segment.label} · ${share(segment.value).toFixed(0)}%`}
                />
              )
            })
          : null}
      </div>

      {displayLegend ? (
        <div
          className={cn(
            "mt-4",
            legendLayout === "inline"
              ? "flex flex-wrap items-center gap-x-6 gap-y-2"
              : "flex flex-col gap-3"
          )}
        >
          {segments.map((segment, index) => {
            const color = segmentColor(segment, index)
            const preset = isSeriesColor(color)
              ? SERIES_BG[color]
              : undefined

            return (
              <div
                key={segmentKey(segment, index)}
                className={cn(
                  "flex items-center gap-2.5",
                  legendLayout === "inline" && "gap-2"
                )}
              >
                <span
                  aria-hidden
                  className={cn(
                    "size-2 flex-none rounded-[2px]",
                    preset
                  )}
                  style={{
                    backgroundColor: preset ? undefined : color,
                  }}
                />
                <span
                  className={cn(
                    "text-xs text-secondary-foreground",
                    legendLayout === "inline"
                      ? "whitespace-nowrap"
                      : "flex-1"
                  )}
                >
                  {segment.label}
                </span>
                {legendAs === "percent" ? (
                  <span className="font-mono text-xs text-muted-foreground tabular-nums">
                    {share(segment.value).toFixed(0)}%
                  </span>
                ) : (
                  <span className="text-xs">
                    {formatValue(segment.value, segment)}
                  </span>
                )}
              </div>
            )
          })}
        </div>
      ) : null}
    </div>
  )
}
