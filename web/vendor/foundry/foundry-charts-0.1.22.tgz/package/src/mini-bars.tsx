import { Bar, BarChart, ResponsiveContainer, Tooltip } from "recharts"

export type MiniBarPoint = {
  label: string
  value: number
}

export function MiniBars({
  data,
  height = 96,
}: {
  data: MiniBarPoint[]
  height?: number
}) {
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer
        width="100%"
        height="100%"
        initialDimension={{ width: 320, height }}
      >
        <BarChart data={data} barCategoryGap="28%">
          <Tooltip
            cursor={{ fill: "var(--accent)", opacity: 0.45 }}
            contentStyle={{
              background: "var(--popover)",
              color: "var(--popover-foreground)",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius)",
              fontSize: 12,
            }}
          />
          <Bar
            dataKey="value"
            fill="var(--chart-2)"
            radius={[3, 3, 1, 1]}
            isAnimationActive={false}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
