import {
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceArea,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { cn } from "@foundry/ui/lib/utils"

export interface TelemetryPoint {
  timestamp: string | number
  value: number
  isOutlier?: boolean
  zScore?: number
}

export interface TelemetryTraceChartProps {
  data: TelemetryPoint[]
  personalBaseline?: { mean: number; stdDev: number }
  referenceRange?: { min: number; max: number; label?: string }
  height?: number
  unit?: string
  valueFormatter?: (val: number) => string
  className?: string
}

export function TelemetryTraceChart({
  data,
  personalBaseline,
  referenceRange,
  height = 260,
  unit,
  valueFormatter = (val) => `${val}${unit ? ` ${unit}` : ""}`,
  className,
}: TelemetryTraceChartProps) {
  return (
    <div
      data-slot="telemetry-trace-chart"
      style={{ height }}
      className={cn("w-full relative", className)}
    >
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 12, right: 16, bottom: 8, left: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.5} />
          <XAxis
            dataKey="timestamp"
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
          />
          <YAxis
            stroke="var(--muted-foreground)"
            tick={{ fill: "var(--muted-foreground)", fontSize: 10, fontFamily: "var(--font-mono)" }}
            tickFormatter={valueFormatter}
          />

          {/* Reference range shading */}
          {referenceRange && (
            <ReferenceArea
              y1={referenceRange.min}
              y2={referenceRange.max}
              fill="var(--positive)"
              fillOpacity={0.06}
            />
          )}

          {/* Personal baseline ±1 stdDev */}
          {personalBaseline && (
            <>
              <ReferenceLine
                y={personalBaseline.mean}
                stroke="var(--primary)"
                strokeDasharray="4 4"
                label={{
                  value: "Baseline",
                  position: "insideTopRight",
                  fill: "var(--primary)",
                  fontSize: 9,
                  fontFamily: "var(--font-mono)",
                }}
              />
              <ReferenceArea
                y1={personalBaseline.mean - personalBaseline.stdDev}
                y2={personalBaseline.mean + personalBaseline.stdDev}
                fill="var(--primary)"
                fillOpacity={0.08}
              />
            </>
          )}

          <Tooltip
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null
              const pt = payload[0].payload as TelemetryPoint
              return (
                <div className="rounded-control border border-border bg-popover/95 p-2 font-mono text-xs shadow-lg backdrop-blur-md">
                  <div className="font-semibold text-strong">{label}</div>
                  <div className="text-primary font-medium">{valueFormatter(pt.value)}</div>
                  {pt.zScore !== undefined && (
                    <div className="text-2xs text-muted-foreground">
                      Z-score: {pt.zScore >= 0 ? "+" : ""}{pt.zScore.toFixed(1)}σ
                    </div>
                  )}
                  {pt.isOutlier && (
                    <div className="text-2xs text-warning font-semibold mt-0.5">
                      ⚠️ Outlier Reading
                    </div>
                  )}
                </div>
              )
            }}
          />

          <Line
            dataKey="value"
            stroke="var(--primary)"
            strokeWidth={2}
            dot={(props: any) => {
              const { cx, cy, payload } = props
              if (payload?.isOutlier) {
                return (
                  <circle
                    key={`${cx}-${cy}`}
                    cx={cx}
                    cy={cy}
                    r={4.5}
                    fill="var(--warning)"
                    stroke="var(--background)"
                    strokeWidth={1.5}
                  />
                )
              }
              return (
                <circle
                  key={`${cx}-${cy}`}
                  cx={cx}
                  cy={cy}
                  r={2}
                  fill="var(--primary)"
                />
              )
            }}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  )
}
